from simplines import compile_kernel, apply_periodic

from simplines import SplineSpace
from simplines import TensorSpace
from simplines import StencilMatrix
from simplines import StencilVector
from simplines import least_square_Bspline

#.. Prologation by knots insertion matrix
from   simplines                   import prolongation_matrix

#====================================================
#.... Cahn_hilliard utilities
from gallery_section_08 import assemble_matrix_ex01 #---1 : In uniform mesh 
from gallery_section_08 import assemble_vector_ex01 #---1 : In uniform mesh
from gallery_section_08 import assemble_norm_ex01   #---1 : In uniform mesh 

assemble_stiffness = compile_kernel(assemble_matrix_ex01, arity=2)
assemble1_rhs      = compile_kernel(assemble_vector_ex01, arity=1)
assemble_norm_l2   = compile_kernel(assemble_norm_ex01, arity=1)
#...
from gallery_section_08 import assemble_matrix_ex04 #---2 : In adapted mesh
from gallery_section_08 import assemble_vector_ex02 #---2 : In adapted mesh
from gallery_section_08 import assemble_norm_ex02   #---2 : In adapted mesh

assemble2_rhs       = compile_kernel(assemble_vector_ex02, arity=1)
assemble2_stiffness = compile_kernel(assemble_matrix_ex04, arity=2)
assemble2_norm_l2   = compile_kernel(assemble_norm_ex02, arity=1)

#-----------------------------------------------------------MAE utilities
from gallery_section_10 import assemble_stiffnessmatrix1D
from gallery_section_10 import assemble_massmatrix1D
from gallery_section_10 import assemble_matrix_ex11
from gallery_section_10 import assemble_matrix_ex12
from gallery_section_10 import assemble_vector_ex0mae # .. identity mapping

assemble_stiffness1D = compile_kernel( assemble_stiffnessmatrix1D, arity=2)
assemble_mass1D      = compile_kernel( assemble_massmatrix1D, arity=2)
assemble_matrix_ex01 = compile_kernel(assemble_matrix_ex11, arity=1)
assemble_matrix_ex02 = compile_kernel(assemble_matrix_ex12, arity=1)
assemble_rhsmae_t0    = compile_kernel(assemble_vector_ex0mae, arity=1)


#++++ MAE and Density function
from gallery_section_11 import assemble_vector_ex01mae
from gallery_section_11 import assemble_vector_rhsmae

assemble_rhsmae       = compile_kernel(assemble_vector_ex01mae, arity=1)
assemble_monmae       = compile_kernel(assemble_vector_rhsmae, arity=1)

#................................................
from gallery_section_12 import plot_res
from gallery_section_12 import assemble_vector_in

assemble_rhs_in      = compile_kernel(assemble_vector_in, arity=1)

#=================================
from scipy.sparse        import kron
from scipy.sparse        import csr_matrix
from scipy.sparse        import csc_matrix, linalg as sla
from kronecker.kronecker import vec_2d
from kronecker.fast_diag import Poisson
from numpy               import zeros, linalg, asarray, sqrt
#+-
import timeit
import time
import numpy as np


#==============================================================================
class Picard(object):

    # ... intensity of mesh refinement
    intensity = 50.
    def __init__(self, V1, V2, V3, V4, V00, V11, V01, V10):
       #___
       I1         = np.eye(V3.nbasis)
       I2         = np.eye(V4.nbasis)

       #... We delete the first and the last spline function
       #.. as a technic for applying Neumann boundary condition
       #.in a mixed formulation

       #..Stiffness and Mass matrix in 1D in the first deriction
       D1         = assemble_mass1D(V3)
       D1         = D1.tosparse()
       D1         = D1.toarray()
       D1         = csr_matrix(D1)
       #___
       M1         = assemble_mass1D(V1)
       M1         = M1.tosparse()
       m1         = M1
       M1         = M1.toarray()[1:-1,1:-1]
       M1         = csc_matrix(M1)
       m1         = csr_matrix(m1)

       #..Stiffness and Mass matrix in 1D in the second deriction
       D2         = assemble_mass1D(V4)
       D2         = D2.tosparse()
       D2         = D2.toarray()
       D2         = csr_matrix(D2)
       #___
       M2         = assemble_mass1D(V2)
       M2         = M2.tosparse()
       m2         = M2
       M2         = M2.toarray()[1:-1,1:-1]
       M2         = csc_matrix(M2)
       m2         = csr_matrix(m2)

       #...
       R1         = assemble_matrix_ex01(V01)
       R1         = R1.toarray()
       R1         = R1.reshape(V01.nbasis)
       r1         = R1.T
       R1         = R1[1:-1,:].T
       R1         = csr_matrix(R1)
       r1         = csr_matrix(r1)
       #___
       R2         = assemble_matrix_ex02(V10)
       R2         = R2.toarray()
       R2         = R2.reshape(V10.nbasis)
       r2         = R2
       R2         = R2[:,1:-1]
       R2         = csr_matrix(R2)
       r2         = csr_matrix(r2)

       #...step 0.1
       mats_1     = [M1, M1]
       mats_2     = [D2, D2]

       # ...Fast Solver
       poisson_c1 = Poisson(mats_1, mats_2)
              
       #...step 0.2
       mats_1     = [D1, D1]
       mats_2     = [M2, M2]

       # ...Fast Solver
       poisson_c2 = Poisson(mats_1, mats_2)
       
       #...step 1
       M1         = sla.inv(M1)
       A1         = M1.dot(R1.T)
       K1         = R1.dot( A1)
       K1         = csr_matrix(K1)
       #___
       M2         = sla.inv(M2)
       A2         = M2.dot( R2.T)
       K2         = R2.dot( A2)
       K2         = csr_matrix(K2)

       #...step 2
       mats_1     = [D1, K1]
       mats_2     = [D2, K2]

       # ...Fast Solver
       poisson    = Poisson(mats_1, mats_2)

       #  ... Strong form of Neumann boundary condition which is Dirichlet because of Mixed formulation
       u_01       = StencilVector(V01.vector_space)
       u_10       = StencilVector(V10.vector_space)
       #..
       x_D        = np.zeros(V01.nbasis)
       y_D        = np.zeros(V10.nbasis)

       x_D[-1, :] = 1. 
       y_D[:, -1] = 1.
       #..
       #..
       u_01.from_array(V01, x_D)
       u_10.from_array(V10, y_D)
       #...non homogenoeus Neumann boundary 
       b01        = -kron(r1, D2).dot(u_01.toarray())
       #__
       b10        = -kron(D1, r2).dot( u_10.toarray())
       b_0        = b01 + b10
       #...
       b11        = -kron(m1[1:-1,:], D2).dot(u_01.toarray())
       #___
       b12        = -kron(D1, m2[1:-1,:]).dot(u_10.toarray())
       
       #___Solve first system
       self.r_0     =  kron(A1.T, I2).dot(b11) + kron(I1, A2.T).dot(b12) - b_0

       #___
       self.x11_1   = kron(A1, I2)
       self.x12_1   = kron(I1, A2)
       #___
       self.C1      = poisson_c1.solve(2.*b11)
       self.C2      = poisson_c2.solve(2.*b12)
        
       self.spaces  = [V1, V2, V3, V4, V11, V01, V10]
       self.poisson = poisson
       self.M_res   = kron(D1, D2)
    def solve(self, V= None, x_2 = None, time = None, u_H = None, u11_li = None, u12_li = None):

        V1, V2, V3, V4, V11, V01, V10    = self.spaces[:]
        # ... for residual
        M_res      = self.M_res     
        #----------------------------------------------------------------------------------------------
        tol    = 1.e-7
        niter  = 100
        
        if x_2 is None :
            # ... for Two or Multi grids
            u11     = StencilVector(V01.vector_space)
            u12     = StencilVector(V10.vector_space)
            x11     = np.zeros(V01.nbasis) # dx/ appr.solution
            x12     = np.zeros(V10.nbasis) # dy/ appr.solution
            # ...
            u11.from_array(V01, x11)
            u12.from_array(V10, x12)
            # ...Assembles Neumann boundary conditions
            x11[-1,:]  = 1.
            x12[:,-1]  = 1.
            # .../
            x_2     = zeros(V3.nbasis*V4.nbasis)
        else:
            u11          = StencilVector(V01.vector_space)
            u12          = StencilVector(V10.vector_space)
            x11          = np.zeros(V01.nbasis) # dx/ appr.solution
            x12          = np.zeros(V10.nbasis) # dy/ appr.solution
            # ...Assembles Neumann (Dirichlet) boundary conditions
            x11[-1,:]    = 1.
            x12[:,-1]    = 1.
            # ...
            x11[1:-1,:]  =  (self.C1 - self.x11_1.dot(x_2)).reshape([V1.nbasis-2,V3.nbasis])
            u11.from_array(V01, x11)
            #___
            x12[:,1:-1]  =  (self.C2 - self.x12_1.dot(x_2)).reshape([V4.nbasis,V2.nbasis-2])
            u12.from_array(V10, x12)        

        if u_H is None:

             for i in range(niter):
           
                   #---Assembles a right hand side of Poisson equation
                   rhs          = StencilVector(V11.vector_space)
                   rhs          = assemble_rhsmae_t0(V, fields = [u11, u12], out= rhs)
                   b            = rhs.toarray()
                   #___
                   r            =  self.r_0 - b
           
                   # ... Solve first system
                   x2           = self.poisson.solve(r)
                   x2           = x2 -sum(x2)/len(x2)
                   #___
                   x11[1:-1,:]  =  (self.C1 - self.x11_1.dot(x2)).reshape([V1.nbasis-2,V3.nbasis])      
                   u11.from_array(V01, x11)
                   #___
                   x12[:,1:-1]  =  (self.C2 - self.x12_1.dot(x2)).reshape([V4.nbasis,V2.nbasis-2])
                   u12.from_array(V10, x12)
  
                   #..Residual   
                   dx           = x2[:]-x_2[:]
                   x_2[:]       = x2[:]
           
                   #... Compute residual for L2
                   l2_residual   = sqrt(dx.dot(M_res.dot(dx)) )
            
                   if l2_residual < tol:
                       break
        else  :           
             for i in range(niter):
           
                   #---Assembles a right hand side of Poisson equation
                   rhs          = StencilVector(V11.vector_space)
                   rhs          = assemble_rhsmae(V, fields = [u11, u12, u11_li, u12_li, u_H], knots = True, value = [Picard.intensity], out= rhs)
                   b            = rhs.toarray()
                   #___
                   r            =  self.r_0 - b
           
                   # ... Solve first system
                   x2           = self.poisson.solve(r)
                   x2           = x2 -sum(x2)/len(x2)
                   #___
                   x11[1:-1,:]  =  (self.C1 - self.x11_1.dot(x2)).reshape([V1.nbasis-2,V3.nbasis])      
                   u11.from_array(V01, x11)
                   #___
                   x12[:,1:-1]  =  (self.C2 - self.x12_1.dot(x2)).reshape([V4.nbasis,V2.nbasis-2])
                   u12.from_array(V10, x12)
  
                   #..Residual   
                   dx           = x2[:]-x_2[:]
                   x_2[:]       = x2[:]
           
                   #... Compute residual for L2
                   l2_residual   = sqrt(dx.dot(M_res.dot(dx)) )
            
                   if l2_residual < tol:
                       break
        print('-----> N-iter in Picard ={} -----> l2_residual= {}'.format(i, l2_residual))
        return u11, u12, x11, x12
        
#================================================================================
#.. Computes the L2 projection of a solution at last iteration            
#==============================================================================
class L2_projection(object):
    
    # ... left_v and right_v is the bounds of a density function [left_v, right_v]
    left_v   = 1.
    right_v  = 10.
    assert(right_v - left_v > 0.)
    
    def __init__(self, V1, V2, periodic):
       #___
       M1               = assemble_mass1D(V1)
       M1               = apply_periodic(V1, M1)
       M1               = csr_matrix(M1)

       M2               = assemble_mass1D(V2)
       M2               = apply_periodic(V1, M2)
       M2               = csr_matrix(M2)

       mats_1           = [0.5*M1, 0.5*M1]
       mats_2           = [M2, M2]
       # ...
       mats_1           = [0.5*M1, 0.5*M1]
       mats_2           = [M2, M2]
       # ...
       self.poisson     = Poisson(mats_1, mats_2)   
       # ...
       self.spaces      = [V1, V2] 
       self.periodic    = periodic
       self.nbasis      = [V1.nbasis-V1.degree, V2.nbasis-V2.degree]
       self.M1          = M1
       self.M2          = M2
           
    def density(self, V, Vh, u11_mae, u12_mae, u):
           
           nbasis     = (self.nbasis[0],self.nbasis[0])
           #print('-----L2 projection of the solution in the B-spline space--------------')
           u_L2       = StencilVector(V.vector_space)
           #...
           rhs        = StencilVector(V.vector_space)
           rhs        = assemble_monmae(Vh, fields = [u11_mae, u12_mae, u], knots = True, value = [L2_projection.left_v, L2_projection.right_v], out= rhs)
           b          = apply_periodic( V, rhs, self.periodic)
       
           #---Solve a linear system
           x          = self.poisson.solve(b)
           x          = x.reshape(nbasis)
           x          = apply_periodic(V, x, self.periodic, update = True)

           #...
           u_L2.from_array(V, x)
           return u_L2, x 
       
    def Proj_solve(self, V):
           V1, V2     = self.spaces[:]
           M_mass     = kron(self.M1, self.M2)
           nbasis     = (self.nbasis[0],self.nbasis[0])       
           #... We delete the first and the last spline function
           #. as a technic for applying Dirichlet boundary condition
           u                = StencilVector(V.vector_space)
 
           #---- assemble random control Points
           #rhs              = assemble_rhs_in( V)
           #b                = apply_periodic(V, rhs, self.periodic)
           #xh               = self.poisson.solve(b)
           #xh               = xh.reshape(nbasis)
           #... this is for random coeffs
           xh               = (np.random.rand(nbasis[0], nbasis[1])-1.)*0.05 + 0.63
           xh               = apply_periodic(V, xh, self.periodic, update = True)
           u.from_array(V, xh)
           #...
           Norm      = assemble_norm_l2(V, fields=[u], value = [alpha, theta])
           norm      = Norm.toarray()[1]
           return u, xh, M_mass, norm
           
#============================================================
#... two-stage pre-dictor–multicorrector algorithm
def Cahn_hilliard_in_uniform_mesh(V1, V2, V, u, xh, dt, alpha, theta, N_iter = None):

       periodic = [True, True]

       if N_iter is None:
          N_iter  = 100
       tol        = 1e-6
       
       u_f        = StencilVector(V.vector_space)
       
       #... Step 1 : Initialization
       xu_n       = zeros(V.nbasis)
       xu_n[:,:]  = xh[:,:]
       
       #___
       u_f.from_array(V, xu_n )
       #... step 2 : Multicoerrector :
       for i in range(0, N_iter): 
             
          #___ step (b): implicite time schem level
           
          stiffness  = assemble_stiffness(V, fields=[u_f], value = [dt, alpha, theta])
          M          = apply_periodic(V, stiffness, periodic)
          #...
          rhs        = assemble1_rhs( V, fields=[u_f, u], value = [dt, alpha, theta])
          rhs        = apply_periodic(V, rhs, periodic)

          #--Solve a linear system
          b          = -1.*rhs
          #++ 
          lu         = sla.splu(csc_matrix(M))
          d_thx      = lu.solve(b)
          #print('CPU-time  SUP_LU== ', time.time()- start)
          d_tx       = d_thx.reshape((V1.nbasis-V1.degree, V2.nbasis-V2.degree))                    
          d_tx       = apply_periodic(V, d_tx, periodic, update= True)
          #___ step (c): update
          xu_n[:,:] = xu_n[:,:] + d_tx[:,:]
          Res        = np.max(np.absolute(d_thx))
          #___ step (a)
          u_f.from_array(V, xu_n )
          
          if Res < tol or Res > 1e10:
             break
       print('perform the iteration number : = {} Residual  = {}'.format( i, Res))
       # ...
       u.from_array(V, xu_n)
       # ...
       Norm      = assemble_norm_l2(V, fields=[u], value = [alpha, theta])
       norm      = Norm.toarray()[1]
       return u, xu_n, Res, norm

#============================================================
#... two-stage pre-dictor–multicorrector algorithm
def Cahn_hilliard_in_adapted_mesh(V1, V2, V, Vh, u11_mae, u12_mae, u, dt, alpha, theta, N_iter = None):

       periodic = [True, True]

       if N_iter is None:
          N_iter  = 100
       tol        = 1e-6
       
       u_f        = StencilVector(V.vector_space)
       # ...
       xh = u.toarray().reshape(V.nbasis)         
       # ... Step 1 : Initialization
       xu_n       = zeros(V.nbasis)
       xu_n[:,:]  = xh[:,:]
       # ... :  u_f in uniform mesh
       u_f.from_array(V, xu_n ) 
       for i in range(0, N_iter): 
             
          #___ step (b): Implicite time schem level  
          start = time.time()         
          stiffness  = StencilMatrix(V.vector_space, V.vector_space)
          stiffness  = assemble2_stiffness(Vh, fields=[u11_mae, u12_mae, u_f], value = [dt, alpha, theta], out = stiffness)
          M          = apply_periodic(V, stiffness, periodic)
          #...
          rhs        = StencilVector(V.vector_space)          
          rhs        = assemble2_rhs( Vh, fields=[u11_mae, u12_mae, u_f, u], value = [dt, alpha, theta], out = rhs)
          rhs        = apply_periodic(V, rhs, periodic)

          #--Solve a linear system
          b          = -1.*(rhs)
          # ...
          M          = csc_matrix(M)
          # +++ 
          start = time.time()         
          lu         = sla.splu(M)
          d_thx      = lu.solve(b)
          #print('\n time consumed to solve linear system ==================================', time.time() - start,'\n')
          # ...
          d_tx       = d_thx.reshape((V1.nbasis-V1.degree, V2.nbasis-V2.degree))                    
          d_tx       = apply_periodic(V, d_tx, periodic, update= True)
          #___ step (c): update
          xu_n[:,:] = xu_n[:,:] + d_tx[:,:]
          Res        = np.max(np.absolute(d_thx))
          #___ step (a)
          u_f.from_array(V, xu_n )
          
          if Res < tol or Res > 1e10:
             break
       
       print('perform the iteration number : = {} Residual  = {}'.format( i, Res))
       # ...
       u.from_array(V, xu_n)
       # ...
       Norm       = StencilVector(V.vector_space)
       Norm       = assemble2_norm_l2(Vh, fields=[u11_mae, u12_mae, u], value = [alpha, theta], out = Norm)
       norm       = Norm.toarray()[1]
       return u, xu_n, Res, norm

# ... EDPs data
alpha           = 3000.
theta           = 3./2 

# ... Galerkin initialization
mdegree         = 4
degree          = 2
quad_degree     = max(degree, mdegree)+3
nelements       = 32
periodic        = [True, True]

# ...
dt              = 1e-8
t               = 0.
levels          = list(np.linspace(-0.0,1.0,100))
# ...
nbpts           = 140    # for plot
t_max           = 1.      # for time
Sol_CH          = []
Sol_ACH         = []
n_iter          = []
GL_free_energy  = []
GL_free_Adenergy= []

#--------------------
# create the spline space for each direction
U1    = SplineSpace(degree=degree, nelements= nelements, nderiv = 2, periodic=periodic[0], quad_degree = quad_degree)
U2    = SplineSpace(degree=degree, nelements= nelements, nderiv = 2, periodic=periodic[1], quad_degree = quad_degree)
Uh    = TensorSpace(U1, U2)

#----------------------
# create the spline space for each direction
V1    = SplineSpace(degree=mdegree, nelements= nelements, nderiv = 2, quad_degree = quad_degree)
V2    = SplineSpace(degree=mdegree, nelements= nelements, nderiv = 2, quad_degree = quad_degree)
V3    = SplineSpace(degree=mdegree-1, nelements= nelements, grid = V1.grid, nderiv = 2, quad_degree = quad_degree)
V4    = SplineSpace(degree=mdegree-1, nelements= nelements, grid = V2.grid, nderiv = 2, quad_degree = quad_degree)

# create the tensor space
V00   = TensorSpace(V1, V2)
V11   = TensorSpace(V3, V4)
V01   = TensorSpace(V1, V3)
V10   = TensorSpace(V4, V2)
Vh    = TensorSpace(V1, V2, V3, V4, U1, U2)
Vt    = TensorSpace(V3, V4, U1, U2)

#=======================================================
#... Computes the tools for Mixed V-F of MAE
Pi     = Picard(V1, V2, V3, V4, V00, V11, V01, V10)
#..............................................................
#--- Computes the initial CH randem solution and B-spline solver for densioty function
Pr_h   = L2_projection(U1, U2, periodic)

#=======================================================
u_ch, xu_ch, M_ms, norm = Pr_h.Proj_solve(Uh)

#... Fixed for computing statistical moment
u_Pr0      = xu_ch

#---Adaptive meshes
u_n_ch     = u_ch

#-------------------------------------------------------
#..... computing the initial optimal mapping as identity
u11_mae, u12_mae, x11_mae, x12_mae   = Pi.solve(V = Vh, time = 0.)

# ...
du_ch     = (u_Pr0[:-degree,:-degree]-xu_ch[:-degree,:-degree]).reshape((Uh.nbasis[0]-degree)*(Uh.nbasis[1]-degree))
Sol_CH.append((M_ms.dot(du_ch)).dot(du_ch) )
Sol_ACH.append((M_ms.dot(du_ch)).dot(du_ch))
GL_free_energy.append(norm)     
GL_free_Adenergy.append(norm)
n_iter.append(np.exp(float(np.format_float_scientific( t, unique=False, precision=2)))-1.)   
plot_res(V01, V10, Uh, xu_ch, x11_mae, x12_mae, xu_ch, u_Pr0, nbpts, 0, t, n_iter, levels, Sol_CH, Sol_ACH, GL_free_energy, GL_free_Adenergy)

pl_r   = 1
save_i = 1
ii     = 0

while t <= t_max:
   if t >= 1e-3: 
       dt = 1e-7
   t           += dt
   print('================= In Uniform mesh  ============================time =', t)
   u_ch_l  = u_ch
   #-------------------------------------------
   u_ch, xu_ch, Res1, norm_f = Cahn_hilliard_in_uniform_mesh(U1, U2, Uh, u_ch, xu_ch, dt, alpha, theta)
   
   # ... In adaptive meshes
   print('================= In adaptive meshes ==========================time =', t, '\n\n')
   u_n_ch_l   = u_n_ch
   u11_mae_l  = u11_mae
   u12_mae_l  = u12_mae
   #-----------------------------------------------------------
   # ... computation of the optimal mapping using last solution 
   rho_st, rho_h                        = Pr_h.density(Uh, Vh, u11_mae, u12_mae, u_n_ch)

   # ... Computes the optimal mapping using initial solution 
   u11_mae, u12_mae, x11_mae, x12_mae   = Pi.solve(V=Vh, u_H = rho_st, u11_li = u11_mae, u12_li = u12_mae)
   # ...   
   u_n_ch, xh_n_ch, Res, norm_ad        = Cahn_hilliard_in_adapted_mesh(U1, U2, Uh, Vh, u11_mae, u12_mae, u_n_ch, dt, alpha, theta)
   
   #------------
   if  Res + Res1 > 1. :
        print("Sorry. Your settings or the regularity assumption are not working !!!")
        u_ch     = u_ch_l 
        u_n_ch   = u_n_ch_l  
        u11_mae  = u11_mae_l
        u12_mae  = u12_mae_l
        dt       = dt*5e-1
        ii      -= 1

   if ii == pl_r :
     pl_r   += 10
     #+++++++++++++++++++++++++++++
     du_ch     = (u_Pr0[:-degree,:-degree]-xu_ch[:-degree,:-degree]).reshape((Uh.nbasis[0]-degree)*(Uh.nbasis[1]-degree))
     Sol_CH.append((M_ms.dot(du_ch)).dot(du_ch) )
     du_ch     = (u_Pr0[:-degree,:-degree]-xh_n_ch[:-degree,:-degree]).reshape((Uh.nbasis[0]-degree)*(Uh.nbasis[1]-degree))
     Sol_ACH.append((M_ms.dot(du_ch)).dot(du_ch) )
     GL_free_energy.append(norm_f)     
     GL_free_Adenergy.append(norm_ad)
     n_iter.append(np.exp(float(np.format_float_scientific( t, unique=False, precision=2)))-1.)   
     # ...
     plot_res(V01, V10, Uh, xu_ch, x11_mae, x12_mae, xh_n_ch, u_Pr0, nbpts, save_i, t, n_iter, levels, Sol_CH, Sol_ACH, GL_free_energy, GL_free_Adenergy, rho_h = rho_h)
     # ...
     save_i += 1
     #____________
   ii += 1
