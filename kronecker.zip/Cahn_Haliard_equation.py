from simplines import compile_kernel, apply_periodic

from simplines import SplineSpace
from simplines import TensorSpace
from simplines import StencilMatrix
from simplines import StencilVector
from simplines import pyccel_sol_field_2d
from simplines import least_square_Bspline
from simplines import prolongation_matrix

#====================================================
#.... Poisson utilities
from gallery_section_08 import assemble_matrix_ex01 #---1 : In uniform mesh 
from gallery_section_08 import assemble_vector_ex01 #---1 : In uniform mesh
from gallery_section_08 import assemble_norm_ex01   #---1 : In uniform mesh 

assemble_stiffness = compile_kernel(assemble_matrix_ex01, arity=2)
assemble1_rhs      = compile_kernel(assemble_vector_ex01, arity=1)
assemble_norm_l2   = compile_kernel(assemble_norm_ex01, arity=1)
#...
from gallery_section_08 import assemble_matrix_ad02 #---2 : In adapted mesh
from gallery_section_08 import assemble_vector_ex02 #---2 : In adapted mesh
from gallery_section_08 import assemble_norm_ex02   #---2 : In adapted mesh

assemble2_rhs       = compile_kernel(assemble_vector_ex02, arity=1)
assemble2_stiffness = compile_kernel(assemble_matrix_ad02, arity=2)
assemble2_norm_l2   = compile_kernel(assemble_norm_ex02, arity=1)

#====================================================
#... MAE utilities
from gallery_section_10 import assemble_stiffnessmatrix1D
from gallery_section_10 import assemble_massmatrix1D
from gallery_section_10 import assemble_matrix_ex11
from gallery_section_10 import assemble_matrix_ex12
from gallery_section_10 import assemble_vector_ex0mae

assemble_stiffness1D = compile_kernel( assemble_stiffnessmatrix1D, arity=2)
assemble_mass1D      = compile_kernel( assemble_massmatrix1D, arity=2)
assemble_matrix_ex01 = compile_kernel(assemble_matrix_ex11, arity=1)
assemble_matrix_ex02 = compile_kernel(assemble_matrix_ex12, arity=1)
assemble_rhsmae_t0    = compile_kernel(assemble_vector_ex0mae, arity=1)

#====================================================
#... Density --sqrt(1+|grad(uh|))
from gallery_section_11 import assemble_vector_ex01mae
from gallery_section_11 import assemble_vector_rhsmae

assemble_rhsmae       = compile_kernel(assemble_vector_ex01mae, arity=1)
assemble_monmae       = compile_kernel(assemble_vector_rhsmae, arity=1)

#====================================================
# ... L2 projection
from gallery_section_12 import assemble_vector_in
from gallery_section_12 import assemble_vector_in02
from gallery_section_12 import plot_res

assemble_rhs_in      = compile_kernel(assemble_vector_in, arity=1)
assemble_inrhs       = compile_kernel(assemble_vector_in02, arity=1)


#=================================
from scipy.sparse        import kron
from scipy.sparse        import csr_matrix
from scipy.sparse        import csc_matrix, linalg as sla
from kronecker.kronecker import vec_2d
from kronecker.fast_diag import Poisson
from numpy               import zeros, linalg, asarray, sqrt
#+-
import numpy as np
import timeit
import time

#==============================================================================
class Picard(object):
    def __init__(self, V1, V2, V3, V4, V00, V11, V01, V10):
       #___
       I1         = np.eye(V3.nbasis)
       I2         = np.eye(V4.nbasis)

       #... We delete the first and the last spline function
       #.. as a technic for applying Neumann boundary condition
       #.in a mixed formulation

       #..Stiffness and Mass matrix in 1D in the first deriction
       D1         = assemble_mass1D(V3)
       D1         = D1.tosparse()
       D1         = D1.toarray()
       D1         = csr_matrix(D1)
       #___
       M1         = assemble_mass1D(V1)
       M1         = M1.tosparse()
       m1         = M1
       M1         = M1.toarray()[1:-1,1:-1]
       M1         = csc_matrix(M1)
       m1         = csr_matrix(m1)

       #..Stiffness and Mass matrix in 1D in the second deriction
       D2         = assemble_mass1D(V4)
       D2         = D2.tosparse()
       D2         = D2.toarray()
       D2         = csr_matrix(D2)
       #___
       M2         = assemble_mass1D(V2)
       M2         = M2.tosparse()
       m2         = M2
       M2         = M2.toarray()[1:-1,1:-1]
       M2         = csc_matrix(M2)
       m2         = csr_matrix(m2)

       #...
       R1         = assemble_matrix_ex01(V01)
       R1         = R1.toarray()
       R1         = R1.reshape(V01.nbasis)
       r1         = R1.T
       R1         = R1[1:-1,:].T
       R1         = csr_matrix(R1)
       r1         = csr_matrix(r1)
       #___
       R2         = assemble_matrix_ex02(V10)
       R2         = R2.toarray()
       R2         = R2.reshape(V10.nbasis)
       r2         = R2
       R2         = R2[:,1:-1]
       R2         = csr_matrix(R2)
       r2         = csr_matrix(r2)

       #...step 0.1
       mats_1     = [M1, M1]
       mats_2     = [D2, D2]

       # ...Fast Solver
       poisson_c1 = Poisson(mats_1, mats_2)
              
       #...step 0.2
       mats_1     = [D1, D1]
       mats_2     = [M2, M2]

       # ...Fast Solver
       poisson_c2 = Poisson(mats_1, mats_2)
       
       #...step 1
       M1         = sla.inv(M1)
       A1         = M1.dot(R1.T)
       K1         = R1.dot( A1)
       K1         = csr_matrix(K1)
       #___
       M2         = sla.inv(M2)
       A2         = M2.dot( R2.T)
       K2         = R2.dot( A2)
       K2         = csr_matrix(K2)

       #...step 2
       mats_1     = [D1, K1]
       mats_2     = [D2, K2]

       # ...Fast Solver
       poisson    = Poisson(mats_1, mats_2)

       #  ... Strong form of Neumann boundary condition which is Dirichlet because of Mixed formulation
       u_01       = StencilVector(V01.vector_space)
       u_10       = StencilVector(V10.vector_space)
       #..
       x_D        = np.zeros(V01.nbasis)
       y_D        = np.zeros(V10.nbasis)

       x_D[-1, :] = 1. 
       y_D[:, -1] = 1.
       #..
       #..
       u_01.from_array(V01, x_D)
       u_10.from_array(V10, y_D)
       #...non homogenoeus Neumann boundary 
       b01        = -kron(r1, D2).dot(u_01.toarray())
       #__
       b10        = -kron(D1, r2).dot( u_10.toarray())
       b_0        = b01 + b10
       #...
       b11        = -kron(m1[1:-1,:], D2).dot(u_01.toarray())
       #___
       b12        = -kron(D1, m2[1:-1,:]).dot(u_10.toarray())
       
       #___Solve first system
       self.r_0     =  kron(A1.T, I2).dot(b11) + kron(I1, A2.T).dot(b12) - b_0

       #___
       self.x11_1   = kron(A1, I2)
       self.x12_1   = kron(I1, A2)
       #___
       self.C1      = poisson_c1.solve(2.*b11)
       self.C2      = poisson_c2.solve(2.*b12)
        
       self.spaces  = [V1, V2, V3, V4, V11, V01, V10]
       self.poisson = poisson
       self.M_res   = kron(D1, D2)
    def solve(self, V= None, x_2 = None, time = None, u_H = None, u11_li = None, u12_li = None):

        V1, V2, V3, V4, V11, V01, V10    = self.spaces[:]
        # ... for residual
        M_res      = self.M_res     
        #----------------------------------------------------------------------------------------------
        tol    = 1.e-7
        niter  = 100
        
        if x_2 is None :
            # ... for Two or Multi grids
            u11     = StencilVector(V01.vector_space)
            u12     = StencilVector(V10.vector_space)
            x11     = np.zeros(V01.nbasis) # dx/ appr.solution
            x12     = np.zeros(V10.nbasis) # dy/ appr.solution
            # ...
            u11.from_array(V01, x11)
            u12.from_array(V10, x12)
            # ...Assembles Neumann boundary conditions
            x11[-1,:]  = 1.
            x12[:,-1]  = 1.
            # .../
            x_2     = zeros(V3.nbasis*V4.nbasis)
        else:
            u11          = StencilVector(V01.vector_space)
            u12          = StencilVector(V10.vector_space)
            x11          = np.zeros(V01.nbasis) # dx/ appr.solution
            x12          = np.zeros(V10.nbasis) # dy/ appr.solution
            # ...Assembles Neumann (Dirichlet) boundary conditions
            x11[-1,:]    = 1.
            x12[:,-1]    = 1.
            # ...
            x11[1:-1,:]  =  (self.C1 - self.x11_1.dot(x_2)).reshape([V1.nbasis-2,V3.nbasis])
            u11.from_array(V01, x11)
            #___
            x12[:,1:-1]  =  (self.C2 - self.x12_1.dot(x_2)).reshape([V4.nbasis,V2.nbasis-2])
            u12.from_array(V10, x12)        

        if u_H is None:

             for i in range(niter):
           
                   #---Assembles a right hand side of Poisson equation
                   rhs          = StencilVector(V11.vector_space)
                   rhs          = assemble_rhsmae_t0(V, fields = [u11, u12], out= rhs)
                   b            = rhs.toarray()
                   #___
                   r            =  self.r_0 - b
           
                   # ... Solve first system
                   x2           = self.poisson.solve(r)
                   x2           = x2 -sum(x2)/len(x2)
                   #___
                   x11[1:-1,:]  =  (self.C1 - self.x11_1.dot(x2)).reshape([V1.nbasis-2,V3.nbasis])      
                   u11.from_array(V01, x11)
                   #___
                   x12[:,1:-1]  =  (self.C2 - self.x12_1.dot(x2)).reshape([V4.nbasis,V2.nbasis-2])
                   u12.from_array(V10, x12)
  
                   #..Residual   
                   dx           = x2[:]-x_2[:]
                   x_2[:]       = x2[:]
           
                   #... Compute residual for L2
                   l2_residual   = sqrt(dx.dot(M_res.dot(dx)) )
            
                   if l2_residual < tol:
                       break
        else  :           
             for i in range(niter):
           
                   #---Assembles a right hand side of Poisson equation
                   rhs          = StencilVector(V11.vector_space)
                   rhs          = assemble_rhsmae(V, fields = [u11, u12, u11_li, u12_li, u_H], knots = True, out= rhs)
                   b            = rhs.toarray()
                   #___
                   r            =  self.r_0 - b
           
                   # ... Solve first system
                   x2           = self.poisson.solve(r)
                   x2           = x2 -sum(x2)/len(x2)
                   #___
                   x11[1:-1,:]  =  (self.C1 - self.x11_1.dot(x2)).reshape([V1.nbasis-2,V3.nbasis])      
                   u11.from_array(V01, x11)
                   #___
                   x12[:,1:-1]  =  (self.C2 - self.x12_1.dot(x2)).reshape([V4.nbasis,V2.nbasis-2])
                   u12.from_array(V10, x12)
  
                   #..Residual   
                   dx           = x2[:]-x_2[:]
                   x_2[:]       = x2[:]
           
                   #... Compute residual for L2
                   l2_residual   = sqrt(dx.dot(M_res.dot(dx)) )
            
                   if l2_residual < tol:
                       break
        print('-----> N-iter in Picard ={} -----> l2_residual= {}'.format(i, l2_residual))
        return u11, u12, x11, x12
        
#================================================================================
#.. Computes the L2 projection of a solution at last iteration            
#==============================================================================
class L2_projection(object):
    def __init__(self, V1, V2, periodic):
       #___
       M1               = assemble_mass1D(V1)
       M1               = apply_periodic(V1, M1)
       M1               = csr_matrix(M1)

       M2               = assemble_mass1D(V2)
       M2               = apply_periodic(V1, M2)
       M2               = csr_matrix(M2)

       mats_1           = [0.5*M1, 0.5*M1]
       mats_2           = [M2, M2]
       # ...
       mats_1           = [0.5*M1, 0.5*M1]
       mats_2           = [M2, M2]
       # ...
       self.poisson     = Poisson(mats_1, mats_2)   
       # ...
       self.spaces      = [V1, V2] 
       self.periodic    = periodic
       self.nbasis      = [V1.nbasis-V1.degree, V2.nbasis-V2.degree]
       self.M1          = M1
       self.M2          = M2
           
    def density(self, V, Vh, u11_mae, u12_mae, u):
           
           nbasis     = (self.nbasis[0],self.nbasis[0])
           #print('-----L2 projection of the solution in the B-spline space--------------')
           u_L2       = StencilVector(V.vector_space)
           #...
           rhs        = StencilVector(V.vector_space)
           rhs        = assemble_monmae(Vh, fields = [u11_mae, u12_mae, u], knots = True, out= rhs)
           b          = apply_periodic( V, rhs, self.periodic)
       
           #---Solve a linear system
           x          = self.poisson.solve(b)
           x          = x.reshape(nbasis)
           x          = apply_periodic(V, x, self.periodic, update = True)

           #...
           u_L2.from_array(V, x)
           return u_L2, x 
       
    #==============================================================================
    #.......Poisson ALGORITHM
    def Proj_solve(self, V):
           V1, V2     = self.spaces[:]
           M_mass     = kron(self.M1, self.M2)
           nbasis     = (self.nbasis[0],self.nbasis[0])       
           #... We delete the first and the last spline function
           #. as a technic for applying Dirichlet boundary condition
           u                = StencilVector(V.vector_space)
           dtu                = StencilVector(V.vector_space)
 
           #---- assemble random control Points
           #rhs              = assemble_rhs_in( V)
           #b                = apply_periodic(V, rhs, self.periodic)
           #xh               = self.poisson.solve(b)
           #xh               = xh.reshape(nbasis)
           #... this is for random coeffs
           xh               = (np.random.rand(nbasis[0], nbasis[1])-1.)*0.05 +0.63
           xh               = apply_periodic(V, xh, self.periodic, update = True)
           u.from_array(V, xh)
           
           #---- assemble rhs of dt u at t = 0
           rhs               = assemble_inrhs( V, fields = [u])
           rhs               = apply_periodic( V, rhs, self.periodic)
           # ...
           b                = -1.*rhs
           #--Solve a linear system
           dtxh             = self.poisson.solve(b)
           dtxh             = dtxh.reshape(nbasis)
           dtxh             = apply_periodic(V, dtxh, self.periodic, update = True)
           dtu.from_array(V, dtxh)
           #...
           Norm      = assemble_norm_l2(V, fields=[u])
           norm      = Norm.toarray()[1]
           return u, xh, dtu, dtxh, M_mass, norm
           
           
#============================================================
#... two-stage pre-dictor–multicorrector algorithm
#============================================================
def Cahn_Haliard_equation(V1, V2, V, u, xh, ut, txh, dt, N_iter = None):

       periodic = [True, True]
       rho_inf    = 0.5
       alpha_m    = 0.5 * ((3. - rho_inf)/(1. + rho_inf))
       alpha_f    = 1/(1. + rho_inf)
       gamma      = 0.5 + alpha_m - alpha_f

       if N_iter is None:
          N_iter  = 100
       tol        = 1e-5
       
       u_m        = StencilVector(V.vector_space)
       u_f        = StencilVector(V.vector_space)
       
       #... Step 1 : Initialization
       xu_n       = zeros(V.nbasis)
       xu_n[:,:]  = xh[:,:]
       #...
       xtu_n      = zeros(V.nbasis)
       xtu_n[:,:] = ( (gamma-1.)/gamma ) * txh[:,:]
           
       #... step 2 : Multicoerrector :
       for i in range(0, N_iter): 
             
          #___ step (a)
          u_m.from_array(V, txh + alpha_m * (xtu_n - txh) )   
          u_f.from_array(V, xh  + alpha_f * (xu_n  -  xh) )
          #___ step (b): Genralized alpha level
           
          stiffness  = assemble_stiffness(V, fields=[u_f], value = [dt])
          M          = apply_periodic(V, stiffness, periodic)
          #...
          rhs        = assemble1_rhs( V, fields=[u_f, u_m])
          rhs        = apply_periodic(V, rhs, periodic)

          #--Solve a linear system
          b          = -1.*rhs
          #++ 
          #start      = time.time()
          #d_tx, status = sla.gmres(M, b, tol=1.e-8, maxiter=5000)
          #print('CPU-time  GMRES == ', time.time()- start)
          #start      = time.time()
          lu         = sla.splu(csc_matrix(M))
          d_tx       = lu.solve(b)
          #print('CPU-time  SUP_LU== ', time.time()- start)
          d_tx       = d_tx.reshape((V1.nbasis-V1.degree, V2.nbasis-V2.degree))                    
          d_tx       = apply_periodic(V, d_tx, periodic, update= True)
          #___ step (c): update
          xtu_n[:,:] = xtu_n[:,:] + d_tx[:,:]
          xu_n[:,:]  = xu_n[:,:]  +  gamma * dt * d_tx[:,:]
          Res        = np.max(np.absolute(b))
          if Res < tol or Res > 1e10:
             break
       print('perform the iteration number : = {} Residual  = {}'.format( i, Res))
       u.from_array(V, xu_n)
       ut.from_array(V, xtu_n)
       # ...
       Norm      = assemble_norm_l2(V, fields=[u])
       norm      = Norm.toarray()[0]
       return u, xu_n, ut, xtu_n, Res, norm       

#============================================================
#... two-stage pre-dictor–multicorrector algorithm
def Cahn_Haliard_equation_in_adapted_mesh(V1, V2, V, Vh, u11_mae, u12_mae,  u, ut, dt, N_iter = None):

       periodic = [True, True]
       rho_inf    = 0.5
       alpha_m    = 0.5 * ((3. - rho_inf)/(1. + rho_inf))
       alpha_f    = 1/(1. + rho_inf)
       gamma      = 0.5 + alpha_m - alpha_f

       if N_iter is None:
          N_iter  = 1000
       tol        = 1e-5
       # ...
       u_m        = StencilVector(V.vector_space)
       u_f        = StencilVector(V.vector_space)
       
       #... Step 1 : Initialization
       xh         = u.toarray().reshape(V.nbasis)
       txh        = ut.toarray().reshape(V.nbasis)
       # ...
       xu_n       = zeros(V.nbasis)
       xu_n[:,:]  = u.toarray().reshape(V.nbasis)
       #...
       xtu_n      = zeros(V.nbasis)
       xtu_n[:,:] = ( (gamma-1.)/gamma ) * ut.toarray().reshape(V.nbasis)
           
       #... step 2 : Multicoerrector :
       for i in range(0, N_iter): 
             
          #___ step (a)
          u_m.from_array(V, txh + alpha_m * (xtu_n - txh) )   
          u_f.from_array(V, xh  + alpha_f * (xu_n  -  xh) )
          #___ step (b): Genralized alpha level
          stiffness  = StencilMatrix(V.vector_space, V.vector_space)
          stiffness  = assemble2_stiffness(Vh, fields=[u11_mae, u12_mae, u_f], value = [dt], out = stiffness)
          M          = apply_periodic(V, stiffness, periodic)
          #...
          rhs        = StencilVector(V.vector_space)
          rhs        = assemble2_rhs( Vh, fields=[u11_mae, u12_mae, u_f, u_m], value = [dt], out = rhs)
          rhs        = apply_periodic(V, rhs, periodic)
          
          #--Solve a linear system
          b          = -1.*rhs
          #++ 
          #start      = time.time()
          #d_tx, status = sla.gmres(M, b, tol=1.e-8, maxiter=5000)
          #print('CPU-time  GMRES == ', time.time()- start)
          #start      = time.time()
          lu         = sla.splu(csc_matrix(M))
          d_tx       = lu.solve(b)
          #print('CPU-time  SUP_LU== ', time.time()- start)
          d_tx       = d_tx.reshape((V1.nbasis-V1.degree, V2.nbasis-V2.degree))                    
          d_tx       = apply_periodic(V, d_tx, periodic, update= True)
          #___ step (c): update
          xtu_n[:,:] = xtu_n[:,:] + d_tx[:,:]
          xu_n[:,:]  = xu_n[:,:]  +  gamma * dt * d_tx[:,:]
          Res        = np.max(np.absolute(b))
          if Res < tol or Res > 1e10:
             break
       print('perform the iteration number : = {} Residual  = {}'.format( i, Res))
       u.from_array(V, xu_n)
       ut.from_array(V, xtu_n)
       # ...
       # ...
       Norm       = StencilVector(V.vector_space)
       Norm       = assemble2_norm_l2(Vh, fields=[u11_mae, u12_mae, u], out = Norm)
       norm       = Norm.toarray()[0]
       return u, xu_n, ut, xtu_n, Res, norm   

mdegree         = 4
degree          = 2
quad_degree     = max(degree, mdegree)+3
nelements       = 32
periodic        = [True, True]
# ...
dt              = 1e-8
t               = 0.
levels          = list(np.linspace(-0.2,1.2,100))
# ...
nbpts           = 140    # for plot
t_final         = 1.
Sol_CH          = []
Sol_ACH         = []
n_iter          = []
GL_free_energy  = []
GL_free_Adenergy= []

#----------------------
# create the spline space for each direction
U1    = SplineSpace(degree=degree, nelements= nelements, nderiv = 2, periodic=periodic[0], quad_degree = quad_degree)
U2    = SplineSpace(degree=degree, nelements= nelements, nderiv = 2, periodic=periodic[1], quad_degree = quad_degree)
Uh    = TensorSpace(U1, U2)

#----------------------
# create the spline space for each direction
V1 = SplineSpace(degree=mdegree, nelements= nelements, nderiv = 2, quad_degree = quad_degree)
V2 = SplineSpace(degree=mdegree, nelements= nelements, nderiv = 2, quad_degree = quad_degree)
V3 = SplineSpace(degree=mdegree-1, nelements= nelements, grid = V1.grid, nderiv = 2, quad_degree = quad_degree)
V4 = SplineSpace(degree=mdegree-1, nelements= nelements, grid = V2.grid, nderiv = 2, quad_degree = quad_degree)

# create the tensor space
V00 = TensorSpace(V1, V2)
V11 = TensorSpace(V3, V4)
V01 = TensorSpace(V1, V3)
V10 = TensorSpace(V4, V2)
Vh  = TensorSpace(V1, V2, V3, V4, U1, U2)
Vt  = TensorSpace(V3, V4, U1, U2)

#=======================================================
#--------------Initialization
#======================================================= 
u11_mae_i  = StencilVector(V01.vector_space)
u12_mae_i  = StencilVector(V10.vector_space)

#... Computes the tools for Mixed V-F of MAE
Pi         = Picard(V1, V2, V3, V4, V00, V11, V01, V10)

#--- Computes the tools for CH and B-spline L2 porjection
Pr_h       = L2_projection(U1, U2, periodic)


#================================================================= ==========
#--------------Compute the initial unifrom mesh and initial solution
#======================================================= ====================
#..... computing the initial optimal mapping as identity
u11_mae, u12_mae, x11_mae, x12_mae   = Pi.solve(V = Vh, time = 0.)

#=======================================================
u_ch, xu_ch, dtu_ch, dtxu_ch, M_ms, norm = Pr_h.Proj_solve(Uh)

#... For computing statistical moment
u_Pr0      = xu_ch
#---Adaptive meshes
u_n_ch    = u_ch
tu_n_ch   = dtu_ch


# --------------------------
# ... PLOT initial solution
du_ch     = (u_Pr0[:-degree,:-degree]-xu_ch[:-degree,:-degree]).reshape((Uh.nbasis[0]-degree)*(Uh.nbasis[1]-degree))
Sol_CH.append((M_ms.dot(du_ch)).dot(du_ch) )
Sol_ACH.append((M_ms.dot(du_ch)).dot(du_ch))
GL_free_energy.append(norm)     
GL_free_Adenergy.append(norm)
n_iter.append(np.exp(float(np.format_float_scientific( t, unique=False, precision=2)))-1.)   
plot_res(V01, V10, Uh, xu_ch, x11_mae, x12_mae, xu_ch, u_Pr0, nbpts, 0, t, n_iter, levels, Sol_CH, Sol_ACH, GL_free_energy, GL_free_Adenergy)

# ---
pl_r   = 1
save_i = 1
ii     = 0

while t < t_final:
   if t >= 1e-6:
        dt = 1e-7
   t        += dt
   print('computation in time =', t, '\n\n')
   print('================= In Uniform mesh  ============================')
   u_ch_l  = u_ch
   #-------------------------------------------
   u_ch, xu_ch, dtu_ch, dtxu_ch, Res1, norm_f  = Cahn_Haliard_equation(U1, U2, Uh, u_ch, xu_ch, dtu_ch, dtxu_ch, dt)
   
   #... In adaptive meshes
   print('================= In adaptive meshes ==========================')
   #-----------------------------------------------------------
   #... computation of the optimal mapping using last solution 
   lsu_n_ch   = u_n_ch 
   u11_mae_i.from_array(V01, x11_mae)
   u12_mae_i.from_array(V10, x12_mae)
   # ...
   rho_st, rho_h                        = Pr_h.density(Uh, Vh, u11_mae, u12_mae, u_n_ch)
   # ... Computes the optimal mapping using initial solution
   u11_mae, u12_mae, x11_mae, x12_mae   = Pi.solve(V=Vh, u_H = rho_st, u11_li = u11_mae, u12_li = u12_mae)
   #===================================================
   # ... Computes the projection to the B-spline spaces
   u_n_ch, xh_n_ch, tu_n_ch, txh_n_ch, Res, norm_ad = Cahn_Haliard_equation_in_adapted_mesh(U1, U2, Uh, Vh, u11_mae, u12_mae, u_n_ch, tu_n_ch, dt)

   #------------
   if  Res + Res1 > 1. :
        print("Sorry. Your settings or the regularity assumption are not working !!!")
        u_ch     = u_ch_l 
        u_n_ch   = u_n_ch_l  
        u11_mae  = u11_mae_l
        u12_mae  = u12_mae_l
        dt       = dt*5e-1
        ii      -= 1

   if ii == pl_r :
     pl_r   += 10
     #+++++++++++++++++++++++++++++
     du_ch     = (u_Pr0[:-degree,:-degree]-xu_ch[:-degree,:-degree]).reshape((Uh.nbasis[0]-degree)*(Uh.nbasis[1]-degree))
     Sol_CH.append((M_ms.dot(du_ch)).dot(du_ch) )
     du_ch     = (u_Pr0[:-degree,:-degree]-xh_n_ch[:-degree,:-degree]).reshape((Uh.nbasis[0]-degree)*(Uh.nbasis[1]-degree))
     Sol_ACH.append((M_ms.dot(du_ch)).dot(du_ch) )
     GL_free_energy.append(norm_f)     
     GL_free_Adenergy.append(norm_ad)
     n_iter.append(np.exp(float(np.format_float_scientific( t, unique=False, precision=2)))-1.)   
     # ...
     plot_res(V01, V10, Uh, xu_ch, x11_mae, x12_mae, xh_n_ch, u_Pr0, nbpts, save_i, t, n_iter, levels, Sol_CH, Sol_ACH, GL_free_energy, GL_free_Adenergy, rho_h = rho_h)
     # ...
     save_i += 1
     #____________
   ii += 1
