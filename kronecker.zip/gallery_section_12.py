__all__ = ['assemble_vector_ex01mae']

#---Assemble rhs of L2 projection
#==============================================================================
from pyccel.decorators import types

#==============================================================================
@types('int', 'int', 'int', 'int', 'int', 'int', 'int', 'int','int', 'int', 'int', 'int', 'int[:]', 'int[:]','int[:]', 'int[:]','int[:]', 'int[:]', 'double[:,:,:,:]', 'double[:,:,:,:]',  'double[:,:,:,:]', 'double[:,:,:,:]', 'double[:,:,:,:]', 'double[:,:,:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]',  'double[:,:]', 'double[:,:]', 'real[:]', 'real[:]', 'real[:]', 'real[:]', 'real[:]', 'real[:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]')
def assemble_vector_ex12(ne1, ne2, ne3, ne4, ne5, ne6, p1, p2, p3, p4, p5, p6, spans_1, spans_2,  spans_3, spans_4, spans_5, spans_6, basis_1, basis_2, basis_3, basis_4, basis_5, basis_6, weights_1, weights_2, weights_3, weights_4, weights_5, weights_6, points_1, points_2, points_3, points_4, points_5, points_6, knots_1, knots_2, knots_3, knots_4, knots_5, knots_6, vector_u, vector_w, vector_v, rhs):

    from numpy import empty
    from numpy import zeros
    from numpy import exp

    # ... sizes
    k1 = weights_5.shape[1]
    k2 = weights_6.shape[1]
    #...
    lcoeffs_u  = zeros((p1+1,p3+1))
    lcoeffs_w  = zeros((p4+1,p2+1))
    lcoeffs_v  = zeros((p5+1,p6+1))
    lvalues_u  = zeros((k1, k2))
    # ...
    J_mat      = zeros((k1,k2))

    points1    = zeros((ne1*ne2, k1*k2))
    points2    = zeros((ne1*ne2, k1*k2))

    # ... Assemble a new points by a new map 
    for ie1 in range(0, ne1):
        i_span_1 = spans_1[ie1]
        i_span_4 = spans_4[ie1]
        for ie2 in range(0, ne2):
            i_span_2 = spans_2[ie2]
            i_span_3 = spans_3[ie2]

            lcoeffs_u[ : , : ] = vector_u[i_span_1 : i_span_1+p1+1, i_span_3 : i_span_3+p3+1]
            lcoeffs_w[ : , : ] = vector_w[i_span_4 : i_span_4+p4+1, i_span_2 : i_span_2+p2+1]
            for g1 in range(0, k1):
                for g2 in range(0, k2):

                    sx = 0.0
                    for il_1 in range(0, p1+1):
                          for il_2 in range(0, p3+1):

                              bj_0    = basis_1[ie1,il_1,0,g1]*basis_3[ie2,il_2,0,g2]
                              coeff_u = lcoeffs_u[il_1,il_2]

                              sx     +=  coeff_u*bj_0
                    sy = 0.0
                    for il_1 in range(0, p4+1):
                          for il_2 in range(0, p2+1):

                              bj_0    = basis_4[ie1,il_1,0,g1]*basis_2[ie2,il_2,0,g2]
                              coeff_w = lcoeffs_w[il_1,il_2]

                              sy     +=  coeff_w*bj_0
                    points1[ie2+ne2*ie1, g2+k2*g1] = sx
                    points2[ie2+ne2*ie1, g2+k2*g1] = sy

    #--Computes All basis in a new points
    nders          = 2
    degree         = p5
    #..
    ne, nq         = points1.shape
    xx             = zeros(nq)

    left           = empty( degree )
    right          = empty( degree )
    ndu            = empty( (degree+1, degree+1) )
    a              = empty( (       2, degree+1) )
    ders           = zeros( (     nders+1, degree+1) ) # output array
    basis1         = zeros( (ne,degree+1, nders+1, nq))
    for ie in range(ne):
        xx[:] = points1[ie,:]
        for iq,xq in enumerate(xx):
            #span = find_span( knots, degree, xq )
            #~~~~~~~~~~~~~~~
            # Knot index at left/right boundary
            low  = degree
            high = len(knots_5)-1-degree
            # Check if point is exactly on left/right boundary, or outside domain
            if xq <= knots_5[low ]: 
                 span = low
            if xq >= knots_5[high]: 
                 span = high-1
            else : 
              # Perform binary search
              span = (low+high)//2
              while xq < knots_5[span] or xq >= knots_5[span+1]:
                 if xq < knots_5[span]:
                     high = span
                 else:
                     low  = span
                 span = (low+high)//2
            ndu[0,0] = 1.0
            for j in range(0,degree):
                left [j] = xq - knots_5[span-j]
                right[j] = knots_5[span+1+j] - xq
                saved    = 0.0
                for r in range(0,j+1):
                    # compute inverse of knot differences and save them into lower triangular part of ndu
                    ndu[j+1,r] = 1.0 / (right[r] + left[j-r])
                    # compute basis functions and save them into upper triangular part of ndu
                    temp       = ndu[r,j] * ndu[j+1,r]
                    ndu[r,j+1] = saved + right[r] * temp
                    saved      = left[j-r] * temp
                ndu[j+1,j+1] = saved	

            # Compute derivatives in 2D output array 'ders'
            ders[0,:] = ndu[:,degree]
            for r in range(0,degree+1):
                s1 = 0
                s2 = 1
                a[0,0] = 1.0
                for k in range(1,nders+1):
                    d  = 0.0
                    rk = r-k
                    pk = degree-k
                    if r >= k:
                       a[s2,0] = a[s1,0] * ndu[pk+1,rk]
                       d = a[s2,0] * ndu[rk,pk]
                    j1 = 1   if (rk  > -1 ) else -rk
                    j2 = k-1 if (r-1 <= pk) else degree-r
                    for ij in range(j1,j2+1):
                        a[s2,ij] = (a[s1,ij] - a[s1,ij-1]) * ndu[pk+1,rk+ij]
                    for ij in range(j1,j2+1):
                        d += a[s2,ij]* ndu[rk+ij,pk]
                    if r <= pk:
                       a[s2,k] = - a[s1,k-1] * ndu[pk+1,r]
                       d += a[s2,k] * ndu[r,pk]
                    ders[k,r] = d
                    j  = s1
                    s1 = s2
                    s2 = j
            # Multiply derivatives by correct factors
            r = degree
            ders[1,:] = ders[1,:] * r
            r = r * (degree-1)
            ders[2,:] = ders[2,:] * r
            basis1[ie,:,0,iq] = ders[0,:]
            basis1[ie,:,1,iq] = ders[1,:]
            basis1[ie,:,2,iq] = ders[2,:]

    degree         = p6
    #..
    ne, nq         = points2.shape
    basis2         = zeros( (ne,degree+1, nders+1, nq))
    for ie in range(ne):
        xx[:] = points2[ie,:]
        for iq,xq in enumerate(xx):
            #span = find_span( knots, degree, xq )
            #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            # Knot index at left/right boundary
            low  = degree
            high = len(knots_6)-1-degree
            # Check if point is exactly on left/right boundary, or outside domain
            if xq <= knots_6[low ]: 
                 span = low
            if xq >= knots_6[high]: 
                 span = high-1
            else :
              # Perform binary search
              span = (low+high)//2
              while xq < knots_6[span] or xq >= knots_6[span+1]:
                 if xq < knots_6[span]:
                     high = span
                 else:
                     low  = span
                 span = (low+high)//2
            ndu[0,0] = 1.0
            for j in range(0,degree):
                left [j] = xq - knots_6[span-j]
                right[j] = knots_6[span+1+j] - xq
                saved    = 0.0
                for r in range(0,j+1):
                    # compute inverse of knot differences and save them into lower triangular part of ndu
                    ndu[j+1,r] = 1.0 / (right[r] + left[j-r])
                    # compute basis functions and save them into upper triangular part of ndu
                    temp       = ndu[r,j] * ndu[j+1,r]
                    ndu[r,j+1] = saved + right[r] * temp
                    saved      = left[j-r] * temp
                ndu[j+1,j+1] = saved	

            # Compute derivatives in 2D output array 'ders'
            ders[0,:] = ndu[:,degree]
            for r in range(0,degree+1):
                s1 = 0
                s2 = 1
                a[0,0] = 1.0
                for k in range(1,nders+1):
                    d  = 0.0
                    rk = r-k
                    pk = degree-k
                    if r >= k:
                       a[s2,0] = a[s1,0] * ndu[pk+1,rk]
                       d = a[s2,0] * ndu[rk,pk]
                    j1 = 1   if (rk  > -1 ) else -rk
                    j2 = k-1 if (r-1 <= pk) else degree-r
                    for ij in range(j1,j2+1):
                        a[s2,ij] = (a[s1,ij] - a[s1,ij-1]) * ndu[pk+1,rk+ij]
                    for ij in range(j1,j2+1):
                        d += a[s2,ij]* ndu[rk+ij,pk]
                    if r <= pk:
                       a[s2,k] = - a[s1,k-1] * ndu[pk+1,r]
                       d += a[s2,k] * ndu[r,pk]
                    ders[k,r] = d
                    j  = s1
                    s1 = s2
                    s2 = j
            #~~~ Multiply derivatives by correct factors
            r = degree
            ders[1,:] = ders[1,:] * r
            r = r * (degree-1)
            ders[2,:] = ders[2,:] * r
            basis2[ie,:,0,iq] = ders[0,:]
            basis2[ie,:,1,iq] = ders[1,:]
            basis2[ie,:,2,iq] = ders[2,:]
            
    # ... 
    for ie1 in range(0, ne5):
        i_span_1 = spans_1[ie1]
        i_span_4 = spans_4[ie1]
        i_span_5 = spans_5[ie1]
        
        for ie2 in range(0, ne6):
            i_span_2 = spans_2[ie2]
            i_span_3 = spans_3[ie2]
            i_span_6 = spans_6[ie2]

            lcoeffs_u[ : , : ] = vector_u[i_span_1 : i_span_1+p1+1, i_span_3 : i_span_3+p3+1]
            lcoeffs_w[ : , : ] = vector_w[i_span_4 : i_span_4+p4+1, i_span_2 : i_span_2+p2+1]
            for g1 in range(0, k1):
                for g2 in range(0, k2):

                    sxx = 0.0
                    sxy = 0.0
                    for il_1 in range(0, p1+1):
                          for il_2 in range(0, p3+1):

                              bj_x     = basis_1[ie1,il_1,1,g1]*basis_3[ie2,il_2,0,g2]
                              bj_y     = basis_1[ie1,il_1,0,g1]*basis_3[ie2,il_2,1,g2]

                              coeff_u  = lcoeffs_u[il_1,il_2]

                              sxx     +=  coeff_u*bj_x
                              sxy     +=  coeff_u*bj_y
                    syx = 0.0
                    syy = 0.0
                    for il_1 in range(0, p4+1):
                          for il_2 in range(0, p2+1):

                              bj_y    = basis_4[ie1,il_1,0,g1]*basis_2[ie2,il_2,1,g2]
                              bj_x    = basis_4[ie1,il_1,1,g1]*basis_2[ie2,il_2,0,g2]

                              coeff_w = lcoeffs_w[il_1,il_2]

                              syx    +=  coeff_w*bj_x
                              syy    +=  coeff_w*bj_y

                    J_mat[g1,g2]      = abs(sxx*syy-sxy*syx)

            lcoeffs_v[ : , : ] = vector_v[i_span_5 : i_span_5+p5+1, i_span_6 : i_span_6+p6+1]
            for g1 in range(0, k1):
                for g2 in range(0, k2):
                    
                    s = 0.0
                    for il_1 in range(0, p5+1):
                        for il_2 in range(0, p6+1):
                            bi_0     = basis_5[ie1, il_1, 0, g1] * basis_6[ie2, il_2, 0, g2]
                            # ...
                            coeff_v  = lcoeffs_v[il_1,il_2]
                            # ...
                            s       +=  coeff_v*bi_0
                    lvalues_u[g1,g2]  = s
                    
            for g1 in range(0, k1):
                for g2 in range(0, k2):
                    for il_1 in range(0, p5+1):
                        for il_2 in range(0, p6+1):
                            xq     = points1[ie2+ne2*ie1, g2+k2*g1]

                            degree    = p5
                            low       = degree
                            high      = len(knots_5)-1-degree
                            # Check if point is exactly on left/right boundary, or outside domain
                            if xq <= knots_5[low ]: 
                                 span = low
                            if xq >= knots_5[high]: 
                                 span = high-1
                            else : 
                              # Perform binary search
                              span = (low+high)//2
                              while xq < knots_5[span] or xq >= knots_5[span+1]:
                                 if xq < knots_5[span]:
                                     high = span
                                 else:
                                     low  = span
                                 span = (low+high)//2

                            i1       = span - p5 + il_1
                            
                            # ...
                            xq       = points2[ie2+ne2*ie1, g2+k2*g1]

                            degree   = p6
                            low      = degree
                            high     = len(knots_6)-1-degree
                            # Check if point is exactly on left/right boundary, or outside domain
                            if xq <= knots_6[low ]: 
                                 span = low
                            if xq >= knots_6[high]: 
                                 span = high-1
                            else : 
                              # Perform binary search
                              span = (low+high)//2
                              while xq < knots_6[span] or xq >= knots_6[span+1]:
                                 if xq < knots_6[span]:
                                     high = span
                                 else:
                                     low  = span
                                 span = (low+high)//2

                            i2        = span - p6 + il_2
                            
                            # ...
                            bi_0      = basis1[ie2+ne2*ie1,il_1,0,g2+k2*g1]*basis2[ie2+ne2*ie1,il_2,0,g2+k2*g1]
                            # ...
                            wvol      = weights_5[ie1, g1]*weights_6[ie2, g2] 

                            #... 
                            u         = lvalues_u[g1,g2]
                            #...
                            rhs[i1+p5,i2+p6] += bi_0 * u * wvol * J_mat[g1,g2]
    # ...

#==============================================================================Assemble rhs Poisson
#---1 : In uniform mesh
@types('int', 'int', 'int', 'int', 'int[:]', 'int[:]', 'double[:,:,:,:]', 'double[:,:,:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]')
def assemble_vector_in02(ne1, ne2, p1, p2, spans_1, spans_2,  basis_1, basis_2,  weights_1, weights_2, points_1, points_2, vector_v, rhs):

    from numpy import zeros
    from numpy import random
    # ... sizes
    k1 = weights_1.shape[1]
    k2 = weights_2.shape[1]
    #...
    rho_inf = 0.5
    alpha_m = 0.5 * ((3. - rho_inf)/(1. + rho_inf))
    alpha_f = 1/(1. + rho_inf)
    gamma   = 0.5 + alpha_m - alpha_f
    alpha   = 3000.
    theta   = 3./2
    # ...
    lcoeffs_v  = zeros((p1+1,p2+1))
    #...
    lvalues_u  = zeros((k1, k2))
    lvalues_ux = zeros((k1, k2))
    lvalues_uy = zeros((k1, k2))
    # ...
    lvalues_uxx = zeros((k1, k2))
    lvalues_uyy = zeros((k1, k2))
    # ... build rhs
    for ie1 in range(0, ne1):
        i_span_1 = spans_1[ie1]
        for ie2 in range(0, ne2):
            i_span_2 = spans_2[ie2]
            
            lcoeffs_v[ : , : ] = vector_v[i_span_1 : i_span_1+p1+1, i_span_2 : i_span_2+p2+1]
            for g1 in range(0, k1):
                for g2 in range(0, k2):

                    #... Integration of Dirichlet boundary conditions
                    s   = 0.0
                    sy  = 0.0
                    sx  = 0.0
                    # ..
                    sxx = 0.0
                    syy = 0.0
                    for il_1 in range(0, p1+1):
                        for il_2 in range(0, p2+1):
                            
                            bi_0  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_x1 = basis_1[ie1, il_1, 1, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_x2 = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 1, g2]
                            
                            bi_xx = basis_1[ie1, il_1, 2, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_yy = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 2, g2]
                            # ... 
                            coeff_v   = lcoeffs_v[il_1,il_2]
                            # ...
                            s        +=  coeff_v*bi_0
                            sx       +=  coeff_v*bi_x1
                            sy       +=  coeff_v*bi_x2
                            # ...
                            sxx      +=  coeff_v*bi_xx
                            syy      +=  coeff_v*bi_yy
                                            
                    lvalues_u[g1,g2]   = s
                    lvalues_ux[g1,g2]  = sx
                    lvalues_uy[g1,g2]  = sy
                    #
                    lvalues_uxx[g1,g2] = sxx
                    lvalues_uyy[g1,g2] = syy
            for il_1 in range(0, p1+1):
                for il_2 in range(0, p2+1):
                    i1 = i_span_1 - p1 + il_1
                    i2 = i_span_2 - p2 + il_2

                    v = 0.0
                    for g1 in range(0, k1):
                        for g2 in range(0, k2):
                            bi_0  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_x  = basis_1[ie1, il_1, 1, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_y  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 1, g2]                            

                            bi_xx = basis_1[ie1, il_1, 2, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_yy = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 2, g2]                            
                            #..
                            wvol  = weights_1[ie1, g1]*weights_2[ie2, g2]
                            # ... rhs
                            u     = lvalues_u[g1,g2]
                            ux    = lvalues_ux[g1,g2]
                            uy    = lvalues_uy[g1,g2]
                            #..
                            uxx   = lvalues_uxx[g1,g2]
                            uyy   = lvalues_uyy[g1,g2]
                            v += (  ((3.*alpha/(2.*theta))*(1- 4.*theta*u*(1.-u)) + (1.-2. * u) * (uxx + uyy) ) * (ux * bi_x + uy * bi_y) + u * (1.-u) * (uxx + uyy) * (bi_xx + bi_yy) ) * wvol

                    rhs[i1+p1,i2+p2] += v   
    # ...
#==============================================================================Assemble rhs Poisson
#---1 : In uniform mesh
@types('int', 'int', 'int', 'int', 'int[:]', 'int[:]', 'double[:,:,:,:]', 'double[:,:,:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]')
def assemble_vector_in(ne1, ne2, p1, p2, spans_1, spans_2,  basis_1, basis_2,  weights_1, weights_2, points_1, points_2, rhs):

    from numpy import zeros
    from numpy import random
    from numpy import sin
    from numpy import exp
    from numpy import log
    from numpy import pi
    # ... sizes
    k1 = weights_1.shape[1]
    k2 = weights_2.shape[1]
    # ...
    lvalues_u  = zeros((k1, k2))
    # ... build rhs
    for ie1 in range(0, ne1):
        i_span_1 = spans_1[ie1]
        for ie2 in range(0, ne2):
            i_span_2 = spans_2[ie2]

            f                = (2.*random.rand()-1.)*0.05 +0.63
            for g1 in range(0, k1):
                for g2 in range(0, k2):
                    x = points_1[ie1, g1]
                    y = points_2[ie2, g2]
                    lvalues_u[g1,g2] = f #exp(-20*(x-0.5-0.25*sin(2*pi*y)*sin(0.6*pi*(1.+50.*0.)))**2)
                    
            for il_1 in range(0, p1+1):
                for il_2 in range(0, p2+1):
                    i1 = i_span_1 - p1 + il_1
                    i2 = i_span_2 - p2 + il_2

                    v = 0.0
                    for g1 in range(0, k1):
                        for g2 in range(0, k2):
                            bi_0  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 0, g2]
                            #..
                            wvol  = weights_1[ie1, g1]*weights_2[ie2, g2]
                            # ... rhs
                            u  = lvalues_u[g1,g2]
                            v += bi_0 * u * wvol 

                    rhs[i1+p1,i2+p2] += v   
    # ...

#==============================================================================Assemble rhs Poisson
#---1 : In uniform mesh
@types('int', 'int', 'int', 'int', 'int[:]', 'int[:]', 'double[:,:,:,:]', 'double[:,:,:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]', 'double[:,:]')
def assemble_vector_ex05(ne1, ne2, p1, p2, spans_1, spans_2,  basis_1, basis_2,  weights_1, weights_2, points_1, points_2, vector_v, rhs):

    from numpy import zeros
    from numpy import random
    # ... sizes
    k1 = weights_1.shape[1]
    k2 = weights_2.shape[1]
    #...
    rho_inf     = 0.5
    alpha_m     = 0.5 * ((3. - rho_inf)/(1. + rho_inf))
    alpha_f     = 1/(1. + rho_inf)
    gamma       = 0.5 + alpha_m - alpha_f
    alpha       = 3000.
    theta       = 3./2
    # ...
    lcoeffs_v   = zeros((p1+1,p2+1))
    #...
    lvalues_u   = zeros((k1, k2))
    lvalues_ux  = zeros((k1, k2))
    lvalues_uy  = zeros((k1, k2))
    # ...
    lvalues_uxx = zeros((k1, k2))
    lvalues_uyy = zeros((k1, k2))
    # ... build rhs
    for ie1 in range(0, ne1):
        i_span_1 = spans_1[ie1]
        for ie2 in range(0, ne2):
            i_span_2 = spans_2[ie2]
            
            lcoeffs_v[ : , : ] = vector_v[i_span_1 : i_span_1+p1+1, i_span_2 : i_span_2+p2+1]
            for g1 in range(0, k1):
                for g2 in range(0, k2):

                    #... Integration of Dirichlet boundary conditions
                    s   = 0.0
                    sy  = 0.0
                    sx  = 0.0
                    # ..
                    sxx = 0.0
                    syy = 0.0
                    for il_1 in range(0, p1+1):
                        for il_2 in range(0, p2+1):
                            
                            bi_0  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_x1 = basis_1[ie1, il_1, 1, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_x2 = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 1, g2]
                            
                            bi_xx = basis_1[ie1, il_1, 2, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_yy = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 2, g2]
                            # ... 
                            coeff_v   = lcoeffs_v[il_1,il_2]
                            # ...
                            s        +=  coeff_v*bi_0
                            sx       +=  coeff_v*bi_x1
                            sy       +=  coeff_v*bi_x2
                            # ...
                            sxx      +=  coeff_v*bi_xx
                            syy      +=  coeff_v*bi_yy
                                            
                    lvalues_u[g1,g2]   = s
                    lvalues_ux[g1,g2]  = sx
                    lvalues_uy[g1,g2]  = sy
                    #
                    lvalues_uxx[g1,g2] = sxx
                    lvalues_uyy[g1,g2] = syy
            for il_1 in range(0, p1+1):
                for il_2 in range(0, p2+1):
                    i1 = i_span_1 - p1 + il_1
                    i2 = i_span_2 - p2 + il_2

                    v = 0.0
                    for g1 in range(0, k1):
                        for g2 in range(0, k2):
                            bi_0  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_x  = basis_1[ie1, il_1, 1, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_y  = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 1, g2]                            

                            bi_xx = basis_1[ie1, il_1, 2, g1] * basis_2[ie2, il_2, 0, g2]
                            bi_yy = basis_1[ie1, il_1, 0, g1] * basis_2[ie2, il_2, 2, g2]                            
                            #..
                            wvol  = weights_1[ie1, g1]*weights_2[ie2, g2]
                            # ... rhs
                            u     = lvalues_u[g1,g2]
                            ux    = lvalues_ux[g1,g2]
                            uy    = lvalues_uy[g1,g2]
                            #..
                            uxx   = lvalues_uxx[g1,g2]
                            uyy   = lvalues_uyy[g1,g2]
                            v += (  ((3.*alpha/(2.*theta))*(1- 4.*theta*u*(1.-u)) + (1.-2. * u) * (uxx + uyy) ) * (ux * bi_x + uy * bi_y) + u * (1.-u) * (uxx + uyy) * (bi_xx + bi_yy) ) * wvol

                    rhs[i1+p1,i2+p2] += v   
    # ...
    

from simplines import pyccel_sol_field_2d
#from matplotlib.pyplot import plot, show
import matplotlib.pyplot            as     plt
from   mpl_toolkits.axes_grid1      import make_axes_locatable
from   mpl_toolkits.mplot3d         import axes3d
from   matplotlib                   import cm
from   mpl_toolkits.mplot3d.axes3d  import get_test_data
from   matplotlib.ticker            import LinearLocator, FormatStrFormatter
import numpy                        as     np
font = {'family': 'serif', 
	 'color':  'k', 
	 'weight': 'normal', 
	 'size': 25, 
		 } 

def plot_res(V01, V10, VPh, xu_ch, x11_mae, x12_mae, xh_n_ch, u_Pr0, nbpts, save_i, t, n_iter, levels, Sol_CH, Sol_ACH, GL_free_energy, GL_free_Adenergy, rho_h = None):    

	degree = VPh.degree[0]
	nbasis = VPh.nbasis
	if False :
	  #pl_rr   += 100
	  np.savetxt('data/mapp1_'+str(save_i)+'.txt', x11_mae, fmt='%.2e')
	  np.savetxt('data/mapp2_'+str(save_i)+'.txt',  x12_mae, fmt='%.2e')
	  np.savetxt('data/sol_uni_'+str(save_i)+'.txt', xu_ch, fmt='%.2e')
	  np.savetxt('data/sol_ad_'+str(save_i)+'.txt', xh_n_ch, fmt='%.2e')
	  np.savetxt('data/density_'+str(save_i)+'.txt', rho_h, fmt='%.2e')

	#-------------------------------------------------------------------------------------------
	u_Pr,a,b,X, Y    = pyccel_sol_field_2d((nbpts,nbpts),      xu_ch, VPh.knots, VPh.degree)	
	u_ad_Pr = pyccel_sol_field_2d((nbpts,nbpts),    xh_n_ch, VPh.knots, VPh.degree)[0]
	#++++++++++++++++++++++++++++++
	#--Solution of MAE equation (optimal mapping)
	Xmae,uxx,uxy = pyccel_sol_field_2d((nbpts,nbpts),  x11_mae , V01.knots, V01.degree)[:-2]
	Ymae,uyx,uyy = pyccel_sol_field_2d((nbpts,nbpts),  x12_mae , V10.knots, V10.degree)[:-2]
	#...
	Jac_MAE = uxx*uyy- uxy*uyx
	print('>-------------------------Quality of the optimal mapping-----------------------   Jacobian min = {}  Jacobian max = {}'.format(np.min(Jac_MAE), np.max(Jac_MAE)))
	#+++-----------------------------------------------------------------------------------
	time      = np.format_float_scientific(t, unique=False, precision=3)
	# ... Statistical moment
	# -----
	fig = plt.figure() 
	plt.plot(n_iter, Sol_ACH, '*-k', linewidth = 2., label='$\mathbf{Ad}$')
	plt.plot(n_iter, Sol_CH, 'o-b', linewidth = 2., label='$\mathbf{Un}$')
	plt.xscale('log')
	plt.grid(color='k', linestyle='--', linewidth=0.5, which ="both")
	plt.xlabel('$\mathbf{time}$',  fontweight ='bold', fontdict=font)
	plt.ylabel('$\mathbf{M_2}$',  fontweight ='bold', fontdict=font)
	plt.legend(fontsize="15")
	fig.tight_layout()
	plt.savefig('statistical_moment_2')
	plt.show(block=False)
	plt.close()
	# -----
	fig = plt.figure() 
	plt.plot(n_iter, GL_free_Adenergy,  '--*k', label = '$\mathbf{GL-free-energy Ad}$')
	plt.plot(n_iter, GL_free_energy,  '--ob', label = '$\mathbf{GL-free-energy}$' )
	plt.xscale('log')
	plt.xlabel('$\mathbf{time}$',  fontweight ='bold', fontdict=font)
	plt.ylabel('$\mathbf{E}$',  fontweight ='bold', fontdict=font)
	plt.grid(color='k', linestyle='--', linewidth=0.5, which ="both")
	plt.legend(fontsize="15")
	fig.tight_layout()
	plt.savefig('GL_free_energy.png')
	plt.show(block=False)
	plt.close()
	# -----
	fig =plt.figure() 
	plt.plot(Ymae[70,:], u_ad_Pr[70,:], 'o-k', linewidth = 2., label='$\mathbf{Ad}$')
	plt.plot(Y[70,:], u_Pr[70,:], '*-b', linewidth = 2., label='$\mathbf{Un}$')
	plt.grid(color='k', linestyle='--', linewidth=0.5, which ="both")
	plt.xlabel('$\mathbf{m}$',  fontweight ='bold', fontdict=font)
	plt.ylabel('$\mathbf{C^h}$',  fontweight ='bold', fontdict=font)
	plt.legend(fontsize="15")
	fig.tight_layout()
	plt.savefig('projection.png')
	plt.show(block=False)
	plt.close()
	# -----
	fig =plt.figure() 
	plt.plot(Ymae[10,:], u_ad_Pr[10,:], 'o-k', linewidth = 2., label='$\mathbf{Ad}$')
	plt.plot(Y[10,:], u_Pr[10,:], '*-b', linewidth = 2., label='$\mathbf{Un}$')
	plt.grid(color='k', linestyle='--', linewidth=0.5, which ="both")
	plt.xlabel('$\mathbf{m}$',  fontweight ='bold', fontdict=font)
	plt.ylabel('$\mathbf{C^h}$',  fontweight ='bold', fontdict=font)
	plt.legend(fontsize="15")
	fig.tight_layout()
	plt.savefig('projection10.png')
	plt.show(block=False)
	plt.close()
	# -----
	fig =plt.figure() 
	plt.plot(Ymae[110,:], u_ad_Pr[110,:], 'o-k', linewidth = 2., label='$\mathbf{Ad}$')
	plt.plot(Y[110,:], u_Pr[110,:], '*-b', linewidth = 2., label='$\mathbf{Un}$')
	plt.grid(color='k', linestyle='--', linewidth=0.5, which ="both")
	plt.xlabel('$\mathbf{m}$',  fontweight ='bold', fontdict=font)
	plt.ylabel('$\mathbf{C^h}$',  fontweight ='bold', fontdict=font)
	plt.legend(fontsize="15")
	fig.tight_layout()
	plt.savefig('projection110.png')
	plt.show(block=False)
	plt.close()
	# -----
	fig =plt.figure() 
	plt.plot(Ymae[130,:], u_ad_Pr[130,:], 'o-k', linewidth = 2., label='$\mathbf{Ad}$')
	plt.plot(Y[130,:], u_Pr[130,:], '*-b', linewidth = 2., label='$\mathbf{Un}$')
	plt.grid(color='k', linestyle='--', linewidth=0.5, which ="both")
	plt.xlabel('$\mathbf{m}$',  fontweight ='bold', fontdict=font)
	plt.ylabel('$\mathbf{C^h}$',  fontweight ='bold', fontdict=font)
	plt.legend(fontsize="15")
	fig.tight_layout()
	plt.savefig('projection.png')
	plt.show(block=False)
	plt.close()
	# ...
	figtitle        = 'Cahn_haliard_equation '
	fig, axes       = plt.subplots( 1, 2, figsize=[12,12], num=figtitle )
	for ax in axes:
	  ax.set_aspect('equal')
	axes[0].set_title( 'With adaptive meshes at t= {}'.format(time) )
	im2 = axes[0].contourf( Xmae, Ymae, u_ad_Pr, levels, cmap= 'jet')
	divider = make_axes_locatable(axes[0]) 
	cax   = divider.append_axes("right", size="5%", pad=0.05, aspect = 40) 
	plt.colorbar(im2, cax=cax)   

	axes[1].set_title( 'With uniform mesh at t= {}'.format(time) )
	im3 = axes[1].contourf( X, Y, u_Pr, levels, cmap= 'jet')
	divider = make_axes_locatable(axes[1]) 
	cax   = divider.append_axes("right", size="5%", pad=0.05, aspect = 40) 
	plt.colorbar(im3, cax=cax)

	fig.tight_layout()
	plt.subplots_adjust(wspace=0.3)
	plt.savefig('figs/u_{}.png'.format(save_i))
	plt.show(block=False)
	#plt.pause(0.3)
	plt.close()
	# ...
	figtitle        = 'Cahn_haliard_equation '
	fig, axes       = plt.subplots( 1, 2, figsize=[12,12], num=figtitle )
	for ax in axes:
	  ax.set_aspect('equal')
	#axes[0].set_title( 'Physical domain ' )
	for i in range(nbpts):
	   phidx = Xmae[:,i]
	   phidy = Ymae[:,i]

	   axes[0].plot(phidx, phidy, '-k', linewidth = 0.5)
	for i in range(nbpts):
	   phidx = Xmae[i,:]
	   phidy = Ymae[i,:]

	   axes[0].plot(phidx, phidy, '-k', linewidth = 0.5)
	#axes[0].axis('off')
	axes[0].margins(0,0)

	axes[1].set_title( 'With adaptive meshes at t= {}'.format(time) )
	im2 = axes[1].contourf( Xmae, Ymae, u_ad_Pr, levels, cmap= 'jet')
	divider = make_axes_locatable(axes[1]) 
	cax   = divider.append_axes("right", size="5%", pad=0.05, aspect = 40) 
	plt.colorbar(im2, cax=cax)
	fig.tight_layout()
	plt.subplots_adjust(wspace=0.3)
	plt.savefig('figs_monitor/uad_{}.png'.format(save_i))
	plt.show(block=False)
	#plt.pause(0.3)
	plt.close()
	# ...
	if rho_h is not None:
		Moni    = pyccel_sol_field_2d((nbpts,nbpts),      rho_h, VPh.knots, VPh.degree)[0]
		figtitle        = 'Cahn_haliard_equation '
		fig, axes       = plt.subplots( 1, 3, figsize=[12,12], num=figtitle )
		for ax in axes:
		  ax.set_aspect('equal')
		for i in range(nbpts):
		   phidx = Xmae[:,i]
		   phidy = Ymae[:,i]

		   axes[0].plot(phidx, phidy, '-k', linewidth = 0.5)
		for i in range(nbpts):
		   phidx = Xmae[i,:]
		   phidy = Ymae[i,:]

		   axes[0].plot(phidx, phidy, '-k', linewidth = 0.5)
		#axes[0].axis('off')
		axes[0].margins(0,0)

		axes[1].set_title( 'Monitor Funct at t= {}'.format(time) )
		im3 = axes[1].contourf( X, Y, Moni, cmap= 'jet')
		divider = make_axes_locatable(axes[1]) 
		cax   = divider.append_axes("right", size="5%", pad=0.05, aspect = 40) 
		plt.colorbar(im3, cax=cax)

		axes[2].set_title( 'With adaptive meshes at t= {}'.format(time) )
		im2 = axes[2].contourf( Xmae, Ymae, u_ad_Pr, levels, cmap= 'jet')
		divider = make_axes_locatable(axes[2]) 
		cax   = divider.append_axes("right", size="5%", pad=0.05, aspect = 40) 
		plt.colorbar(im2, cax=cax)      
		fig.tight_layout()
		plt.subplots_adjust(wspace=0.3)
		plt.savefig('figs_monitor/u_mon_{}.png'.format(save_i))
		plt.show(block=False)
		#plt.pause(0.3)
		plt.close()
	return 0
