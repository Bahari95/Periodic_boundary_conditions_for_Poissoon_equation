#define PY_ARRAY_UNIQUE_SYMBOL CWRAPPER_ARRAY_API
#include "numpy_version.h"
#include "numpy/arrayobject.h"
#include "cwrapper.h"
#include <stdlib.h>
#include "ndarrays.h"
#include "cwrapper_ndarrays.h"


void bind_c_solve_unit_sylvester_system_2d(int64_t n0_d1, double *d1, int64_t n0_d2, double *d2, int64_t n0_b, double *b, double tau, int64_t n0_x, double *x);
void bind_c_solve_unit_sylvester_system_3d(int64_t n0_d1, double *d1, int64_t n0_d2, double *d2, int64_t n0_d3, double *d3, int64_t n0_b, double *b, double tau, int64_t n0_x, double *x);

/*........................................*/


/*........................................*/

/*........................................*/
PyObject *solve_unit_sylvester_system_2d_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray d1 = {.shape = NULL};
    t_ndarray d2 = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    double tau;
    t_ndarray x = {.shape = NULL};
    PyArrayObject *d1_tmp;
    PyArrayObject *d2_tmp;
    PyArrayObject *b_tmp;
    PyObject *tau_tmp;
    PyArrayObject *x_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "d1",
        "d2",
        "b",
        "tau",
        "x",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!OO!", kwlist, &PyArray_Type, &d1_tmp, &PyArray_Type, &d2_tmp, &PyArray_Type, &b_tmp, &tau_tmp, &PyArray_Type, &x_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(d1_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        d1 = pyarray_to_ndarray(d1_tmp);
    }
    if (!pyarray_check(d2_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        d2 = pyarray_to_ndarray(d2_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (PyIs_NativeFloat(tau_tmp))
    {
        tau = PyDouble_to_Double(tau_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(x_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        x = pyarray_to_ndarray(x_tmp);
    }
    bind_c_solve_unit_sylvester_system_2d(nd_ndim(&d1, 0), nd_data(&d1), nd_ndim(&d2, 0), nd_data(&d2), nd_ndim(&b, 0), nd_data(&b), tau, nd_ndim(&x, 0), nd_data(&x));
    result = Py_BuildValue("");
    free_pointer(d1);
    free_pointer(d2);
    free_pointer(b);
    free_pointer(x);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *solve_unit_sylvester_system_3d_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray d1 = {.shape = NULL};
    t_ndarray d2 = {.shape = NULL};
    t_ndarray d3 = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    double tau;
    t_ndarray x = {.shape = NULL};
    PyArrayObject *d1_tmp;
    PyArrayObject *d2_tmp;
    PyArrayObject *d3_tmp;
    PyArrayObject *b_tmp;
    PyObject *tau_tmp;
    PyArrayObject *x_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "d1",
        "d2",
        "d3",
        "b",
        "tau",
        "x",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!OO!", kwlist, &PyArray_Type, &d1_tmp, &PyArray_Type, &d2_tmp, &PyArray_Type, &d3_tmp, &PyArray_Type, &b_tmp, &tau_tmp, &PyArray_Type, &x_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(d1_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        d1 = pyarray_to_ndarray(d1_tmp);
    }
    if (!pyarray_check(d2_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        d2 = pyarray_to_ndarray(d2_tmp);
    }
    if (!pyarray_check(d3_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        d3 = pyarray_to_ndarray(d3_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (PyIs_NativeFloat(tau_tmp))
    {
        tau = PyDouble_to_Double(tau_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(x_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        x = pyarray_to_ndarray(x_tmp);
    }
    bind_c_solve_unit_sylvester_system_3d(nd_ndim(&d1, 0), nd_data(&d1), nd_ndim(&d2, 0), nd_data(&d2), nd_ndim(&d3, 0), nd_data(&d3), nd_ndim(&b, 0), nd_data(&b), tau, nd_ndim(&x, 0), nd_data(&x));
    result = Py_BuildValue("");
    free_pointer(d1);
    free_pointer(d2);
    free_pointer(d3);
    free_pointer(b);
    free_pointer(x);
    return result;
}
/*........................................*/

static int exec_func(PyObject* m)
{
    return 0;
}

/*........................................*/

static PyMethodDef fast_diag_core_methods[] = {
    {
        "solve_unit_sylvester_system_2d",
        (PyCFunction)solve_unit_sylvester_system_2d_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        "\n    Solves the linear system (D1 x I2 + I1 x D2 + tau I1 x I2) x = b\n    "
    },
    {
        "solve_unit_sylvester_system_3d",
        (PyCFunction)solve_unit_sylvester_system_3d_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        "\n    Solves the linear system (D1 x I2 x I3 + I1 x D2 x I3 + I1 x I2 x D3 + tau I1 x I2 x I3) x = b\n    "
    },
    { NULL, NULL, 0, NULL}
};

/*........................................*/

static PyModuleDef_Slot fast_diag_core_slots[] = {
    {Py_mod_exec, exec_func},
    {0, NULL},
};

/*........................................*/

static struct PyModuleDef fast_diag_core_module = {
    PyModuleDef_HEAD_INIT,
    /* name of module */
    "fast_diag_core",
    /* module documentation, may be NULL */
    NULL,
    /* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
    0,
    fast_diag_core_methods,
    fast_diag_core_slots
};

/*........................................*/

PyMODINIT_FUNC PyInit_fast_diag_core(void)
{
    import_array();
    return PyModuleDef_Init(&fast_diag_core_module);
}
