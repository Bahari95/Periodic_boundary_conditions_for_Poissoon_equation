#define PY_ARRAY_UNIQUE_SYMBOL CWRAPPER_ARRAY_API
#include "numpy_version.h"
#include "numpy/arrayobject.h"
#include "cwrapper.h"
#include <stdlib.h>
#include "ndarrays.h"
#include "cwrapper_ndarrays.h"
#include <stdint.h>


void bind_c_spsolve_dns_lower(int64_t n0_L, int64_t n1_L, double *L, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_dns_upper(int64_t n0_U, int64_t n1_U, double *U, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_csr_lower(int64_t n0_A_data, double *A_data, int64_t n0_A_ind, int32_t *A_ind, int64_t n0_A_ptr, int32_t *A_ptr, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_csr_upper(int64_t n0_A_data, double *A_data, int64_t n0_A_ind, int32_t *A_ind, int64_t n0_A_ptr, int32_t *A_ptr, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_tril(int64_t n0_A_rows, int32_t *A_rows, int64_t n0_A_cols, int32_t *A_cols, int64_t n0_A_data, double *A_data, int64_t n0_rows, int64_t *rows, int64_t n0_cols, int64_t *cols, int64_t n0_data, double *data);
void bind_c_triu(int64_t n0_A_rows, int32_t *A_rows, int64_t n0_A_cols, int32_t *A_cols, int64_t n0_A_data, double *A_data, int64_t n0_rows, int64_t *rows, int64_t n0_cols, int64_t *cols, int64_t n0_data, double *data);
void bind_c_tril_kron_2(int64_t A1_nnz, int64_t n0_A1_rows, int32_t *A1_rows, int64_t n0_A1_cols, int32_t *A1_cols, int64_t n0_A1_data, double *A1_data, int64_t A2_nnz, int64_t n0_A2_rows, int32_t *A2_rows, int64_t n0_A2_cols, int32_t *A2_cols, int64_t n0_A2_data, double *A2_data, int64_t A2_nrows, int64_t A2_ncols, int64_t n0_rows, int64_t *rows, int64_t n0_cols, int64_t *cols, int64_t n0_data, double *data);
void bind_c_triu_kron_2(int64_t A1_nnz, int64_t n0_A1_rows, int32_t *A1_rows, int64_t n0_A1_cols, int32_t *A1_cols, int64_t n0_A1_data, double *A1_data, int64_t A2_nnz, int64_t n0_A2_rows, int32_t *A2_rows, int64_t n0_A2_cols, int32_t *A2_cols, int64_t n0_A2_data, double *A2_data, int64_t A2_nrows, int64_t A2_ncols, int64_t n0_rows, int64_t *rows, int64_t n0_cols, int64_t *cols, int64_t n0_data, double *data);
void bind_c_tril_kron_3(int64_t A1_nnz, int64_t n0_A1_rows, int32_t *A1_rows, int64_t n0_A1_cols, int32_t *A1_cols, int64_t n0_A1_data, double *A1_data, int64_t A2_nnz, int64_t n0_A2_rows, int32_t *A2_rows, int64_t n0_A2_cols, int32_t *A2_cols, int64_t n0_A2_data, double *A2_data, int64_t A3_nnz, int64_t n0_A3_rows, int32_t *A3_rows, int64_t n0_A3_cols, int32_t *A3_cols, int64_t n0_A3_data, double *A3_data, int64_t A2_nrows, int64_t A2_ncols, int64_t A3_nrows, int64_t A3_ncols, int64_t n0_rows, int64_t *rows, int64_t n0_cols, int64_t *cols, int64_t n0_data, double *data);
void bind_c_triu_kron_3(int64_t A1_nnz, int64_t n0_A1_rows, int32_t *A1_rows, int64_t n0_A1_cols, int32_t *A1_cols, int64_t n0_A1_data, double *A1_data, int64_t A2_nnz, int64_t n0_A2_rows, int32_t *A2_rows, int64_t n0_A2_cols, int32_t *A2_cols, int64_t n0_A2_data, double *A2_data, int64_t A3_nnz, int64_t n0_A3_rows, int32_t *A3_rows, int64_t n0_A3_cols, int32_t *A3_cols, int64_t n0_A3_data, double *A3_data, int64_t A2_nrows, int64_t A2_ncols, int64_t A3_nrows, int64_t A3_ncols, int64_t n0_rows, int64_t *rows, int64_t n0_cols, int64_t *cols, int64_t n0_data, double *data);
void bind_c_spsolve_kron_csr_2_lower(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_2_upper(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_3_lower(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_A3_data, double *A3_data, int64_t n0_A3_ind, int32_t *A3_ind, int64_t n0_A3_ptr, int32_t *A3_ptr, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_3_upper(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_A3_data, double *A3_data, int64_t n0_A3_ind, int32_t *A3_ind, int64_t n0_A3_ptr, int32_t *A3_ptr, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_2_sum_lower(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_B1_data, double *B1_data, int64_t n0_B1_ind, int32_t *B1_ind, int64_t n0_B1_ptr, int32_t *B1_ptr, int64_t n0_B2_data, double *B2_data, int64_t n0_B2_ind, int32_t *B2_ind, int64_t n0_B2_ptr, int32_t *B2_ptr, double alpha, double beta, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_2_sum_upper(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_B1_data, double *B1_data, int64_t n0_B1_ind, int32_t *B1_ind, int64_t n0_B1_ptr, int32_t *B1_ptr, int64_t n0_B2_data, double *B2_data, int64_t n0_B2_ind, int32_t *B2_ind, int64_t n0_B2_ptr, int32_t *B2_ptr, double alpha, double beta, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_3_sum_lower(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_A3_data, double *A3_data, int64_t n0_A3_ind, int32_t *A3_ind, int64_t n0_A3_ptr, int32_t *A3_ptr, int64_t n0_B1_data, double *B1_data, int64_t n0_B1_ind, int32_t *B1_ind, int64_t n0_B1_ptr, int32_t *B1_ptr, int64_t n0_B2_data, double *B2_data, int64_t n0_B2_ind, int32_t *B2_ind, int64_t n0_B2_ptr, int32_t *B2_ptr, int64_t n0_B3_data, double *B3_data, int64_t n0_B3_ind, int32_t *B3_ind, int64_t n0_B3_ptr, int32_t *B3_ptr, int64_t n0_C1_data, double *C1_data, int64_t n0_C1_ind, int32_t *C1_ind, int64_t n0_C1_ptr, int32_t *C1_ptr, int64_t n0_C2_data, double *C2_data, int64_t n0_C2_ind, int32_t *C2_ind, int64_t n0_C2_ptr, int32_t *C2_ptr, int64_t n0_C3_data, double *C3_data, int64_t n0_C3_ind, int32_t *C3_ind, int64_t n0_C3_ptr, int32_t *C3_ptr, double alpha, double beta, double gamma, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_3_sum_upper(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_A3_data, double *A3_data, int64_t n0_A3_ind, int32_t *A3_ind, int64_t n0_A3_ptr, int32_t *A3_ptr, int64_t n0_B1_data, double *B1_data, int64_t n0_B1_ind, int32_t *B1_ind, int64_t n0_B1_ptr, int32_t *B1_ptr, int64_t n0_B2_data, double *B2_data, int64_t n0_B2_ind, int32_t *B2_ind, int64_t n0_B2_ptr, int32_t *B2_ptr, int64_t n0_B3_data, double *B3_data, int64_t n0_B3_ind, int32_t *B3_ind, int64_t n0_B3_ptr, int32_t *B3_ptr, int64_t n0_C1_data, double *C1_data, int64_t n0_C1_ind, int32_t *C1_ind, int64_t n0_C1_ptr, int32_t *C1_ptr, int64_t n0_C2_data, double *C2_data, int64_t n0_C2_ind, int32_t *C2_ind, int64_t n0_C2_ptr, int32_t *C2_ptr, int64_t n0_C3_data, double *C3_data, int64_t n0_C3_ind, int32_t *C3_ind, int64_t n0_C3_ptr, int32_t *C3_ptr, double alpha, double beta, double gamma, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_23_sum_lower(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_B1_data, double *B1_data, int64_t n0_B1_ind, int32_t *B1_ind, int64_t n0_B1_ptr, int32_t *B1_ptr, int64_t n0_B2_data, double *B2_data, int64_t n0_B2_ind, int32_t *B2_ind, int64_t n0_B2_ptr, int32_t *B2_ptr, int64_t n0_C1_data, double *C1_data, int64_t n0_C1_ind, int32_t *C1_ind, int64_t n0_C1_ptr, int32_t *C1_ptr, int64_t n0_C2_data, double *C2_data, int64_t n0_C2_ind, int32_t *C2_ind, int64_t n0_C2_ptr, int32_t *C2_ptr, double alpha, double beta, double gamma, int64_t n0_b, double *b, int64_t n0_y, double *y);
void bind_c_spsolve_kron_csr_23_sum_upper(int64_t n0_A1_data, double *A1_data, int64_t n0_A1_ind, int32_t *A1_ind, int64_t n0_A1_ptr, int32_t *A1_ptr, int64_t n0_A2_data, double *A2_data, int64_t n0_A2_ind, int32_t *A2_ind, int64_t n0_A2_ptr, int32_t *A2_ptr, int64_t n0_B1_data, double *B1_data, int64_t n0_B1_ind, int32_t *B1_ind, int64_t n0_B1_ptr, int32_t *B1_ptr, int64_t n0_B2_data, double *B2_data, int64_t n0_B2_ind, int32_t *B2_ind, int64_t n0_B2_ptr, int32_t *B2_ptr, int64_t n0_C1_data, double *C1_data, int64_t n0_C1_ind, int32_t *C1_ind, int64_t n0_C1_ptr, int32_t *C1_ptr, int64_t n0_C2_data, double *C2_data, int64_t n0_C2_ind, int32_t *C2_ind, int64_t n0_C2_ptr, int32_t *C2_ptr, double alpha, double beta, double gamma, int64_t n0_b, double *b, int64_t n0_y, double *y);

/*........................................*/


/*........................................*/

/*........................................*/
PyObject *spsolve_dns_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray L = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *L_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "L",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!", kwlist, &PyArray_Type, &L_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(L_tmp, NPY_DOUBLE, 2, NPY_ARRAY_C_CONTIGUOUS))
    {
        return NULL;
    }
    else
    {
        L = pyarray_to_ndarray(L_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_dns_lower(nd_ndim(&L, 0), nd_ndim(&L, 1), nd_data(&L), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(L);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_dns_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray U = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *U_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "U",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!", kwlist, &PyArray_Type, &U_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(U_tmp, NPY_DOUBLE, 2, NPY_ARRAY_C_CONTIGUOUS))
    {
        return NULL;
    }
    else
    {
        U = pyarray_to_ndarray(U_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_dns_upper(nd_ndim(&U, 0), nd_ndim(&U, 1), nd_data(&U), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(U);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_csr_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A_data = {.shape = NULL};
    t_ndarray A_ind = {.shape = NULL};
    t_ndarray A_ptr = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A_data_tmp;
    PyArrayObject *A_ind_tmp;
    PyArrayObject *A_ptr_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A_data",
        "A_ind",
        "A_ptr",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!", kwlist, &PyArray_Type, &A_data_tmp, &PyArray_Type, &A_ind_tmp, &PyArray_Type, &A_ptr_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_data = pyarray_to_ndarray(A_data_tmp);
    }
    if (!pyarray_check(A_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_ind = pyarray_to_ndarray(A_ind_tmp);
    }
    if (!pyarray_check(A_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_ptr = pyarray_to_ndarray(A_ptr_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_csr_lower(nd_ndim(&A_data, 0), nd_data(&A_data), nd_ndim(&A_ind, 0), nd_data(&A_ind), nd_ndim(&A_ptr, 0), nd_data(&A_ptr), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A_data);
    free_pointer(A_ind);
    free_pointer(A_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_csr_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A_data = {.shape = NULL};
    t_ndarray A_ind = {.shape = NULL};
    t_ndarray A_ptr = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A_data_tmp;
    PyArrayObject *A_ind_tmp;
    PyArrayObject *A_ptr_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A_data",
        "A_ind",
        "A_ptr",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!", kwlist, &PyArray_Type, &A_data_tmp, &PyArray_Type, &A_ind_tmp, &PyArray_Type, &A_ptr_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_data = pyarray_to_ndarray(A_data_tmp);
    }
    if (!pyarray_check(A_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_ind = pyarray_to_ndarray(A_ind_tmp);
    }
    if (!pyarray_check(A_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_ptr = pyarray_to_ndarray(A_ptr_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_csr_upper(nd_ndim(&A_data, 0), nd_data(&A_data), nd_ndim(&A_ind, 0), nd_data(&A_ind), nd_ndim(&A_ptr, 0), nd_data(&A_ptr), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A_data);
    free_pointer(A_ind);
    free_pointer(A_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *tril_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A_rows = {.shape = NULL};
    t_ndarray A_cols = {.shape = NULL};
    t_ndarray A_data = {.shape = NULL};
    t_ndarray rows = {.shape = NULL};
    t_ndarray cols = {.shape = NULL};
    t_ndarray data = {.shape = NULL};
    PyArrayObject *A_rows_tmp;
    PyArrayObject *A_cols_tmp;
    PyArrayObject *A_data_tmp;
    PyArrayObject *rows_tmp;
    PyArrayObject *cols_tmp;
    PyArrayObject *data_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A_rows",
        "A_cols",
        "A_data",
        "rows",
        "cols",
        "data",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!", kwlist, &PyArray_Type, &A_rows_tmp, &PyArray_Type, &A_cols_tmp, &PyArray_Type, &A_data_tmp, &PyArray_Type, &rows_tmp, &PyArray_Type, &cols_tmp, &PyArray_Type, &data_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_rows = pyarray_to_ndarray(A_rows_tmp);
    }
    if (!pyarray_check(A_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_cols = pyarray_to_ndarray(A_cols_tmp);
    }
    if (!pyarray_check(A_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_data = pyarray_to_ndarray(A_data_tmp);
    }
    if (!pyarray_check(rows_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        rows = pyarray_to_ndarray(rows_tmp);
    }
    if (!pyarray_check(cols_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        cols = pyarray_to_ndarray(cols_tmp);
    }
    if (!pyarray_check(data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        data = pyarray_to_ndarray(data_tmp);
    }
    bind_c_tril(nd_ndim(&A_rows, 0), nd_data(&A_rows), nd_ndim(&A_cols, 0), nd_data(&A_cols), nd_ndim(&A_data, 0), nd_data(&A_data), nd_ndim(&rows, 0), nd_data(&rows), nd_ndim(&cols, 0), nd_data(&cols), nd_ndim(&data, 0), nd_data(&data));
    result = Py_BuildValue("");
    free_pointer(A_rows);
    free_pointer(A_cols);
    free_pointer(A_data);
    free_pointer(rows);
    free_pointer(cols);
    free_pointer(data);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *triu_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A_rows = {.shape = NULL};
    t_ndarray A_cols = {.shape = NULL};
    t_ndarray A_data = {.shape = NULL};
    t_ndarray rows = {.shape = NULL};
    t_ndarray cols = {.shape = NULL};
    t_ndarray data = {.shape = NULL};
    PyArrayObject *A_rows_tmp;
    PyArrayObject *A_cols_tmp;
    PyArrayObject *A_data_tmp;
    PyArrayObject *rows_tmp;
    PyArrayObject *cols_tmp;
    PyArrayObject *data_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A_rows",
        "A_cols",
        "A_data",
        "rows",
        "cols",
        "data",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!", kwlist, &PyArray_Type, &A_rows_tmp, &PyArray_Type, &A_cols_tmp, &PyArray_Type, &A_data_tmp, &PyArray_Type, &rows_tmp, &PyArray_Type, &cols_tmp, &PyArray_Type, &data_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_rows = pyarray_to_ndarray(A_rows_tmp);
    }
    if (!pyarray_check(A_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_cols = pyarray_to_ndarray(A_cols_tmp);
    }
    if (!pyarray_check(A_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A_data = pyarray_to_ndarray(A_data_tmp);
    }
    if (!pyarray_check(rows_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        rows = pyarray_to_ndarray(rows_tmp);
    }
    if (!pyarray_check(cols_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        cols = pyarray_to_ndarray(cols_tmp);
    }
    if (!pyarray_check(data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        data = pyarray_to_ndarray(data_tmp);
    }
    bind_c_triu(nd_ndim(&A_rows, 0), nd_data(&A_rows), nd_ndim(&A_cols, 0), nd_data(&A_cols), nd_ndim(&A_data, 0), nd_data(&A_data), nd_ndim(&rows, 0), nd_data(&rows), nd_ndim(&cols, 0), nd_data(&cols), nd_ndim(&data, 0), nd_data(&data));
    result = Py_BuildValue("");
    free_pointer(A_rows);
    free_pointer(A_cols);
    free_pointer(A_data);
    free_pointer(rows);
    free_pointer(cols);
    free_pointer(data);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *tril_kron_2_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int64_t A1_nnz;
    t_ndarray A1_rows = {.shape = NULL};
    t_ndarray A1_cols = {.shape = NULL};
    t_ndarray A1_data = {.shape = NULL};
    int64_t A2_nnz;
    t_ndarray A2_rows = {.shape = NULL};
    t_ndarray A2_cols = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    int64_t A2_nrows;
    int64_t A2_ncols;
    t_ndarray rows = {.shape = NULL};
    t_ndarray cols = {.shape = NULL};
    t_ndarray data = {.shape = NULL};
    PyObject *A1_nnz_tmp;
    PyArrayObject *A1_rows_tmp;
    PyArrayObject *A1_cols_tmp;
    PyArrayObject *A1_data_tmp;
    PyObject *A2_nnz_tmp;
    PyArrayObject *A2_rows_tmp;
    PyArrayObject *A2_cols_tmp;
    PyArrayObject *A2_data_tmp;
    PyObject *A2_nrows_tmp;
    PyObject *A2_ncols_tmp;
    PyArrayObject *rows_tmp;
    PyArrayObject *cols_tmp;
    PyArrayObject *data_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_nnz",
        "A1_rows",
        "A1_cols",
        "A1_data",
        "A2_nnz",
        "A2_rows",
        "A2_cols",
        "A2_data",
        "A2_nrows",
        "A2_ncols",
        "rows",
        "cols",
        "data",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "OO!O!O!OO!O!O!OOO!O!O!", kwlist, &A1_nnz_tmp, &PyArray_Type, &A1_rows_tmp, &PyArray_Type, &A1_cols_tmp, &PyArray_Type, &A1_data_tmp, &A2_nnz_tmp, &PyArray_Type, &A2_rows_tmp, &PyArray_Type, &A2_cols_tmp, &PyArray_Type, &A2_data_tmp, &A2_nrows_tmp, &A2_ncols_tmp, &PyArray_Type, &rows_tmp, &PyArray_Type, &cols_tmp, &PyArray_Type, &data_tmp))
    {
        return NULL;
    }
    if (PyIs_NativeInt(A1_nnz_tmp))
    {
        A1_nnz = PyInt64_to_Int64(A1_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A1_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_rows = pyarray_to_ndarray(A1_rows_tmp);
    }
    if (!pyarray_check(A1_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_cols = pyarray_to_ndarray(A1_cols_tmp);
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (PyIs_NativeInt(A2_nnz_tmp))
    {
        A2_nnz = PyInt64_to_Int64(A2_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A2_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_rows = pyarray_to_ndarray(A2_rows_tmp);
    }
    if (!pyarray_check(A2_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_cols = pyarray_to_ndarray(A2_cols_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (PyIs_NativeInt(A2_nrows_tmp))
    {
        A2_nrows = PyInt64_to_Int64(A2_nrows_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A2_ncols_tmp))
    {
        A2_ncols = PyInt64_to_Int64(A2_ncols_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(rows_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        rows = pyarray_to_ndarray(rows_tmp);
    }
    if (!pyarray_check(cols_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        cols = pyarray_to_ndarray(cols_tmp);
    }
    if (!pyarray_check(data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        data = pyarray_to_ndarray(data_tmp);
    }
    bind_c_tril_kron_2(A1_nnz, nd_ndim(&A1_rows, 0), nd_data(&A1_rows), nd_ndim(&A1_cols, 0), nd_data(&A1_cols), nd_ndim(&A1_data, 0), nd_data(&A1_data), A2_nnz, nd_ndim(&A2_rows, 0), nd_data(&A2_rows), nd_ndim(&A2_cols, 0), nd_data(&A2_cols), nd_ndim(&A2_data, 0), nd_data(&A2_data), A2_nrows, A2_ncols, nd_ndim(&rows, 0), nd_data(&rows), nd_ndim(&cols, 0), nd_data(&cols), nd_ndim(&data, 0), nd_data(&data));
    result = Py_BuildValue("");
    free_pointer(A1_rows);
    free_pointer(A1_cols);
    free_pointer(A1_data);
    free_pointer(A2_rows);
    free_pointer(A2_cols);
    free_pointer(A2_data);
    free_pointer(rows);
    free_pointer(cols);
    free_pointer(data);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *triu_kron_2_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int64_t A1_nnz;
    t_ndarray A1_rows = {.shape = NULL};
    t_ndarray A1_cols = {.shape = NULL};
    t_ndarray A1_data = {.shape = NULL};
    int64_t A2_nnz;
    t_ndarray A2_rows = {.shape = NULL};
    t_ndarray A2_cols = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    int64_t A2_nrows;
    int64_t A2_ncols;
    t_ndarray rows = {.shape = NULL};
    t_ndarray cols = {.shape = NULL};
    t_ndarray data = {.shape = NULL};
    PyObject *A1_nnz_tmp;
    PyArrayObject *A1_rows_tmp;
    PyArrayObject *A1_cols_tmp;
    PyArrayObject *A1_data_tmp;
    PyObject *A2_nnz_tmp;
    PyArrayObject *A2_rows_tmp;
    PyArrayObject *A2_cols_tmp;
    PyArrayObject *A2_data_tmp;
    PyObject *A2_nrows_tmp;
    PyObject *A2_ncols_tmp;
    PyArrayObject *rows_tmp;
    PyArrayObject *cols_tmp;
    PyArrayObject *data_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_nnz",
        "A1_rows",
        "A1_cols",
        "A1_data",
        "A2_nnz",
        "A2_rows",
        "A2_cols",
        "A2_data",
        "A2_nrows",
        "A2_ncols",
        "rows",
        "cols",
        "data",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "OO!O!O!OO!O!O!OOO!O!O!", kwlist, &A1_nnz_tmp, &PyArray_Type, &A1_rows_tmp, &PyArray_Type, &A1_cols_tmp, &PyArray_Type, &A1_data_tmp, &A2_nnz_tmp, &PyArray_Type, &A2_rows_tmp, &PyArray_Type, &A2_cols_tmp, &PyArray_Type, &A2_data_tmp, &A2_nrows_tmp, &A2_ncols_tmp, &PyArray_Type, &rows_tmp, &PyArray_Type, &cols_tmp, &PyArray_Type, &data_tmp))
    {
        return NULL;
    }
    if (PyIs_NativeInt(A1_nnz_tmp))
    {
        A1_nnz = PyInt64_to_Int64(A1_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A1_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_rows = pyarray_to_ndarray(A1_rows_tmp);
    }
    if (!pyarray_check(A1_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_cols = pyarray_to_ndarray(A1_cols_tmp);
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (PyIs_NativeInt(A2_nnz_tmp))
    {
        A2_nnz = PyInt64_to_Int64(A2_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A2_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_rows = pyarray_to_ndarray(A2_rows_tmp);
    }
    if (!pyarray_check(A2_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_cols = pyarray_to_ndarray(A2_cols_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (PyIs_NativeInt(A2_nrows_tmp))
    {
        A2_nrows = PyInt64_to_Int64(A2_nrows_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A2_ncols_tmp))
    {
        A2_ncols = PyInt64_to_Int64(A2_ncols_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(rows_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        rows = pyarray_to_ndarray(rows_tmp);
    }
    if (!pyarray_check(cols_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        cols = pyarray_to_ndarray(cols_tmp);
    }
    if (!pyarray_check(data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        data = pyarray_to_ndarray(data_tmp);
    }
    bind_c_triu_kron_2(A1_nnz, nd_ndim(&A1_rows, 0), nd_data(&A1_rows), nd_ndim(&A1_cols, 0), nd_data(&A1_cols), nd_ndim(&A1_data, 0), nd_data(&A1_data), A2_nnz, nd_ndim(&A2_rows, 0), nd_data(&A2_rows), nd_ndim(&A2_cols, 0), nd_data(&A2_cols), nd_ndim(&A2_data, 0), nd_data(&A2_data), A2_nrows, A2_ncols, nd_ndim(&rows, 0), nd_data(&rows), nd_ndim(&cols, 0), nd_data(&cols), nd_ndim(&data, 0), nd_data(&data));
    result = Py_BuildValue("");
    free_pointer(A1_rows);
    free_pointer(A1_cols);
    free_pointer(A1_data);
    free_pointer(A2_rows);
    free_pointer(A2_cols);
    free_pointer(A2_data);
    free_pointer(rows);
    free_pointer(cols);
    free_pointer(data);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *tril_kron_3_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int64_t A1_nnz;
    t_ndarray A1_rows = {.shape = NULL};
    t_ndarray A1_cols = {.shape = NULL};
    t_ndarray A1_data = {.shape = NULL};
    int64_t A2_nnz;
    t_ndarray A2_rows = {.shape = NULL};
    t_ndarray A2_cols = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    int64_t A3_nnz;
    t_ndarray A3_rows = {.shape = NULL};
    t_ndarray A3_cols = {.shape = NULL};
    t_ndarray A3_data = {.shape = NULL};
    int64_t A2_nrows;
    int64_t A2_ncols;
    int64_t A3_nrows;
    int64_t A3_ncols;
    t_ndarray rows = {.shape = NULL};
    t_ndarray cols = {.shape = NULL};
    t_ndarray data = {.shape = NULL};
    PyObject *A1_nnz_tmp;
    PyArrayObject *A1_rows_tmp;
    PyArrayObject *A1_cols_tmp;
    PyArrayObject *A1_data_tmp;
    PyObject *A2_nnz_tmp;
    PyArrayObject *A2_rows_tmp;
    PyArrayObject *A2_cols_tmp;
    PyArrayObject *A2_data_tmp;
    PyObject *A3_nnz_tmp;
    PyArrayObject *A3_rows_tmp;
    PyArrayObject *A3_cols_tmp;
    PyArrayObject *A3_data_tmp;
    PyObject *A2_nrows_tmp;
    PyObject *A2_ncols_tmp;
    PyObject *A3_nrows_tmp;
    PyObject *A3_ncols_tmp;
    PyArrayObject *rows_tmp;
    PyArrayObject *cols_tmp;
    PyArrayObject *data_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_nnz",
        "A1_rows",
        "A1_cols",
        "A1_data",
        "A2_nnz",
        "A2_rows",
        "A2_cols",
        "A2_data",
        "A3_nnz",
        "A3_rows",
        "A3_cols",
        "A3_data",
        "A2_nrows",
        "A2_ncols",
        "A3_nrows",
        "A3_ncols",
        "rows",
        "cols",
        "data",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "OO!O!O!OO!O!O!OO!O!O!OOOOO!O!O!", kwlist, &A1_nnz_tmp, &PyArray_Type, &A1_rows_tmp, &PyArray_Type, &A1_cols_tmp, &PyArray_Type, &A1_data_tmp, &A2_nnz_tmp, &PyArray_Type, &A2_rows_tmp, &PyArray_Type, &A2_cols_tmp, &PyArray_Type, &A2_data_tmp, &A3_nnz_tmp, &PyArray_Type, &A3_rows_tmp, &PyArray_Type, &A3_cols_tmp, &PyArray_Type, &A3_data_tmp, &A2_nrows_tmp, &A2_ncols_tmp, &A3_nrows_tmp, &A3_ncols_tmp, &PyArray_Type, &rows_tmp, &PyArray_Type, &cols_tmp, &PyArray_Type, &data_tmp))
    {
        return NULL;
    }
    if (PyIs_NativeInt(A1_nnz_tmp))
    {
        A1_nnz = PyInt64_to_Int64(A1_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A1_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_rows = pyarray_to_ndarray(A1_rows_tmp);
    }
    if (!pyarray_check(A1_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_cols = pyarray_to_ndarray(A1_cols_tmp);
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (PyIs_NativeInt(A2_nnz_tmp))
    {
        A2_nnz = PyInt64_to_Int64(A2_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A2_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_rows = pyarray_to_ndarray(A2_rows_tmp);
    }
    if (!pyarray_check(A2_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_cols = pyarray_to_ndarray(A2_cols_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (PyIs_NativeInt(A3_nnz_tmp))
    {
        A3_nnz = PyInt64_to_Int64(A3_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A3_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_rows = pyarray_to_ndarray(A3_rows_tmp);
    }
    if (!pyarray_check(A3_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_cols = pyarray_to_ndarray(A3_cols_tmp);
    }
    if (!pyarray_check(A3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_data = pyarray_to_ndarray(A3_data_tmp);
    }
    if (PyIs_NativeInt(A2_nrows_tmp))
    {
        A2_nrows = PyInt64_to_Int64(A2_nrows_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A2_ncols_tmp))
    {
        A2_ncols = PyInt64_to_Int64(A2_ncols_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A3_nrows_tmp))
    {
        A3_nrows = PyInt64_to_Int64(A3_nrows_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A3_ncols_tmp))
    {
        A3_ncols = PyInt64_to_Int64(A3_ncols_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(rows_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        rows = pyarray_to_ndarray(rows_tmp);
    }
    if (!pyarray_check(cols_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        cols = pyarray_to_ndarray(cols_tmp);
    }
    if (!pyarray_check(data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        data = pyarray_to_ndarray(data_tmp);
    }
    bind_c_tril_kron_3(A1_nnz, nd_ndim(&A1_rows, 0), nd_data(&A1_rows), nd_ndim(&A1_cols, 0), nd_data(&A1_cols), nd_ndim(&A1_data, 0), nd_data(&A1_data), A2_nnz, nd_ndim(&A2_rows, 0), nd_data(&A2_rows), nd_ndim(&A2_cols, 0), nd_data(&A2_cols), nd_ndim(&A2_data, 0), nd_data(&A2_data), A3_nnz, nd_ndim(&A3_rows, 0), nd_data(&A3_rows), nd_ndim(&A3_cols, 0), nd_data(&A3_cols), nd_ndim(&A3_data, 0), nd_data(&A3_data), A2_nrows, A2_ncols, A3_nrows, A3_ncols, nd_ndim(&rows, 0), nd_data(&rows), nd_ndim(&cols, 0), nd_data(&cols), nd_ndim(&data, 0), nd_data(&data));
    result = Py_BuildValue("");
    free_pointer(A1_rows);
    free_pointer(A1_cols);
    free_pointer(A1_data);
    free_pointer(A2_rows);
    free_pointer(A2_cols);
    free_pointer(A2_data);
    free_pointer(A3_rows);
    free_pointer(A3_cols);
    free_pointer(A3_data);
    free_pointer(rows);
    free_pointer(cols);
    free_pointer(data);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *triu_kron_3_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int64_t A1_nnz;
    t_ndarray A1_rows = {.shape = NULL};
    t_ndarray A1_cols = {.shape = NULL};
    t_ndarray A1_data = {.shape = NULL};
    int64_t A2_nnz;
    t_ndarray A2_rows = {.shape = NULL};
    t_ndarray A2_cols = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    int64_t A3_nnz;
    t_ndarray A3_rows = {.shape = NULL};
    t_ndarray A3_cols = {.shape = NULL};
    t_ndarray A3_data = {.shape = NULL};
    int64_t A2_nrows;
    int64_t A2_ncols;
    int64_t A3_nrows;
    int64_t A3_ncols;
    t_ndarray rows = {.shape = NULL};
    t_ndarray cols = {.shape = NULL};
    t_ndarray data = {.shape = NULL};
    PyObject *A1_nnz_tmp;
    PyArrayObject *A1_rows_tmp;
    PyArrayObject *A1_cols_tmp;
    PyArrayObject *A1_data_tmp;
    PyObject *A2_nnz_tmp;
    PyArrayObject *A2_rows_tmp;
    PyArrayObject *A2_cols_tmp;
    PyArrayObject *A2_data_tmp;
    PyObject *A3_nnz_tmp;
    PyArrayObject *A3_rows_tmp;
    PyArrayObject *A3_cols_tmp;
    PyArrayObject *A3_data_tmp;
    PyObject *A2_nrows_tmp;
    PyObject *A2_ncols_tmp;
    PyObject *A3_nrows_tmp;
    PyObject *A3_ncols_tmp;
    PyArrayObject *rows_tmp;
    PyArrayObject *cols_tmp;
    PyArrayObject *data_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_nnz",
        "A1_rows",
        "A1_cols",
        "A1_data",
        "A2_nnz",
        "A2_rows",
        "A2_cols",
        "A2_data",
        "A3_nnz",
        "A3_rows",
        "A3_cols",
        "A3_data",
        "A2_nrows",
        "A2_ncols",
        "A3_nrows",
        "A3_ncols",
        "rows",
        "cols",
        "data",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "OO!O!O!OO!O!O!OO!O!O!OOOOO!O!O!", kwlist, &A1_nnz_tmp, &PyArray_Type, &A1_rows_tmp, &PyArray_Type, &A1_cols_tmp, &PyArray_Type, &A1_data_tmp, &A2_nnz_tmp, &PyArray_Type, &A2_rows_tmp, &PyArray_Type, &A2_cols_tmp, &PyArray_Type, &A2_data_tmp, &A3_nnz_tmp, &PyArray_Type, &A3_rows_tmp, &PyArray_Type, &A3_cols_tmp, &PyArray_Type, &A3_data_tmp, &A2_nrows_tmp, &A2_ncols_tmp, &A3_nrows_tmp, &A3_ncols_tmp, &PyArray_Type, &rows_tmp, &PyArray_Type, &cols_tmp, &PyArray_Type, &data_tmp))
    {
        return NULL;
    }
    if (PyIs_NativeInt(A1_nnz_tmp))
    {
        A1_nnz = PyInt64_to_Int64(A1_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A1_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_rows = pyarray_to_ndarray(A1_rows_tmp);
    }
    if (!pyarray_check(A1_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_cols = pyarray_to_ndarray(A1_cols_tmp);
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (PyIs_NativeInt(A2_nnz_tmp))
    {
        A2_nnz = PyInt64_to_Int64(A2_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A2_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_rows = pyarray_to_ndarray(A2_rows_tmp);
    }
    if (!pyarray_check(A2_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_cols = pyarray_to_ndarray(A2_cols_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (PyIs_NativeInt(A3_nnz_tmp))
    {
        A3_nnz = PyInt64_to_Int64(A3_nnz_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(A3_rows_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_rows = pyarray_to_ndarray(A3_rows_tmp);
    }
    if (!pyarray_check(A3_cols_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_cols = pyarray_to_ndarray(A3_cols_tmp);
    }
    if (!pyarray_check(A3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_data = pyarray_to_ndarray(A3_data_tmp);
    }
    if (PyIs_NativeInt(A2_nrows_tmp))
    {
        A2_nrows = PyInt64_to_Int64(A2_nrows_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A2_ncols_tmp))
    {
        A2_ncols = PyInt64_to_Int64(A2_ncols_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A3_nrows_tmp))
    {
        A3_nrows = PyInt64_to_Int64(A3_nrows_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (PyIs_NativeInt(A3_ncols_tmp))
    {
        A3_ncols = PyInt64_to_Int64(A3_ncols_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native int\"");
        return NULL;
    }
    if (!pyarray_check(rows_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        rows = pyarray_to_ndarray(rows_tmp);
    }
    if (!pyarray_check(cols_tmp, NPY_LONG, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        cols = pyarray_to_ndarray(cols_tmp);
    }
    if (!pyarray_check(data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        data = pyarray_to_ndarray(data_tmp);
    }
    bind_c_triu_kron_3(A1_nnz, nd_ndim(&A1_rows, 0), nd_data(&A1_rows), nd_ndim(&A1_cols, 0), nd_data(&A1_cols), nd_ndim(&A1_data, 0), nd_data(&A1_data), A2_nnz, nd_ndim(&A2_rows, 0), nd_data(&A2_rows), nd_ndim(&A2_cols, 0), nd_data(&A2_cols), nd_ndim(&A2_data, 0), nd_data(&A2_data), A3_nnz, nd_ndim(&A3_rows, 0), nd_data(&A3_rows), nd_ndim(&A3_cols, 0), nd_data(&A3_cols), nd_ndim(&A3_data, 0), nd_data(&A3_data), A2_nrows, A2_ncols, A3_nrows, A3_ncols, nd_ndim(&rows, 0), nd_data(&rows), nd_ndim(&cols, 0), nd_data(&cols), nd_ndim(&data, 0), nd_data(&data));
    result = Py_BuildValue("");
    free_pointer(A1_rows);
    free_pointer(A1_cols);
    free_pointer(A1_data);
    free_pointer(A2_rows);
    free_pointer(A2_cols);
    free_pointer(A2_data);
    free_pointer(A3_rows);
    free_pointer(A3_cols);
    free_pointer(A3_data);
    free_pointer(rows);
    free_pointer(cols);
    free_pointer(data);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_2_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_2_lower(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_2_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_2_upper(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_3_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray A3_data = {.shape = NULL};
    t_ndarray A3_ind = {.shape = NULL};
    t_ndarray A3_ptr = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *A3_data_tmp;
    PyArrayObject *A3_ind_tmp;
    PyArrayObject *A3_ptr_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "A3_data",
        "A3_ind",
        "A3_ptr",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &A3_data_tmp, &PyArray_Type, &A3_ind_tmp, &PyArray_Type, &A3_ptr_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(A3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_data = pyarray_to_ndarray(A3_data_tmp);
    }
    if (!pyarray_check(A3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ind = pyarray_to_ndarray(A3_ind_tmp);
    }
    if (!pyarray_check(A3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ptr = pyarray_to_ndarray(A3_ptr_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_3_lower(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&A3_data, 0), nd_data(&A3_data), nd_ndim(&A3_ind, 0), nd_data(&A3_ind), nd_ndim(&A3_ptr, 0), nd_data(&A3_ptr), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(A3_data);
    free_pointer(A3_ind);
    free_pointer(A3_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_3_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray A3_data = {.shape = NULL};
    t_ndarray A3_ind = {.shape = NULL};
    t_ndarray A3_ptr = {.shape = NULL};
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *A3_data_tmp;
    PyArrayObject *A3_ind_tmp;
    PyArrayObject *A3_ptr_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "A3_data",
        "A3_ind",
        "A3_ptr",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &A3_data_tmp, &PyArray_Type, &A3_ind_tmp, &PyArray_Type, &A3_ptr_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(A3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_data = pyarray_to_ndarray(A3_data_tmp);
    }
    if (!pyarray_check(A3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ind = pyarray_to_ndarray(A3_ind_tmp);
    }
    if (!pyarray_check(A3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ptr = pyarray_to_ndarray(A3_ptr_tmp);
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_3_upper(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&A3_data, 0), nd_data(&A3_data), nd_ndim(&A3_ind, 0), nd_data(&A3_ind), nd_ndim(&A3_ptr, 0), nd_data(&A3_ptr), nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(A3_data);
    free_pointer(A3_ind);
    free_pointer(A3_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_2_sum_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray B1_data = {.shape = NULL};
    t_ndarray B1_ind = {.shape = NULL};
    t_ndarray B1_ptr = {.shape = NULL};
    t_ndarray B2_data = {.shape = NULL};
    t_ndarray B2_ind = {.shape = NULL};
    t_ndarray B2_ptr = {.shape = NULL};
    double alpha;
    double beta;
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *B1_data_tmp;
    PyArrayObject *B1_ind_tmp;
    PyArrayObject *B1_ptr_tmp;
    PyArrayObject *B2_data_tmp;
    PyArrayObject *B2_ind_tmp;
    PyArrayObject *B2_ptr_tmp;
    PyObject *alpha_tmp;
    PyObject *beta_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "B1_data",
        "B1_ind",
        "B1_ptr",
        "B2_data",
        "B2_ind",
        "B2_ptr",
        "alpha",
        "beta",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!O!OOO!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &B1_data_tmp, &PyArray_Type, &B1_ind_tmp, &PyArray_Type, &B1_ptr_tmp, &PyArray_Type, &B2_data_tmp, &PyArray_Type, &B2_ind_tmp, &PyArray_Type, &B2_ptr_tmp, &alpha_tmp, &beta_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(B1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_data = pyarray_to_ndarray(B1_data_tmp);
    }
    if (!pyarray_check(B1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ind = pyarray_to_ndarray(B1_ind_tmp);
    }
    if (!pyarray_check(B1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ptr = pyarray_to_ndarray(B1_ptr_tmp);
    }
    if (!pyarray_check(B2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_data = pyarray_to_ndarray(B2_data_tmp);
    }
    if (!pyarray_check(B2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ind = pyarray_to_ndarray(B2_ind_tmp);
    }
    if (!pyarray_check(B2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ptr = pyarray_to_ndarray(B2_ptr_tmp);
    }
    if (PyIs_NativeFloat(alpha_tmp))
    {
        alpha = PyDouble_to_Double(alpha_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(beta_tmp))
    {
        beta = PyDouble_to_Double(beta_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_2_sum_lower(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&B1_data, 0), nd_data(&B1_data), nd_ndim(&B1_ind, 0), nd_data(&B1_ind), nd_ndim(&B1_ptr, 0), nd_data(&B1_ptr), nd_ndim(&B2_data, 0), nd_data(&B2_data), nd_ndim(&B2_ind, 0), nd_data(&B2_ind), nd_ndim(&B2_ptr, 0), nd_data(&B2_ptr), alpha, beta, nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(B1_data);
    free_pointer(B1_ind);
    free_pointer(B1_ptr);
    free_pointer(B2_data);
    free_pointer(B2_ind);
    free_pointer(B2_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_2_sum_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray B1_data = {.shape = NULL};
    t_ndarray B1_ind = {.shape = NULL};
    t_ndarray B1_ptr = {.shape = NULL};
    t_ndarray B2_data = {.shape = NULL};
    t_ndarray B2_ind = {.shape = NULL};
    t_ndarray B2_ptr = {.shape = NULL};
    double alpha;
    double beta;
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *B1_data_tmp;
    PyArrayObject *B1_ind_tmp;
    PyArrayObject *B1_ptr_tmp;
    PyArrayObject *B2_data_tmp;
    PyArrayObject *B2_ind_tmp;
    PyArrayObject *B2_ptr_tmp;
    PyObject *alpha_tmp;
    PyObject *beta_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "B1_data",
        "B1_ind",
        "B1_ptr",
        "B2_data",
        "B2_ind",
        "B2_ptr",
        "alpha",
        "beta",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!O!OOO!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &B1_data_tmp, &PyArray_Type, &B1_ind_tmp, &PyArray_Type, &B1_ptr_tmp, &PyArray_Type, &B2_data_tmp, &PyArray_Type, &B2_ind_tmp, &PyArray_Type, &B2_ptr_tmp, &alpha_tmp, &beta_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(B1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_data = pyarray_to_ndarray(B1_data_tmp);
    }
    if (!pyarray_check(B1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ind = pyarray_to_ndarray(B1_ind_tmp);
    }
    if (!pyarray_check(B1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ptr = pyarray_to_ndarray(B1_ptr_tmp);
    }
    if (!pyarray_check(B2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_data = pyarray_to_ndarray(B2_data_tmp);
    }
    if (!pyarray_check(B2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ind = pyarray_to_ndarray(B2_ind_tmp);
    }
    if (!pyarray_check(B2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ptr = pyarray_to_ndarray(B2_ptr_tmp);
    }
    if (PyIs_NativeFloat(alpha_tmp))
    {
        alpha = PyDouble_to_Double(alpha_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(beta_tmp))
    {
        beta = PyDouble_to_Double(beta_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_2_sum_upper(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&B1_data, 0), nd_data(&B1_data), nd_ndim(&B1_ind, 0), nd_data(&B1_ind), nd_ndim(&B1_ptr, 0), nd_data(&B1_ptr), nd_ndim(&B2_data, 0), nd_data(&B2_data), nd_ndim(&B2_ind, 0), nd_data(&B2_ind), nd_ndim(&B2_ptr, 0), nd_data(&B2_ptr), alpha, beta, nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(B1_data);
    free_pointer(B1_ind);
    free_pointer(B1_ptr);
    free_pointer(B2_data);
    free_pointer(B2_ind);
    free_pointer(B2_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_3_sum_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray A3_data = {.shape = NULL};
    t_ndarray A3_ind = {.shape = NULL};
    t_ndarray A3_ptr = {.shape = NULL};
    t_ndarray B1_data = {.shape = NULL};
    t_ndarray B1_ind = {.shape = NULL};
    t_ndarray B1_ptr = {.shape = NULL};
    t_ndarray B2_data = {.shape = NULL};
    t_ndarray B2_ind = {.shape = NULL};
    t_ndarray B2_ptr = {.shape = NULL};
    t_ndarray B3_data = {.shape = NULL};
    t_ndarray B3_ind = {.shape = NULL};
    t_ndarray B3_ptr = {.shape = NULL};
    t_ndarray C1_data = {.shape = NULL};
    t_ndarray C1_ind = {.shape = NULL};
    t_ndarray C1_ptr = {.shape = NULL};
    t_ndarray C2_data = {.shape = NULL};
    t_ndarray C2_ind = {.shape = NULL};
    t_ndarray C2_ptr = {.shape = NULL};
    t_ndarray C3_data = {.shape = NULL};
    t_ndarray C3_ind = {.shape = NULL};
    t_ndarray C3_ptr = {.shape = NULL};
    double alpha;
    double beta;
    double gamma;
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *A3_data_tmp;
    PyArrayObject *A3_ind_tmp;
    PyArrayObject *A3_ptr_tmp;
    PyArrayObject *B1_data_tmp;
    PyArrayObject *B1_ind_tmp;
    PyArrayObject *B1_ptr_tmp;
    PyArrayObject *B2_data_tmp;
    PyArrayObject *B2_ind_tmp;
    PyArrayObject *B2_ptr_tmp;
    PyArrayObject *B3_data_tmp;
    PyArrayObject *B3_ind_tmp;
    PyArrayObject *B3_ptr_tmp;
    PyArrayObject *C1_data_tmp;
    PyArrayObject *C1_ind_tmp;
    PyArrayObject *C1_ptr_tmp;
    PyArrayObject *C2_data_tmp;
    PyArrayObject *C2_ind_tmp;
    PyArrayObject *C2_ptr_tmp;
    PyArrayObject *C3_data_tmp;
    PyArrayObject *C3_ind_tmp;
    PyArrayObject *C3_ptr_tmp;
    PyObject *alpha_tmp;
    PyObject *beta_tmp;
    PyObject *gamma_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "A3_data",
        "A3_ind",
        "A3_ptr",
        "B1_data",
        "B1_ind",
        "B1_ptr",
        "B2_data",
        "B2_ind",
        "B2_ptr",
        "B3_data",
        "B3_ind",
        "B3_ptr",
        "C1_data",
        "C1_ind",
        "C1_ptr",
        "C2_data",
        "C2_ind",
        "C2_ptr",
        "C3_data",
        "C3_ind",
        "C3_ptr",
        "alpha",
        "beta",
        "gamma",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!OOOO!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &A3_data_tmp, &PyArray_Type, &A3_ind_tmp, &PyArray_Type, &A3_ptr_tmp, &PyArray_Type, &B1_data_tmp, &PyArray_Type, &B1_ind_tmp, &PyArray_Type, &B1_ptr_tmp, &PyArray_Type, &B2_data_tmp, &PyArray_Type, &B2_ind_tmp, &PyArray_Type, &B2_ptr_tmp, &PyArray_Type, &B3_data_tmp, &PyArray_Type, &B3_ind_tmp, &PyArray_Type, &B3_ptr_tmp, &PyArray_Type, &C1_data_tmp, &PyArray_Type, &C1_ind_tmp, &PyArray_Type, &C1_ptr_tmp, &PyArray_Type, &C2_data_tmp, &PyArray_Type, &C2_ind_tmp, &PyArray_Type, &C2_ptr_tmp, &PyArray_Type, &C3_data_tmp, &PyArray_Type, &C3_ind_tmp, &PyArray_Type, &C3_ptr_tmp, &alpha_tmp, &beta_tmp, &gamma_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(A3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_data = pyarray_to_ndarray(A3_data_tmp);
    }
    if (!pyarray_check(A3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ind = pyarray_to_ndarray(A3_ind_tmp);
    }
    if (!pyarray_check(A3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ptr = pyarray_to_ndarray(A3_ptr_tmp);
    }
    if (!pyarray_check(B1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_data = pyarray_to_ndarray(B1_data_tmp);
    }
    if (!pyarray_check(B1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ind = pyarray_to_ndarray(B1_ind_tmp);
    }
    if (!pyarray_check(B1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ptr = pyarray_to_ndarray(B1_ptr_tmp);
    }
    if (!pyarray_check(B2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_data = pyarray_to_ndarray(B2_data_tmp);
    }
    if (!pyarray_check(B2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ind = pyarray_to_ndarray(B2_ind_tmp);
    }
    if (!pyarray_check(B2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ptr = pyarray_to_ndarray(B2_ptr_tmp);
    }
    if (!pyarray_check(B3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B3_data = pyarray_to_ndarray(B3_data_tmp);
    }
    if (!pyarray_check(B3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B3_ind = pyarray_to_ndarray(B3_ind_tmp);
    }
    if (!pyarray_check(B3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B3_ptr = pyarray_to_ndarray(B3_ptr_tmp);
    }
    if (!pyarray_check(C1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_data = pyarray_to_ndarray(C1_data_tmp);
    }
    if (!pyarray_check(C1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ind = pyarray_to_ndarray(C1_ind_tmp);
    }
    if (!pyarray_check(C1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ptr = pyarray_to_ndarray(C1_ptr_tmp);
    }
    if (!pyarray_check(C2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_data = pyarray_to_ndarray(C2_data_tmp);
    }
    if (!pyarray_check(C2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ind = pyarray_to_ndarray(C2_ind_tmp);
    }
    if (!pyarray_check(C2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ptr = pyarray_to_ndarray(C2_ptr_tmp);
    }
    if (!pyarray_check(C3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C3_data = pyarray_to_ndarray(C3_data_tmp);
    }
    if (!pyarray_check(C3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C3_ind = pyarray_to_ndarray(C3_ind_tmp);
    }
    if (!pyarray_check(C3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C3_ptr = pyarray_to_ndarray(C3_ptr_tmp);
    }
    if (PyIs_NativeFloat(alpha_tmp))
    {
        alpha = PyDouble_to_Double(alpha_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(beta_tmp))
    {
        beta = PyDouble_to_Double(beta_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(gamma_tmp))
    {
        gamma = PyDouble_to_Double(gamma_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_3_sum_lower(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&A3_data, 0), nd_data(&A3_data), nd_ndim(&A3_ind, 0), nd_data(&A3_ind), nd_ndim(&A3_ptr, 0), nd_data(&A3_ptr), nd_ndim(&B1_data, 0), nd_data(&B1_data), nd_ndim(&B1_ind, 0), nd_data(&B1_ind), nd_ndim(&B1_ptr, 0), nd_data(&B1_ptr), nd_ndim(&B2_data, 0), nd_data(&B2_data), nd_ndim(&B2_ind, 0), nd_data(&B2_ind), nd_ndim(&B2_ptr, 0), nd_data(&B2_ptr), nd_ndim(&B3_data, 0), nd_data(&B3_data), nd_ndim(&B3_ind, 0), nd_data(&B3_ind), nd_ndim(&B3_ptr, 0), nd_data(&B3_ptr), nd_ndim(&C1_data, 0), nd_data(&C1_data), nd_ndim(&C1_ind, 0), nd_data(&C1_ind), nd_ndim(&C1_ptr, 0), nd_data(&C1_ptr), nd_ndim(&C2_data, 0), nd_data(&C2_data), nd_ndim(&C2_ind, 0), nd_data(&C2_ind), nd_ndim(&C2_ptr, 0), nd_data(&C2_ptr), nd_ndim(&C3_data, 0), nd_data(&C3_data), nd_ndim(&C3_ind, 0), nd_data(&C3_ind), nd_ndim(&C3_ptr, 0), nd_data(&C3_ptr), alpha, beta, gamma, nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(A3_data);
    free_pointer(A3_ind);
    free_pointer(A3_ptr);
    free_pointer(B1_data);
    free_pointer(B1_ind);
    free_pointer(B1_ptr);
    free_pointer(B2_data);
    free_pointer(B2_ind);
    free_pointer(B2_ptr);
    free_pointer(B3_data);
    free_pointer(B3_ind);
    free_pointer(B3_ptr);
    free_pointer(C1_data);
    free_pointer(C1_ind);
    free_pointer(C1_ptr);
    free_pointer(C2_data);
    free_pointer(C2_ind);
    free_pointer(C2_ptr);
    free_pointer(C3_data);
    free_pointer(C3_ind);
    free_pointer(C3_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_3_sum_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray A3_data = {.shape = NULL};
    t_ndarray A3_ind = {.shape = NULL};
    t_ndarray A3_ptr = {.shape = NULL};
    t_ndarray B1_data = {.shape = NULL};
    t_ndarray B1_ind = {.shape = NULL};
    t_ndarray B1_ptr = {.shape = NULL};
    t_ndarray B2_data = {.shape = NULL};
    t_ndarray B2_ind = {.shape = NULL};
    t_ndarray B2_ptr = {.shape = NULL};
    t_ndarray B3_data = {.shape = NULL};
    t_ndarray B3_ind = {.shape = NULL};
    t_ndarray B3_ptr = {.shape = NULL};
    t_ndarray C1_data = {.shape = NULL};
    t_ndarray C1_ind = {.shape = NULL};
    t_ndarray C1_ptr = {.shape = NULL};
    t_ndarray C2_data = {.shape = NULL};
    t_ndarray C2_ind = {.shape = NULL};
    t_ndarray C2_ptr = {.shape = NULL};
    t_ndarray C3_data = {.shape = NULL};
    t_ndarray C3_ind = {.shape = NULL};
    t_ndarray C3_ptr = {.shape = NULL};
    double alpha;
    double beta;
    double gamma;
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *A3_data_tmp;
    PyArrayObject *A3_ind_tmp;
    PyArrayObject *A3_ptr_tmp;
    PyArrayObject *B1_data_tmp;
    PyArrayObject *B1_ind_tmp;
    PyArrayObject *B1_ptr_tmp;
    PyArrayObject *B2_data_tmp;
    PyArrayObject *B2_ind_tmp;
    PyArrayObject *B2_ptr_tmp;
    PyArrayObject *B3_data_tmp;
    PyArrayObject *B3_ind_tmp;
    PyArrayObject *B3_ptr_tmp;
    PyArrayObject *C1_data_tmp;
    PyArrayObject *C1_ind_tmp;
    PyArrayObject *C1_ptr_tmp;
    PyArrayObject *C2_data_tmp;
    PyArrayObject *C2_ind_tmp;
    PyArrayObject *C2_ptr_tmp;
    PyArrayObject *C3_data_tmp;
    PyArrayObject *C3_ind_tmp;
    PyArrayObject *C3_ptr_tmp;
    PyObject *alpha_tmp;
    PyObject *beta_tmp;
    PyObject *gamma_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "A3_data",
        "A3_ind",
        "A3_ptr",
        "B1_data",
        "B1_ind",
        "B1_ptr",
        "B2_data",
        "B2_ind",
        "B2_ptr",
        "B3_data",
        "B3_ind",
        "B3_ptr",
        "C1_data",
        "C1_ind",
        "C1_ptr",
        "C2_data",
        "C2_ind",
        "C2_ptr",
        "C3_data",
        "C3_ind",
        "C3_ptr",
        "alpha",
        "beta",
        "gamma",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!OOOO!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &A3_data_tmp, &PyArray_Type, &A3_ind_tmp, &PyArray_Type, &A3_ptr_tmp, &PyArray_Type, &B1_data_tmp, &PyArray_Type, &B1_ind_tmp, &PyArray_Type, &B1_ptr_tmp, &PyArray_Type, &B2_data_tmp, &PyArray_Type, &B2_ind_tmp, &PyArray_Type, &B2_ptr_tmp, &PyArray_Type, &B3_data_tmp, &PyArray_Type, &B3_ind_tmp, &PyArray_Type, &B3_ptr_tmp, &PyArray_Type, &C1_data_tmp, &PyArray_Type, &C1_ind_tmp, &PyArray_Type, &C1_ptr_tmp, &PyArray_Type, &C2_data_tmp, &PyArray_Type, &C2_ind_tmp, &PyArray_Type, &C2_ptr_tmp, &PyArray_Type, &C3_data_tmp, &PyArray_Type, &C3_ind_tmp, &PyArray_Type, &C3_ptr_tmp, &alpha_tmp, &beta_tmp, &gamma_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(A3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_data = pyarray_to_ndarray(A3_data_tmp);
    }
    if (!pyarray_check(A3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ind = pyarray_to_ndarray(A3_ind_tmp);
    }
    if (!pyarray_check(A3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A3_ptr = pyarray_to_ndarray(A3_ptr_tmp);
    }
    if (!pyarray_check(B1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_data = pyarray_to_ndarray(B1_data_tmp);
    }
    if (!pyarray_check(B1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ind = pyarray_to_ndarray(B1_ind_tmp);
    }
    if (!pyarray_check(B1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ptr = pyarray_to_ndarray(B1_ptr_tmp);
    }
    if (!pyarray_check(B2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_data = pyarray_to_ndarray(B2_data_tmp);
    }
    if (!pyarray_check(B2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ind = pyarray_to_ndarray(B2_ind_tmp);
    }
    if (!pyarray_check(B2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ptr = pyarray_to_ndarray(B2_ptr_tmp);
    }
    if (!pyarray_check(B3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B3_data = pyarray_to_ndarray(B3_data_tmp);
    }
    if (!pyarray_check(B3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B3_ind = pyarray_to_ndarray(B3_ind_tmp);
    }
    if (!pyarray_check(B3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B3_ptr = pyarray_to_ndarray(B3_ptr_tmp);
    }
    if (!pyarray_check(C1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_data = pyarray_to_ndarray(C1_data_tmp);
    }
    if (!pyarray_check(C1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ind = pyarray_to_ndarray(C1_ind_tmp);
    }
    if (!pyarray_check(C1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ptr = pyarray_to_ndarray(C1_ptr_tmp);
    }
    if (!pyarray_check(C2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_data = pyarray_to_ndarray(C2_data_tmp);
    }
    if (!pyarray_check(C2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ind = pyarray_to_ndarray(C2_ind_tmp);
    }
    if (!pyarray_check(C2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ptr = pyarray_to_ndarray(C2_ptr_tmp);
    }
    if (!pyarray_check(C3_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C3_data = pyarray_to_ndarray(C3_data_tmp);
    }
    if (!pyarray_check(C3_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C3_ind = pyarray_to_ndarray(C3_ind_tmp);
    }
    if (!pyarray_check(C3_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C3_ptr = pyarray_to_ndarray(C3_ptr_tmp);
    }
    if (PyIs_NativeFloat(alpha_tmp))
    {
        alpha = PyDouble_to_Double(alpha_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(beta_tmp))
    {
        beta = PyDouble_to_Double(beta_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(gamma_tmp))
    {
        gamma = PyDouble_to_Double(gamma_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_3_sum_upper(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&A3_data, 0), nd_data(&A3_data), nd_ndim(&A3_ind, 0), nd_data(&A3_ind), nd_ndim(&A3_ptr, 0), nd_data(&A3_ptr), nd_ndim(&B1_data, 0), nd_data(&B1_data), nd_ndim(&B1_ind, 0), nd_data(&B1_ind), nd_ndim(&B1_ptr, 0), nd_data(&B1_ptr), nd_ndim(&B2_data, 0), nd_data(&B2_data), nd_ndim(&B2_ind, 0), nd_data(&B2_ind), nd_ndim(&B2_ptr, 0), nd_data(&B2_ptr), nd_ndim(&B3_data, 0), nd_data(&B3_data), nd_ndim(&B3_ind, 0), nd_data(&B3_ind), nd_ndim(&B3_ptr, 0), nd_data(&B3_ptr), nd_ndim(&C1_data, 0), nd_data(&C1_data), nd_ndim(&C1_ind, 0), nd_data(&C1_ind), nd_ndim(&C1_ptr, 0), nd_data(&C1_ptr), nd_ndim(&C2_data, 0), nd_data(&C2_data), nd_ndim(&C2_ind, 0), nd_data(&C2_ind), nd_ndim(&C2_ptr, 0), nd_data(&C2_ptr), nd_ndim(&C3_data, 0), nd_data(&C3_data), nd_ndim(&C3_ind, 0), nd_data(&C3_ind), nd_ndim(&C3_ptr, 0), nd_data(&C3_ptr), alpha, beta, gamma, nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(A3_data);
    free_pointer(A3_ind);
    free_pointer(A3_ptr);
    free_pointer(B1_data);
    free_pointer(B1_ind);
    free_pointer(B1_ptr);
    free_pointer(B2_data);
    free_pointer(B2_ind);
    free_pointer(B2_ptr);
    free_pointer(B3_data);
    free_pointer(B3_ind);
    free_pointer(B3_ptr);
    free_pointer(C1_data);
    free_pointer(C1_ind);
    free_pointer(C1_ptr);
    free_pointer(C2_data);
    free_pointer(C2_ind);
    free_pointer(C2_ptr);
    free_pointer(C3_data);
    free_pointer(C3_ind);
    free_pointer(C3_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_23_sum_lower_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray B1_data = {.shape = NULL};
    t_ndarray B1_ind = {.shape = NULL};
    t_ndarray B1_ptr = {.shape = NULL};
    t_ndarray B2_data = {.shape = NULL};
    t_ndarray B2_ind = {.shape = NULL};
    t_ndarray B2_ptr = {.shape = NULL};
    t_ndarray C1_data = {.shape = NULL};
    t_ndarray C1_ind = {.shape = NULL};
    t_ndarray C1_ptr = {.shape = NULL};
    t_ndarray C2_data = {.shape = NULL};
    t_ndarray C2_ind = {.shape = NULL};
    t_ndarray C2_ptr = {.shape = NULL};
    double alpha;
    double beta;
    double gamma;
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *B1_data_tmp;
    PyArrayObject *B1_ind_tmp;
    PyArrayObject *B1_ptr_tmp;
    PyArrayObject *B2_data_tmp;
    PyArrayObject *B2_ind_tmp;
    PyArrayObject *B2_ptr_tmp;
    PyArrayObject *C1_data_tmp;
    PyArrayObject *C1_ind_tmp;
    PyArrayObject *C1_ptr_tmp;
    PyArrayObject *C2_data_tmp;
    PyArrayObject *C2_ind_tmp;
    PyArrayObject *C2_ptr_tmp;
    PyObject *alpha_tmp;
    PyObject *beta_tmp;
    PyObject *gamma_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "B1_data",
        "B1_ind",
        "B1_ptr",
        "B2_data",
        "B2_ind",
        "B2_ptr",
        "C1_data",
        "C1_ind",
        "C1_ptr",
        "C2_data",
        "C2_ind",
        "C2_ptr",
        "alpha",
        "beta",
        "gamma",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!OOOO!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &B1_data_tmp, &PyArray_Type, &B1_ind_tmp, &PyArray_Type, &B1_ptr_tmp, &PyArray_Type, &B2_data_tmp, &PyArray_Type, &B2_ind_tmp, &PyArray_Type, &B2_ptr_tmp, &PyArray_Type, &C1_data_tmp, &PyArray_Type, &C1_ind_tmp, &PyArray_Type, &C1_ptr_tmp, &PyArray_Type, &C2_data_tmp, &PyArray_Type, &C2_ind_tmp, &PyArray_Type, &C2_ptr_tmp, &alpha_tmp, &beta_tmp, &gamma_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(B1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_data = pyarray_to_ndarray(B1_data_tmp);
    }
    if (!pyarray_check(B1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ind = pyarray_to_ndarray(B1_ind_tmp);
    }
    if (!pyarray_check(B1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ptr = pyarray_to_ndarray(B1_ptr_tmp);
    }
    if (!pyarray_check(B2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_data = pyarray_to_ndarray(B2_data_tmp);
    }
    if (!pyarray_check(B2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ind = pyarray_to_ndarray(B2_ind_tmp);
    }
    if (!pyarray_check(B2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ptr = pyarray_to_ndarray(B2_ptr_tmp);
    }
    if (!pyarray_check(C1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_data = pyarray_to_ndarray(C1_data_tmp);
    }
    if (!pyarray_check(C1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ind = pyarray_to_ndarray(C1_ind_tmp);
    }
    if (!pyarray_check(C1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ptr = pyarray_to_ndarray(C1_ptr_tmp);
    }
    if (!pyarray_check(C2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_data = pyarray_to_ndarray(C2_data_tmp);
    }
    if (!pyarray_check(C2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ind = pyarray_to_ndarray(C2_ind_tmp);
    }
    if (!pyarray_check(C2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ptr = pyarray_to_ndarray(C2_ptr_tmp);
    }
    if (PyIs_NativeFloat(alpha_tmp))
    {
        alpha = PyDouble_to_Double(alpha_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(beta_tmp))
    {
        beta = PyDouble_to_Double(beta_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(gamma_tmp))
    {
        gamma = PyDouble_to_Double(gamma_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_23_sum_lower(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&B1_data, 0), nd_data(&B1_data), nd_ndim(&B1_ind, 0), nd_data(&B1_ind), nd_ndim(&B1_ptr, 0), nd_data(&B1_ptr), nd_ndim(&B2_data, 0), nd_data(&B2_data), nd_ndim(&B2_ind, 0), nd_data(&B2_ind), nd_ndim(&B2_ptr, 0), nd_data(&B2_ptr), nd_ndim(&C1_data, 0), nd_data(&C1_data), nd_ndim(&C1_ind, 0), nd_data(&C1_ind), nd_ndim(&C1_ptr, 0), nd_data(&C1_ptr), nd_ndim(&C2_data, 0), nd_data(&C2_data), nd_ndim(&C2_ind, 0), nd_data(&C2_ind), nd_ndim(&C2_ptr, 0), nd_data(&C2_ptr), alpha, beta, gamma, nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(B1_data);
    free_pointer(B1_ind);
    free_pointer(B1_ptr);
    free_pointer(B2_data);
    free_pointer(B2_ind);
    free_pointer(B2_ptr);
    free_pointer(C1_data);
    free_pointer(C1_ind);
    free_pointer(C1_ptr);
    free_pointer(C2_data);
    free_pointer(C2_ind);
    free_pointer(C2_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

/*........................................*/
PyObject *spsolve_kron_csr_23_sum_upper_wrapper(PyObject *self, PyObject *args, PyObject *kwargs)
{
    t_ndarray A1_data = {.shape = NULL};
    t_ndarray A1_ind = {.shape = NULL};
    t_ndarray A1_ptr = {.shape = NULL};
    t_ndarray A2_data = {.shape = NULL};
    t_ndarray A2_ind = {.shape = NULL};
    t_ndarray A2_ptr = {.shape = NULL};
    t_ndarray B1_data = {.shape = NULL};
    t_ndarray B1_ind = {.shape = NULL};
    t_ndarray B1_ptr = {.shape = NULL};
    t_ndarray B2_data = {.shape = NULL};
    t_ndarray B2_ind = {.shape = NULL};
    t_ndarray B2_ptr = {.shape = NULL};
    t_ndarray C1_data = {.shape = NULL};
    t_ndarray C1_ind = {.shape = NULL};
    t_ndarray C1_ptr = {.shape = NULL};
    t_ndarray C2_data = {.shape = NULL};
    t_ndarray C2_ind = {.shape = NULL};
    t_ndarray C2_ptr = {.shape = NULL};
    double alpha;
    double beta;
    double gamma;
    t_ndarray b = {.shape = NULL};
    t_ndarray y = {.shape = NULL};
    PyArrayObject *A1_data_tmp;
    PyArrayObject *A1_ind_tmp;
    PyArrayObject *A1_ptr_tmp;
    PyArrayObject *A2_data_tmp;
    PyArrayObject *A2_ind_tmp;
    PyArrayObject *A2_ptr_tmp;
    PyArrayObject *B1_data_tmp;
    PyArrayObject *B1_ind_tmp;
    PyArrayObject *B1_ptr_tmp;
    PyArrayObject *B2_data_tmp;
    PyArrayObject *B2_ind_tmp;
    PyArrayObject *B2_ptr_tmp;
    PyArrayObject *C1_data_tmp;
    PyArrayObject *C1_ind_tmp;
    PyArrayObject *C1_ptr_tmp;
    PyArrayObject *C2_data_tmp;
    PyArrayObject *C2_ind_tmp;
    PyArrayObject *C2_ptr_tmp;
    PyObject *alpha_tmp;
    PyObject *beta_tmp;
    PyObject *gamma_tmp;
    PyArrayObject *b_tmp;
    PyArrayObject *y_tmp;
    PyObject *result;
    static char *kwlist[] = {
        "A1_data",
        "A1_ind",
        "A1_ptr",
        "A2_data",
        "A2_ind",
        "A2_ptr",
        "B1_data",
        "B1_ind",
        "B1_ptr",
        "B2_data",
        "B2_ind",
        "B2_ptr",
        "C1_data",
        "C1_ind",
        "C1_ptr",
        "C2_data",
        "C2_ind",
        "C2_ptr",
        "alpha",
        "beta",
        "gamma",
        "b",
        "y",
        NULL
    };
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!O!OOOO!O!", kwlist, &PyArray_Type, &A1_data_tmp, &PyArray_Type, &A1_ind_tmp, &PyArray_Type, &A1_ptr_tmp, &PyArray_Type, &A2_data_tmp, &PyArray_Type, &A2_ind_tmp, &PyArray_Type, &A2_ptr_tmp, &PyArray_Type, &B1_data_tmp, &PyArray_Type, &B1_ind_tmp, &PyArray_Type, &B1_ptr_tmp, &PyArray_Type, &B2_data_tmp, &PyArray_Type, &B2_ind_tmp, &PyArray_Type, &B2_ptr_tmp, &PyArray_Type, &C1_data_tmp, &PyArray_Type, &C1_ind_tmp, &PyArray_Type, &C1_ptr_tmp, &PyArray_Type, &C2_data_tmp, &PyArray_Type, &C2_ind_tmp, &PyArray_Type, &C2_ptr_tmp, &alpha_tmp, &beta_tmp, &gamma_tmp, &PyArray_Type, &b_tmp, &PyArray_Type, &y_tmp))
    {
        return NULL;
    }
    if (!pyarray_check(A1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_data = pyarray_to_ndarray(A1_data_tmp);
    }
    if (!pyarray_check(A1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ind = pyarray_to_ndarray(A1_ind_tmp);
    }
    if (!pyarray_check(A1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A1_ptr = pyarray_to_ndarray(A1_ptr_tmp);
    }
    if (!pyarray_check(A2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_data = pyarray_to_ndarray(A2_data_tmp);
    }
    if (!pyarray_check(A2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ind = pyarray_to_ndarray(A2_ind_tmp);
    }
    if (!pyarray_check(A2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        A2_ptr = pyarray_to_ndarray(A2_ptr_tmp);
    }
    if (!pyarray_check(B1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_data = pyarray_to_ndarray(B1_data_tmp);
    }
    if (!pyarray_check(B1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ind = pyarray_to_ndarray(B1_ind_tmp);
    }
    if (!pyarray_check(B1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B1_ptr = pyarray_to_ndarray(B1_ptr_tmp);
    }
    if (!pyarray_check(B2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_data = pyarray_to_ndarray(B2_data_tmp);
    }
    if (!pyarray_check(B2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ind = pyarray_to_ndarray(B2_ind_tmp);
    }
    if (!pyarray_check(B2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        B2_ptr = pyarray_to_ndarray(B2_ptr_tmp);
    }
    if (!pyarray_check(C1_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_data = pyarray_to_ndarray(C1_data_tmp);
    }
    if (!pyarray_check(C1_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ind = pyarray_to_ndarray(C1_ind_tmp);
    }
    if (!pyarray_check(C1_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C1_ptr = pyarray_to_ndarray(C1_ptr_tmp);
    }
    if (!pyarray_check(C2_data_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_data = pyarray_to_ndarray(C2_data_tmp);
    }
    if (!pyarray_check(C2_ind_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ind = pyarray_to_ndarray(C2_ind_tmp);
    }
    if (!pyarray_check(C2_ptr_tmp, NPY_INT32, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        C2_ptr = pyarray_to_ndarray(C2_ptr_tmp);
    }
    if (PyIs_NativeFloat(alpha_tmp))
    {
        alpha = PyDouble_to_Double(alpha_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(beta_tmp))
    {
        beta = PyDouble_to_Double(beta_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (PyIs_NativeFloat(gamma_tmp))
    {
        gamma = PyDouble_to_Double(gamma_tmp);
    }
    else
    {
        PyErr_SetString(PyExc_TypeError, "\"Argument must be native float\"");
        return NULL;
    }
    if (!pyarray_check(b_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        b = pyarray_to_ndarray(b_tmp);
    }
    if (!pyarray_check(y_tmp, NPY_DOUBLE, 1, NO_ORDER_CHECK))
    {
        return NULL;
    }
    else
    {
        y = pyarray_to_ndarray(y_tmp);
    }
    bind_c_spsolve_kron_csr_23_sum_upper(nd_ndim(&A1_data, 0), nd_data(&A1_data), nd_ndim(&A1_ind, 0), nd_data(&A1_ind), nd_ndim(&A1_ptr, 0), nd_data(&A1_ptr), nd_ndim(&A2_data, 0), nd_data(&A2_data), nd_ndim(&A2_ind, 0), nd_data(&A2_ind), nd_ndim(&A2_ptr, 0), nd_data(&A2_ptr), nd_ndim(&B1_data, 0), nd_data(&B1_data), nd_ndim(&B1_ind, 0), nd_data(&B1_ind), nd_ndim(&B1_ptr, 0), nd_data(&B1_ptr), nd_ndim(&B2_data, 0), nd_data(&B2_data), nd_ndim(&B2_ind, 0), nd_data(&B2_ind), nd_ndim(&B2_ptr, 0), nd_data(&B2_ptr), nd_ndim(&C1_data, 0), nd_data(&C1_data), nd_ndim(&C1_ind, 0), nd_data(&C1_ind), nd_ndim(&C1_ptr, 0), nd_data(&C1_ptr), nd_ndim(&C2_data, 0), nd_data(&C2_data), nd_ndim(&C2_ind, 0), nd_data(&C2_ind), nd_ndim(&C2_ptr, 0), nd_data(&C2_ptr), alpha, beta, gamma, nd_ndim(&b, 0), nd_data(&b), nd_ndim(&y, 0), nd_data(&y));
    result = Py_BuildValue("");
    free_pointer(A1_data);
    free_pointer(A1_ind);
    free_pointer(A1_ptr);
    free_pointer(A2_data);
    free_pointer(A2_ind);
    free_pointer(A2_ptr);
    free_pointer(B1_data);
    free_pointer(B1_ind);
    free_pointer(B1_ptr);
    free_pointer(B2_data);
    free_pointer(B2_ind);
    free_pointer(B2_ptr);
    free_pointer(C1_data);
    free_pointer(C1_ind);
    free_pointer(C1_ptr);
    free_pointer(C2_data);
    free_pointer(C2_ind);
    free_pointer(C2_ptr);
    free_pointer(b);
    free_pointer(y);
    return result;
}
/*........................................*/

static int exec_func(PyObject* m)
{
    return 0;
}

/*........................................*/

static PyMethodDef triangular_core_methods[] = {
    {
        "spsolve_dns_lower",
        (PyCFunction)spsolve_dns_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_dns_upper",
        (PyCFunction)spsolve_dns_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_csr_lower",
        (PyCFunction)spsolve_csr_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_csr_upper",
        (PyCFunction)spsolve_csr_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "tril",
        (PyCFunction)tril_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "triu",
        (PyCFunction)triu_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "tril_kron_2",
        (PyCFunction)tril_kron_2_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "triu_kron_2",
        (PyCFunction)triu_kron_2_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "tril_kron_3",
        (PyCFunction)tril_kron_3_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "triu_kron_3",
        (PyCFunction)triu_kron_3_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_2_lower",
        (PyCFunction)spsolve_kron_csr_2_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_2_upper",
        (PyCFunction)spsolve_kron_csr_2_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_3_lower",
        (PyCFunction)spsolve_kron_csr_3_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_3_upper",
        (PyCFunction)spsolve_kron_csr_3_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_2_sum_lower",
        (PyCFunction)spsolve_kron_csr_2_sum_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_2_sum_upper",
        (PyCFunction)spsolve_kron_csr_2_sum_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_3_sum_lower",
        (PyCFunction)spsolve_kron_csr_3_sum_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_3_sum_upper",
        (PyCFunction)spsolve_kron_csr_3_sum_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_23_sum_lower",
        (PyCFunction)spsolve_kron_csr_23_sum_lower_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    {
        "spsolve_kron_csr_23_sum_upper",
        (PyCFunction)spsolve_kron_csr_23_sum_upper_wrapper,
        METH_VARARGS | METH_KEYWORDS,
        ""
    },
    { NULL, NULL, 0, NULL}
};

/*........................................*/

static PyModuleDef_Slot triangular_core_slots[] = {
    {Py_mod_exec, exec_func},
    {0, NULL},
};

/*........................................*/

static struct PyModuleDef triangular_core_module = {
    PyModuleDef_HEAD_INIT,
    /* name of module */
    "triangular_core",
    /* module documentation, may be NULL */
    NULL,
    /* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
    0,
    triangular_core_methods,
    triangular_core_slots
};

/*........................................*/

PyMODINIT_FUNC PyInit_triangular_core(void)
{
    import_array();
    return PyModuleDef_Init(&triangular_core_module);
}
