import numpy as np
from scipy.linalg import eigh
from scipy.sparse import csr_matrix, coo_matrix

from kronecker import fast_diag_core as core
from kronecker.kronecker import kron

# =========================================================================
def solve_unit_sylvester_system_2d(d1, d2, b, tau=0.):
    """
    Solves the linear system (D1 x I2 + I1 x D2 + tau I1 x I2) x = b
    """
    n1 = len(d1)
    n2 = len(d2)
    x = np.zeros(n1*n2)

    core.solve_unit_sylvester_system_2d(d1, d2, b, float(tau), x)

    return x

# =========================================================================
def solve_unit_sylvester_system_3d(d1, d2, d3, b, tau=0.):
    """
    Solves the linear system (D1 x I2 x I3 + I1 x D2 x I3 + I1 x I2 x D3 + tau I1 x I2 x I3) x = b
    """
    n1 = len(d1)
    n2 = len(d2)
    n3 = len(d3)
    x = np.zeros(n1*n2*n3)

    core.solve_unit_sylvester_system_3d(d1, d2, d3, b, float(tau), x)

    return x

# =========================================================================
def solve_sylvester_system_2d(mats_1, mats_2, b):

    # ...
    M1, K1 = mats_1[:]
    M2, K2 = mats_2[:]
    # ...

    # ...
    M1 = M1.toarray()
    K1 = K1.toarray()

    d1, U1 = eigh(K1, b=M1)
    # ...

    # ...
    M2 = M2.toarray()
    K2 = K2.toarray()

    d2, U2 = eigh(K2, b=M2)
    # ...

    # ...
    t_U1 = U1.T
    t_U2 = U2.T
    # ...

    # ... TODO remove this
    #          this is a trick to avoid the problem of C/F ordering with pyccel
    U1 = coo_matrix(U1).toarray()
    U2 = coo_matrix(U2).toarray()
    # ...

    # ...
    r_tilde = kron(t_U1, t_U2) @ b
    s_tilde = solve_unit_sylvester_system_2d(d1, d2, r_tilde)
    s = kron(U1, U2) @ s_tilde
    # ...

    return s

# =========================================================================
def solve_sylvester_system_3d(mats_1, mats_2, mats_3, b):

    # ...
    M1, K1 = mats_1[:]
    M2, K2 = mats_2[:]
    M3, K3 = mats_3[:]
    # ...

    # ...
    M1 = M1.toarray()
    K1 = K1.toarray()

    d1, U1 = eigh(K1, b=M1)
    # ...

    # ...
    M2 = M2.toarray()
    K2 = K2.toarray()

    d2, U2 = eigh(K2, b=M2)
    # ...

    # ...
    M3 = M3.toarray()
    K3 = K3.toarray()

    d3, U3 = eigh(K3, b=M3)
    # ...

    # ...
    t_U1 = U1.T
    t_U2 = U2.T
    t_U3 = U3.T
    # ...

    # ... TODO remove this
    #          this is a trick to avoid the problem of C/F ordering with pyccel
    U1 = coo_matrix(U1).toarray()
    U2 = coo_matrix(U2).toarray()
    U3 = coo_matrix(U3).toarray()
    # ...

    # ...
    r_tilde = kron(t_U1, t_U2, t_U3) @ b
    s_tilde = solve_unit_sylvester_system_3d(d1, d2, d3, r_tilde)
    s = kron(U1, U2, U3) @ s_tilde
    # ...

    return s

# =========================================================================
class Poisson(object):
    def __init__(self, mats_1, mats_2, mats_3=None, tau=0.):
        # ...
        assert(len(mats_1) == 2)
        assert(len(mats_2) == 2)

        rdim = None
        if mats_3 is None:
            rdim = 2
        else:
            assert(len(mats_3) == 2)
            rdim = 3
        # ...

        # ...
        if rdim == 2:
            Ms = [mats_1[0], mats_2[0]]
            Ks = [mats_1[1], mats_2[1]]
        else:
            Ms = [mats_1[0], mats_2[0], mats_3[0]]
            Ks = [mats_1[1], mats_2[1], mats_3[1]]
        # ...

        # ... generalized eigenvalue decomposition
        ds = []
        Us = []
        t_Us = []
        for M, K in zip(Ms, Ks):
            M = M.toarray()
            K = K.toarray()

            d, U = eigh(K, b=M)

            t_U = U.T
            # trick to avoid F/C ordering with pyccel
            U = csr_matrix(U).toarray()

            ds.append(d)
            Us.append(U)
            t_Us.append(t_U)
        # ...

        # ...
        forward  = None
        backward = None
        if rdim == 2:
            U1, U2 = Us[:]
            t_U1, t_U2 = t_Us[:]

            forward  = kron(t_U1, t_U2)
            backward = kron(U1, U2)

        elif rdim == 3:
            U1, U2, U3 = Us[:]
            t_U1, t_U2, t_U3 = t_Us[:]

            forward  = kron(t_U1, t_U2, t_U3)
            backward = kron(U1, U2, U3)
        # ...

        # ...
        self._mats_1 = mats_1
        self._mats_2 = mats_2
        self._mats_3 = mats_3

        self._ds = ds
        self._Us = Us
        self._t_Us = t_Us
        self._rdim = rdim
        self._tau = tau

        self._forward  = forward
        self._backward = backward
        # ...

    @property
    def rdim(self):
        return self._rdim

    @property
    def mats_1(self):
        return self._mats_1

    @property
    def mats_2(self):
        return self._mats_2

    @property
    def mats_3(self):
        return self._mats_3

    @property
    def ds(self):
        return self._ds

    @property
    def Us(self):
        return self._Us

    @property
    def t_Us(self):
        return self._t_Us

    @property
    def tau(self):
        return self._tau

    @property
    def forward(self):
        return self._forward

    @property
    def backward(self):
        return self._backward

    def _solve_2d(self, b):
        # ...
        d1, d2 = self.ds
        U1, U2 = self.Us
        t_U1, t_U2 = self.t_Us
        # ...

        # ...
        r_tilde = self.forward @ b
        s_tilde = solve_unit_sylvester_system_2d(d1, d2, r_tilde, tau=self.tau)
        s = self.backward @ s_tilde
        # ...

        return s

    def _solve_3d(self, b):
        # ...
        d1, d2, d3 = self.ds
        U1, U2, U3 = self.Us
        t_U1, t_U2, t_U3 = self.t_Us
        # ...

        # ...
        r_tilde = self.forward @ b
        s_tilde = solve_unit_sylvester_system_3d(d1, d2, d3, r_tilde, tau=self.tau)
        s = self.backward @ s_tilde
        # ...

        return s

    def solve(self, b):
        if self.rdim == 2:
            return self._solve_2d(b)
        else:
            return self._solve_3d(b)
