"""
TODO
"""

from abc   import ABCMeta, abstractmethod
import numpy as np
from scipy.sparse import csr_matrix, coo_matrix

from kronecker import kronecker_dns_core as core_dns
from kronecker import kronecker_csr_core as core_csr

# =========================================================================
def vec_2d(X):
    """Convert a matrix to a vector form."""

    n1, n2 = X.shape
    x = np.empty(n1*n2)

    core_dns.vec_2d(X, x)

    return x

# =========================================================================
def unvec_2d(x, n1, n2):
    """Convert a vector to a matrix form."""

    X = np.empty((n1,n2))

    core_dns.unvec_2d(x, n1, n2, X)

    return X

# =========================================================================
def vec_3d(X):
    """Convert a matrix to a vector form."""

    n1, n2, n3 = X.shape
    x = np.empty(n1*n2*n3)

    core_dns.vec_3d(X, x)

    return x

# =========================================================================
def unvec_3d(x, n1, n2, n3):
    """Convert a vector to a matrix form."""

    X = np.empty((n1,n2,n3))

    core_dns.unvec_3d(x, n1, n2, n3, X)

    return X

# =========================================================================
class Basic(metaclass=ABCMeta):

    def __init__(self, *args, **kwargs):
        self._alpha = kwargs.pop('alpha', 1.)

    @property
    def rdim(self):
        return self._rdim

    @property
    def args(self):
        return self._args

    @property
    def shape(self):
        return self._shape

    @property
    def alpha(self):
        return self._alpha

    #-------------------------------------
    # Deferred methods
    #-------------------------------------

    @abstractmethod
    def __neg__(self):
        """ Get the opposite matrix, i.e. a copy with negative sign. """

    @abstractmethod
    def __mul__(self, a):
        """ Multiply by scalar. """

    @abstractmethod
    def __rmul__(self, a):
        """ Multiply by scalar. """

    @abstractmethod
    def __imul__(self, a):
        """ Multiply by scalar, in place. """

    def __truediv__(self, a):
        """ Divide by scalar. """

    def __itruediv__(self, a):
        """ Divide by scalar, in place. """

    @abstractmethod
    def __add__(self, other):
        """ Add . """

    @abstractmethod
    def __iadd__(self, other):
        """ Add . """

    @abstractmethod
    def __radd__(self, other):
        """ Add . """

    @abstractmethod
    def __matmul__(self, other):
        """ @ operator . """

    @abstractmethod
    def __imatmul__(self, other):
        """ @ operator . """

    @abstractmethod
    def __rmatmul__(self, other):
        """ @ operator . """

    @abstractmethod
    def dot( self, v, out=None ):
        pass

# =========================================================================
class KroneckerCSR(Basic):

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        # ...
        rdim = len(args)
        assert(rdim >= 2)
        # ...

        # ...
        is_csr = all([isinstance(a, csr_matrix) for a in args])

        if not is_csr:
            raise ValueError('Expecting scipy CSR matrices')
        # ...

        # ...
        shape = (np.prod([a.shape[0] for a in args]),
                 np.prod([a.shape[1] for a in args]))
        # ...

        # ...
        self._rdim = rdim
        self._args = args
        self._shape = shape
        self._work = None
        # ...

    @property
    def work(self):
        return self._work

    # TODO move this method to a Base class for CSR and DNS?
    #      to avoid code duplication
    def _create_work_arrays(self):

        if self.rdim == 2:
            A1, A2 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]

            n = max(n_rows_1, max(n_cols_1, max(n_rows_2, n_cols_2)))
            W1 = np.empty((n, n))
            W2 = np.empty((n, n))

            self._work = (W1, W2)

        if self.rdim == 3:
            A1, A2, A3 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]
            n_rows_3 = A3.shape[0]
            n_cols_3 = A3.shape[1]
            n_rows_12 = n_rows_1 * n_rows_2
            n_cols_12 = n_cols_1 * n_cols_2

            nrows = n_rows_1 * n_rows_2 * n_rows_3
            ncols = n_cols_1 * n_cols_2 * n_cols_3

            n = max(n_rows_12, max(n_cols_12, max(n_rows_3, n_cols_3)))
            W1 = np.empty((n, n))
            W2 = np.empty((n, n))

            n = max(n_rows_1, max(n_cols_1, max(n_rows_2, n_cols_2)))
            W3 = np.empty((n, n))
            W4 = np.empty((n, n))

            self._work = (W1, W2, W3, W4)

    def dot( self, v, out=None ):
        if out is None:
            out = np.zeros(self.shape[0])

        if self.rdim == 2:
            A1, A2 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]

            # ...
            if self.work is None:
                self._create_work_arrays()

            W1, W2 = self.work[:]
            # ...

            core_csr.kron_2d(A1.data, A1.indices, A1.indptr,
                             A2.data, A2.indices, A2.indptr,
                             n_rows_1, n_cols_1,
                             n_rows_2, n_cols_2,
                             v,
                             W1, W2,
                             out)
        if self.rdim == 3:
            A1, A2, A3 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]
            n_rows_3 = A3.shape[0]
            n_cols_3 = A3.shape[1]

            # ...
            if self.work is None:
                self._create_work_arrays()

            W1, W2, W3, W4 = self.work[:]
            # ...

            core_csr.kron_3d(A1.data, A1.indices, A1.indptr,
                             A2.data, A2.indices, A2.indptr,
                             A3.data, A3.indices, A3.indptr,
                             n_rows_1, n_cols_1,
                             n_rows_2, n_cols_2,
                             n_rows_3, n_cols_3,
                             v,
                             W1, W2, W3, W4,
                             out )

        return self.alpha * out

    def __neg__(self):
        return KroneckerCSR(*self.args, alpha=-1.)

    def __mul__(self, a):
        """ Multiply by scalar. """
        if isinstance(a, (int, float)):
            return KroneckerCSR(*self.args, alpha=a)

        elif isinstance(a, KroneckerCSR):
            alpha = self.alpha * a.alpha
            args = []
            for x,y in zip(self.args, a.args):
                args.append(x*y)
            return KroneckerCSR(*args, alpha=alpha)

        else:
            raise TypeError('not implemented yet')

    def __rmul__(self, a):
        """ Multiply by scalar. """
        assert(isinstance(a, (int, float)))
        return KroneckerCSR(*self.args, alpha=a)

    def __imul__(self, a):
        """ Multiply by scalar, in place. """
        assert(isinstance(a, (int, float)))
        return KroneckerCSR(*self.args, alpha=a)

    def __truediv__(self, a):
        """ Divide by scalar. """
        assert(isinstance(a, (int, float)))
        return KroneckerCSR(*self.args, alpha=1./a)

    def __itruediv__(self, a):
        """ Divide by scalar, in place. """
        assert(isinstance(a, (int, float)))
        return KroneckerCSR(*self.args, alpha=1./a)

    def __add__(self, other):
        if not isinstance(other, (KroneckerCSR, KroneckerDNS, KroneckerSum)):
            raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')

        if isinstance(other, (KroneckerCSR, KroneckerDNS)):
            args = (self, other)
            return KroneckerSum(*args)

        if isinstance(other, KroneckerSum):
            raise NotImplementedError('')

    def __iadd__(self, other):
        """ Add . """
        raise NotImplementedError('')

    def __radd__(self, other):
        """ Add . """
        raise NotImplementedError('')

    def __matmul__(self, other):
        """ @ operator . """
        assert(isinstance(other, np.ndarray))
        assert(len(other.shape) == 1)

        return self.dot(other)

    def __imatmul__(self, other):
        """ @ operator . """
        raise NotImplementedError('')

    def __rmatmul__(self, other):
        """ @ operator . """
        raise NotImplementedError('')

# =========================================================================
class KroneckerDNS(Basic):

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        # ...
        rdim = len(args)
        assert(rdim >= 2)
        # ...

        # ...
        is_dns = all([isinstance(a, np.ndarray) for a in args])

        if not is_dns:
            raise ValueError('Expecting numpy ndarrays')
        # ...

        # ...
        shape = (np.prod([a.shape[0] for a in args]),
                 np.prod([a.shape[1] for a in args]))
        # ...

        # ...
        self._rdim = rdim
        self._args = args
        self._shape = shape
        self._work = None
        # ...

    @property
    def work(self):
        return self._work

    # TODO move this method to a Base class for CSR and DNS?
    #      to avoid code duplication
    def _create_work_arrays(self):

        if self.rdim == 2:
            A1, A2 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]

            n = max(n_rows_1, max(n_cols_1, max(n_rows_2, n_cols_2)))
            W1 = np.empty((n, n))
            W2 = np.empty((n, n))

            self._work = (W1, W2)

        if self.rdim == 3:
            A1, A2, A3 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]
            n_rows_3 = A3.shape[0]
            n_cols_3 = A3.shape[1]
            n_rows_12 = n_rows_1 * n_rows_2
            n_cols_12 = n_cols_1 * n_cols_2

            nrows = n_rows_1 * n_rows_2 * n_rows_3
            ncols = n_cols_1 * n_cols_2 * n_cols_3

            n = max(n_rows_12, max(n_cols_12, max(n_rows_3, n_cols_3)))
            W1 = np.empty((n, n))
            W2 = np.empty((n, n))

            n = max(n_rows_1, max(n_cols_1, max(n_rows_2, n_cols_2)))
            W3 = np.empty((n, n))
            W4 = np.empty((n, n))

            self._work = (W1, W2, W3, W4)

    def dot( self, v, out=None ):
        if out is None:
            out = np.zeros(self.shape[0])

        if self.rdim == 2:
            A1, A2 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]

            # ...
            if self.work is None:
                self._create_work_arrays()

            W1, W2 = self.work[:]
            # ...

            core_dns.kron_2d(A1, A2, v, W1, W2, out)

        if self.rdim == 3:
            A1, A2, A3 = self.args[:]

            n_rows_1 = A1.shape[0]
            n_cols_1 = A1.shape[1]
            n_rows_2 = A2.shape[0]
            n_cols_2 = A2.shape[1]
            n_rows_3 = A3.shape[0]
            n_cols_3 = A3.shape[1]

            # ...
            if self.work is None:
                self._create_work_arrays()

            W1, W2, W3, W4 = self.work[:]
            # ...

            core_dns.kron_3d(A1, A2, A3, v, W1, W2, W3, W4, out )

        return self.alpha * out

    def __neg__(self):
        return KroneckerDNS(*self.args, alpha=-1.)

    def __mul__(self, a):
        """ Multiply by scalar. """
        assert(isinstance(a, (int, float)))
        return KroneckerDNS(*self.args, alpha=a)

    def __rmul__(self, a):
        """ Multiply by scalar. """
        assert(isinstance(a, (int, float)))
        return KroneckerDNS(*self.args, alpha=a)

    def __imul__(self, a):
        """ Multiply by scalar, in place. """
        assert(isinstance(a, (int, float)))
        return KroneckerDNS(*self.args, alpha=a)

    def __truediv__(self, a):
        """ Divide by scalar. """
        assert(isinstance(a, (int, float)))
        return KroneckerDNS(*self.args, alpha=1./a)

    def __itruediv__(self, a):
        """ Divide by scalar, in place. """
        assert(isinstance(a, (int, float)))
        return KroneckerDNS(*self.args, alpha=1./a)

    def __add__(self, other):
        if not isinstance(other, (KroneckerCSR, KroneckerDNS, KroneckerSum)):
            raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')

        if isinstance(other, (KroneckerCSR, KroneckerDNS)):
            args = (self, other)
            return KroneckerSum(*args)

        if isinstance(other, KroneckerSum):
            raise NotImplementedError('')

    def __iadd__(self, other):
        """ Add . """
        raise NotImplementedError('')

    def __radd__(self, other):
        """ Add . """
        raise NotImplementedError('')

    def __matmul__(self, other):
        """ @ operator . """
        assert(isinstance(other, np.ndarray))
        assert(len(other.shape) == 1)

        return self.dot(other)

    def __imatmul__(self, other):
        """ @ operator . """
        raise NotImplementedError('')

    def __rmatmul__(self, other):
        """ @ operator . """
        raise NotImplementedError('')

# =========================================================================
class KroneckerSum(Basic):

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        # ...
        shape = (args[0].shape[0], args[0].shape[1])
        assert(all([shape == (a.shape[0], a.shape[1]) for a in args[1:]]))
        # ...

        # ...
        self._rdim = args[0].rdim
        self._args = args
        self._shape = shape
        # ...

    def dot( self, v, out=None ):
        if out is None:
            out = self.args[0].dot(v)
            for a in self.args[1:]:
                out[:] += a.dot(v)

        else:
            out[:] = 0.
            for a in self.args:
                out[:] += a.dot(v)

        return self.alpha * out

    def __neg__(self):
        # ...
        args = []
        for arg in self.args:
            new = arg.__neg__()

            if isinstance(new, (KroneckerCSR, KroneckerDNS)):
                args.append(new)
            elif isinstance(new, KroneckerSum):
                for _ in new:
                    args.append(_)
            else:
                raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')
        # ...

        return KroneckerSum(*args)

    def __mul__(self, a):
        """ Multiply by scalar. """
        assert(isinstance(a, (int, float)))

        # ...
        args = []
        for arg in self.args:
            new = arg.__mul__(a)

            if isinstance(new, (KroneckerCSR, KroneckerDNS)):
                args.append(new)
            elif isinstance(new, KroneckerSum):
                for _ in new:
                    args.append(_)
            else:
                raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')
        # ...

        return KroneckerSum(*args)

    def __rmul__(self, a):
        """ Multiply by scalar. """
        assert(isinstance(a, (int, float)))

        # ...
        args = []
        for arg in self.args:
            new = arg.__rmul__(a)

            if isinstance(new, (KroneckerCSR, KroneckerDNS)):
                args.append(new)
            elif isinstance(new, KroneckerSum):
                for _ in new:
                    args.append(_)
            else:
                raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')
        # ...

        return KroneckerSum(*args)

    def __imul__(self, a):
        """ Multiply by scalar, in place. """
        assert(isinstance(a, (int, float)))

        # ...
        args = []
        for arg in self.args:
            new = arg.__imul__(a)

            if isinstance(new, (KroneckerCSR, KroneckerDNS)):
                args.append(new)
            elif isinstance(new, KroneckerSum):
                for _ in new:
                    args.append(_)
            else:
                raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')
        # ...

        return KroneckerSum(*args)

    def __truediv__(self, a):
        """ Divide by scalar. """
        assert(isinstance(a, (int, float)))

        # ...
        args = []
        for arg in self.args:
            new = arg.__truediv__(a)

            if isinstance(new, (KroneckerCSR, KroneckerDNS)):
                args.append(new)
            elif isinstance(new, KroneckerSum):
                for _ in new:
                    args.append(_)
            else:
                raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')
        # ...

        return KroneckerSum(*args)

    def __itruediv__(self, a):
        """ Divide by scalar, in place. """
        assert(isinstance(a, (int, float)))

        # ...
        args = []
        for arg in self.args:
            new = arg.__itruediv__(a)

            if isinstance(new, (KroneckerCSR, KroneckerDNS)):
                args.append(new)
            elif isinstance(new, KroneckerSum):
                for _ in new:
                    args.append(_)
            else:
                raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')
        # ...

        return KroneckerSum(*args)

    def __add__(self, other):
        if not isinstance(other, (KroneckerCSR, KroneckerDNS, KroneckerSum)):
            raise TypeError('Expecting KroneckerCSR, KroneckerDNS or KroneckerSum')

        if isinstance(other, (KroneckerCSR, KroneckerDNS)):
            args = list(self.args) + [other]
            return KroneckerSum(*args)

        if isinstance(other, KroneckerSum):
            raise NotImplementedError('')

    def __iadd__(self, other):
        """ Add . """
        raise NotImplementedError('')

    def __radd__(self, other):
        """ Add . """
        raise NotImplementedError('')

    def __matmul__(self, other):
        """ @ operator . """
        assert(isinstance(other, np.ndarray))
        assert(len(other.shape) == 1)

        return self.dot(other)

    def __imatmul__(self, other):
        """ @ operator . """
        raise NotImplementedError('')

    def __rmatmul__(self, other):
        """ @ operator . """
        raise NotImplementedError('')

# =========================================================================
def kron(*args, **kwargs):

    # ...
    is_csr = all([isinstance(a, csr_matrix) for a in args])
    if is_csr:
        return KroneckerCSR(*args, **kwargs)
    # ...

    # ...
    is_dns = all([isinstance(a, np.ndarray) for a in args])
    if is_dns:
        return KroneckerDNS(*args, **kwargs)
    # ...

    raise NotImplementedError('TODO')

