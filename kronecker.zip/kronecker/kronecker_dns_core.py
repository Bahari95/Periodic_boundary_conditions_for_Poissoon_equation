# =========================================================================
def vec_2d(x_mat: 'float[:,:]', x: 'float[:]'):
    """Convert a matrix to a vector form."""

    n1, n2 = x_mat.shape

    for i1 in range(n1):
        for i2 in range(n2):
            i = i2 + i1 * n2
            x[i] = x_mat[i1, i2]

# =========================================================================
def unvec_2d(x: 'float[:]', n1: int, n2: int, x_mat: 'float[:,:]'):
    """Convert a vector to a matrix form."""

    for i1 in range(n1):
        for i2 in range(n2):
            i = i2 + i1 * n2
            x_mat[i1, i2] = x[i]

# =========================================================================
def vec_3d(x_mat: 'float[:,:,:]', x: 'float[:]'):
    """Convert a matrix to a vector form."""

    n1, n2, n3 = x_mat.shape

    for i1 in range(n1):
        for i2 in range(n2):
            for i3 in range(n3):
                i = i3 + (i2 + i1 * n2) * n3
                x[i] = x_mat[i1, i2, i3]

# =========================================================================
def unvec_3d(x: 'float[:]', n1: int, n2: int, n3: int, x_mat: 'float[:,:,:]'):
    """Convert a vector to a matrix form."""

    for i1 in range(n1):
        for i2 in range(n2):
            for i3 in range(n3):
                i = i3 + (i2 + i1 * n2) * n3
                x_mat[i1, i2, i3] = x[i]

# =========================================================================
def mxm(A: 'float[:,:]', x: 'float[:,:]', y: 'float[:,:]'):

    """Matrix-Vector product."""

    n_rows, n_cols = A.shape
    m = x.shape[0]

    for k in range(m):
        for i in range(n_rows):
            wi = 0.
            for j in range(n_cols):
                wi += A[i,j] * x[k,j]
            y[i,k] = wi

# =========================================================================
def vec_2d_omp(x_mat: 'float[:,:]', x: 'float[:]'):
    """Convert a matrix to a vector form."""

    n1, n2 = x_mat.shape

    #$ omp for schedule(runtime) collapse(2)
    for i1 in range(n1):
        for i2 in range(n2):
            i = i2 + i1 * n2
            x[i] = x_mat[i1, i2]

# =========================================================================
def unvec_2d_omp(x: 'float[:]', n1: int, n2: int, x_mat: 'float[:,:]'):
    """Convert a vector to a matrix form."""

    #$ omp for schedule(runtime) collapse(2)
    for i1 in range(n1):
        for i2 in range(n2):
            i = i2 + i1 * n2
            x_mat[i1, i2] = x[i]

# =========================================================================
def mxm_omp(A: 'float[:,:]', x: 'float[:,:]', y: 'float[:,:]'):

    """Matrix-Vector product."""

    n_rows, n_cols = A.shape
    m = x.shape[0]

    #$ omp for schedule(runtime) collapse(2)
    for k in range(m):
        for i in range(n_rows):
            wi = 0.
            for j in range(n_cols):
                wi += A[i,j] * x[k,j]
            y[i,k] = wi

# =========================================================================
def kron_2d(A1: 'float[:,:]', A2: 'float[:,:]', x: 'float[:]', W1: 'float[:,:]', W2: 'float[:,:]', y: 'float[:]'):

    # ...
    n_rows_1 = A1.shape[0]
    n_cols_1 = A1.shape[1]
    n_rows_2 = A2.shape[0]
    n_cols_2 = A2.shape[1]
    # ...

    # ...
    unvec_2d(x, n_cols_1, n_cols_2, W1[0:n_cols_1, 0:n_cols_2])
    # ...

    # ...
    mxm(A2, W1[:n_cols_1,:n_cols_2], W2[:n_rows_2,:n_cols_1])
    # ...

    # ...
    mxm(A1, W2[:n_rows_2,:n_cols_1], W1[:n_rows_1,:n_rows_2])
    # ...

    # ...
    vec_2d(W1[0:n_rows_1, 0:n_rows_2], y)
    # ...

# =========================================================================
def kron_3d(A1: 'float[:,:]', A2: 'float[:,:]', A3: 'float[:,:]',
            x: 'float[:]',
            Z1: 'float[:,:]', Z2: 'float[:,:]',
            Z3: 'float[:,:]', Z4: 'float[:,:]',
            y: 'float[:]'):

    #$ omp parallel

    # ...
    n_rows_1 = A1.shape[0]
    n_cols_1 = A1.shape[1]
    n_rows_2 = A2.shape[0]
    n_cols_2 = A2.shape[1]
    n_rows_3 = A3.shape[0]
    n_cols_3 = A3.shape[1]

    n_rows_12 = n_rows_1 * n_rows_2
    n_cols_12 = n_cols_1 * n_cols_2
    # ...

    unvec_2d_omp(x, n_cols_12, n_cols_3, Z1[0:n_cols_12, 0:n_cols_3])

    mxm_omp(A3, Z1[:n_cols_12,:n_cols_3], Z2[:n_rows_3,:n_cols_12])

    #$ omp for schedule(runtime) private(k, Z3, Z4)
    for k in range(n_rows_3):
        kron_2d(A1, A2, Z2[k,0:n_cols_12], Z3, Z4, Z1[0:n_rows_12,k])

    vec_2d_omp(Z1[0:n_rows_12,0:n_rows_3], y)

    #$ omp end parallel
