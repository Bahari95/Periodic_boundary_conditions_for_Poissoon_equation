import numpy as np
from scipy.sparse import csr_matrix, coo_matrix

from kronecker import triangular_core as core
from kronecker.kronecker import KroneckerSum
from kronecker.kronecker import KroneckerCSR
from kronecker.kronecker import KroneckerDNS

# TODO - use out in _spsolve_kron_block and its variants

# =========================================================================
def _spsolve_csr(A, b, lower, out):

    if out is None:
        n = A.shape[0]
        out = np.zeros(n)

    if lower:
        core.spsolve_csr_lower(A.data, A.indices, A.indptr, b, out)
    else:
        core.spsolve_csr_upper(A.data, A.indices, A.indptr, b, out)

    return out

# =========================================================================
def _spsolve_kron_csr(A, b, lower, out):

    if A.rdim == 2:

        A1, A2 = A.args[:]

        nrows, ncols = A.shape
        assert(nrows == ncols)

        if out is None:
            n = nrows
            out = np.zeros(n)

        if lower:
            core.spsolve_kron_csr_2_lower(A1.data, A1.indices, A1.indptr,
                                     A2.data, A2.indices, A2.indptr,
                                     b, out)
        else:
            core.spsolve_kron_csr_2_upper(A1.data, A1.indices, A1.indptr,
                                     A2.data, A2.indices, A2.indptr,
                                     b, out)

    elif A.rdim == 3:

        A1, A2, A3 = A.args[:]

        nrows, ncols = A.shape
        assert(nrows == ncols)

        if out is None:
            n = nrows
            out = np.zeros(n)

        if lower:
            core.spsolve_kron_csr_3_lower(A1.data, A1.indices, A1.indptr,
                                     A2.data, A2.indices, A2.indptr,
                                     A3.data, A3.indices, A3.indptr,
                                     b, out)
        else:
            core.spsolve_kron_csr_3_upper(A1.data, A1.indices, A1.indptr,
                                     A2.data, A2.indices, A2.indptr,
                                     A3.data, A3.indices, A3.indptr,
                                     b, out)

    return out

# =========================================================================
def _spsolve_kron_sum_csr(A, b, lower, out):

    # 2d case
    if len(A.args) == 2 and A.rdim == 2:
        As_1, As_2 = A.args[:]

        assert(isinstance(As_1, KroneckerCSR))
        assert(isinstance(As_2, KroneckerCSR))

        alpha = As_1.alpha
        beta  = As_2.alpha

        A1, A2 = As_1.args[:]
        B1, B2 = As_2.args[:]

        nrows, ncols = A.shape
        assert(nrows == ncols)

        if out is None:
            n = nrows
            out = np.zeros(n)

        if lower:
            core.spsolve_kron_csr_2_sum_lower(A1.data, A1.indices, A1.indptr,
                                              A2.data, A2.indices, A2.indptr,
                                              B1.data, B1.indices, B1.indptr,
                                              B2.data, B2.indices, B2.indptr,
                                              float(alpha), float(beta),
                                              b, out)
        else:
            core.spsolve_kron_csr_2_sum_upper(A1.data, A1.indices, A1.indptr,
                                              A2.data, A2.indices, A2.indptr,
                                              B1.data, B1.indices, B1.indptr,
                                              B2.data, B2.indices, B2.indptr,
                                              float(alpha), float(beta),
                                              b, out)

    # 2d case
    elif len(A.args) == 3 and A.rdim == 2:
        As_1, As_2, As_3 = A.args[:]

        assert(isinstance(As_1, KroneckerCSR))
        assert(isinstance(As_2, KroneckerCSR))
        assert(isinstance(As_3, KroneckerCSR))

        alpha = As_1.alpha
        beta  = As_2.alpha
        gamma = As_3.alpha

        A1, A2 = As_1.args[:]
        B1, B2 = As_2.args[:]
        C1, C2 = As_3.args[:]

        nrows, ncols = A.shape
        assert(nrows == ncols)

        if out is None:
            n = nrows
            out = np.zeros(n)

        if lower:
            core.spsolve_kron_csr_23_sum_lower(A1.data, A1.indices, A1.indptr,
                                               A2.data, A2.indices, A2.indptr,
                                               B1.data, B1.indices, B1.indptr,
                                               B2.data, B2.indices, B2.indptr,
                                               C1.data, C1.indices, C1.indptr,
                                               C2.data, C2.indices, C2.indptr,
                                               float(alpha), float(beta), float(gamma),
                                               b, out)
        else:
            core.spsolve_kron_csr_23_sum_upper(A1.data, A1.indices, A1.indptr,
                                               A2.data, A2.indices, A2.indptr,
                                               B1.data, B1.indices, B1.indptr,
                                               B2.data, B2.indices, B2.indptr,
                                               C1.data, C1.indices, C1.indptr,
                                               C2.data, C2.indices, C2.indptr,
                                               float(alpha), float(beta), float(gamma),
                                               b, out)

    # 3d case
    elif len(A.args) == 3 and A.rdim == 3:
        As_1, As_2, As_3 = A.args[:]

        assert(isinstance(As_1, KroneckerCSR))
        assert(isinstance(As_2, KroneckerCSR))
        assert(isinstance(As_3, KroneckerCSR))

        alpha = As_1.alpha
        beta  = As_2.alpha
        gamma = As_3.alpha

        A1, A2, A3 = As_1.args[:]
        B1, B2, B3 = As_2.args[:]
        C1, C2, C3 = As_3.args[:]

        nrows, ncols = A.shape
        assert(nrows == ncols)

        if out is None:
            n = nrows
            out = np.zeros(n)

        if lower:
            core.spsolve_kron_csr_3_sum_lower(A1.data, A1.indices, A1.indptr,
                                              A2.data, A2.indices, A2.indptr,
                                              A3.data, A3.indices, A3.indptr,
                                              B1.data, B1.indices, B1.indptr,
                                              B2.data, B2.indices, B2.indptr,
                                              B3.data, B3.indices, B3.indptr,
                                              C1.data, C1.indices, C1.indptr,
                                              C2.data, C2.indices, C2.indptr,
                                              C3.data, C3.indices, C3.indptr,
                                              float(alpha), float(beta), float(gamma),
                                              b, out)
        else:
            core.spsolve_kron_csr_3_sum_upper(A1.data, A1.indices, A1.indptr,
                                              A2.data, A2.indices, A2.indptr,
                                              A3.data, A3.indices, A3.indptr,
                                              B1.data, B1.indices, B1.indptr,
                                              B2.data, B2.indices, B2.indptr,
                                              B3.data, B3.indices, B3.indptr,
                                              C1.data, C1.indices, C1.indptr,
                                              C2.data, C2.indices, C2.indptr,
                                              C3.data, C3.indices, C3.indptr,
                                              float(alpha), float(beta), float(gamma),
                                              b, out)


    else:
        raise NotImplementedError('')

    return out

# =========================================================================
def _spsolve_dns(A, b, lower, out):

    if out is None:
        n = A.shape[0]
        out = np.zeros(n)

    if lower:
        core.spsolve_dns_lower(A, b, out)
    else:
        core.spsolve_dns_upper(A, b, out)

    return out

# =========================================================================
def spsolve(A, b, lower=True, out=None):

    if isinstance(A, np.ndarray):
        out = _spsolve_dns(A, b, lower, out)

    elif isinstance(A, csr_matrix):
        out = _spsolve_csr(A, b, lower, out)

    elif isinstance(A, KroneckerCSR):
        out = _spsolve_kron_csr(A, b, lower, out)

    elif isinstance(A, KroneckerSum):
        out = _spsolve_kron_sum_csr(A, b, lower, out)

    elif isinstance(A, (list, tuple)):
        out = _spsolve_kron_block(A, b, out)

    else:
        raise NotImplementedError('')

    return out

# =========================================================================
def _spsolve_kron_block_2(As, b, out=None):
    """
    Solves a triangular system of the form

    | A11   0 | [x1] = [y1]
    | A21 A22 | [x2] = [y2]
    if A11 and A22 are lower triangular matrices.

    or

    | A11 A12 | [x1] = [y1]
    |   0 A22 | [x2] = [y2]

    if A11 and A22 are upper triangular matrices.
    0 matrices must be specified as None
    """
    # ...
    assert(len(As) == 2)
    assert(len(As[0]) == 2)
    assert(len(As[1]) == 2)

    A11, A12 = As[0]
    A21, A22 = As[1]

    n1 = A11.shape[0]
    n2 = A22.shape[0]
    # ...

    # ...
    b1 = b[:n1]
    b2 = b[n1:]
    # ...

    # lower triangular matrix case
    if A12 is None:
        x1 = spsolve(A11, b1, lower=True)
        x2 = spsolve(A22, b2 - A21.dot(x1), lower=True)

    # upper triangular matrix case
    elif A21 is None:
        x2 = spsolve(A22, b2, lower=False)
        x1 = spsolve(A11, b1 - A12.dot(x2), lower=False)

    else:
        raise ValueError('Wrong entries')


    return np.concatenate([x1,x2])

# =========================================================================
def _spsolve_kron_block_3(As, b, out=None):
    """
    Solves a triangular system of the form

    | A11   0   0 | [x1] = [y1]
    | A21 A22   0 | [x2] = [y2]
    | A31 A32 A33 | [x3] = [y3]

    if A11 and A22 and A33 are lower triangular matrices.

    or

    | A11 A12 A13 | [x1] = [y1]
    |   0 A22 A23 | [x2] = [y2]
    |   0   0 A33 | [x3] = [y3]

    if A11 and A22 and A33 are upper triangular matrices.
    0 matrices must be specified as None
    """
    # ...
    assert(len(As) == 3)
    assert(len(As[0]) == 3)
    assert(len(As[1]) == 3)
    assert(len(As[2]) == 3)

    A11, A12, A13 = As[0]
    A21, A22, A23 = As[1]
    A31, A32, A33 = As[2]

    n1 = A11.shape[0]
    n2 = A22.shape[0]
    n3 = A33.shape[0]
    # ...

    # ...
    b1 = b[:n1]
    b2 = b[n1:n1+n2]
    b3 = b[n1+n2:]
    # ...

    # lower triangular matrix case
    if (A12 is None) and (A13 is None) and (A23 is None):
        x1 = spsolve(A11, b1, lower=True)
        x2 = spsolve(A22, b2 - A21.dot(x1), lower=True)
        x3 = spsolve(A33, b3 - A31.dot(x1) - A32.dot(x2), lower=True)

    # upper triangular matrix case
    elif (A21 is None) and (A31 is None) and (A32 is None):
        x3 = spsolve(A33, b3, lower=False)
        x2 = spsolve(A22, b2 - A23.dot(x3), lower=False)
        x1 = spsolve(A11, b1 - A12.dot(x2) - A13.dot(x3), lower=False)

    else:
        raise ValueError('Wrong entries')

    return np.concatenate([x1,x2,x3])

# =========================================================================
def _spsolve_kron_block(As, b, out=None):
    if len(As) == 2:
        out = _spsolve_kron_block_2(As, b, out)

    elif len(As) == 3:
        out = _spsolve_kron_block_3(As, b, out)

    else:
        raise ValueError('Wrong entries')

    return out

# =========================================================================
def triangular(A, lower):
    assert(isinstance(lower, bool))

    # TODO A must be of type coo
    A = coo_matrix(A)
    nrows, ncols = A.shape

    # we only treate square matrices
    assert(nrows == ncols)
    n = nrows

    # nnz is half of A.nnz + n terms on the diagonal
    nnz = (A.nnz - n) // 2 + n

    data = np.zeros(nnz)
    rows = np.zeros(nnz, dtype=int)
    cols = np.zeros(nnz, dtype=int)

    if lower:
        core.tril(A.row, A.col, A.data, rows, cols, data)
    else:
        core.triu(A.row, A.col, A.data, rows, cols, data)

    return  coo_matrix((data, (rows, cols)), shape=(nrows, ncols))

# =========================================================================
def kron_matrix_dense(As, lower):
    assert(len(As) == 2)

    As = [coo_matrix(A) for A in As]

    A1 = As[0] ; A2 = As[1]
    nrows = A1.shape[0] * A2.shape[0]
    ncols = A1.shape[1] * A2.shape[1]

    nnz = A1.nnz * A2.nnz

    data = np.zeros(nnz)
    rows = np.zeros(nnz, dtype=int)
    cols = np.zeros(nnz, dtype=int)

    k = 0
    for k1 in range(A1.nnz):
        i1 = A1.row[k1]
        j1 = A1.col[k1]
        v1 = A1.data[k1]
        for k2 in range(A2.nnz):
            i2 = A2.row[k2]
            j2 = A2.col[k2]
            v2 = A2.data[k2]

            i = i2 + i1 * A2.shape[0]
            j = j2 + j1 * A2.shape[1]
            v = v1 * v2

            rows[k] = i
            cols[k] = j
            data[k] = v

            k += 1

    return  coo_matrix((data, (rows, cols)), shape=(nrows, ncols))

# =========================================================================
def _tri_kron_2(As, lower):
    assert(isinstance(lower, bool))
    assert(len(As) == 2)

    As = [coo_matrix(A) for A in As]

    A1 = As[0] ; A2 = As[1]
    nrows = A1.shape[0] * A2.shape[0]
    ncols = A1.shape[1] * A2.shape[1]

    nnz = A1.nnz * A2.nnz
    # nnz is half of A.nnz + n terms on the diagonal
    nnz = (nnz - nrows) // 2 + nrows

    data = np.zeros(nnz)
    rows = np.zeros(nnz, dtype=int)
    cols = np.zeros(nnz, dtype=int)

    if lower:
        core.tril_kron_2(A1.nnz, A1.row, A1.col, A1.data,
                         A2.nnz, A2.row, A2.col, A2.data,
                         A2.shape[0], A2.shape[1],
                         rows, cols, data)
    else:
        core.triu_kron_2(A1.nnz, A1.row, A1.col, A1.data,
                         A2.nnz, A2.row, A2.col, A2.data,
                         A2.shape[0], A2.shape[1],
                         rows, cols, data)

    return  coo_matrix((data, (rows, cols)), shape=(nrows, ncols))

# =========================================================================
def _tri_kron_3(As, lower):
    assert(isinstance(lower, bool))
    assert(len(As) == 3)

    As = [coo_matrix(A) for A in As]

    A1 = As[0] ; A2 = As[1] ; A3 = As[2]
    nrows = A1.shape[0] * A2.shape[0] * A3.shape[0]
    ncols = A1.shape[1] * A2.shape[1] * A3.shape[1]

    nnz = A1.nnz * A2.nnz * A3.nnz
    # nnz is half of A.nnz + n terms on the diagonal
    nnz = (nnz - nrows) // 2 + nrows

    data = np.zeros(nnz)
    rows = np.zeros(nnz, dtype=int)
    cols = np.zeros(nnz, dtype=int)

    if lower:
        core.tril_kron_3(A1.nnz, A1.row, A1.col, A1.data,
                         A2.nnz, A2.row, A2.col, A2.data,
                         A3.nnz, A3.row, A3.col, A3.data,
                         A2.shape[0], A2.shape[1],
                         A3.shape[0], A3.shape[1],
                         rows, cols, data)
    else:
        core.triu_kron_3(A1.nnz, A1.row, A1.col, A1.data,
                         A2.nnz, A2.row, A2.col, A2.data,
                         A3.nnz, A3.row, A3.col, A3.data,
                         A2.shape[0], A2.shape[1],
                         A3.shape[0], A3.shape[1],
                         rows, cols, data)

    return  coo_matrix((data, (rows, cols)), shape=(nrows, ncols))

# =========================================================================
def tril(A):
    if not isinstance(A, (KroneckerCSR, KroneckerDNS)):
        raise NotImplementedError('')

    if A.rdim == 2:
        return _tri_kron_2(A.args, lower=True)

    elif A.rdim == 3:
        return _tri_kron_3(A.args, lower=True)

# =========================================================================
def triu(A):
    if not isinstance(A, (KroneckerCSR, KroneckerDNS)):
        raise NotImplementedError('')

    if A.rdim == 2:
        return _tri_kron_2(A.args, lower=False)

    elif A.rdim == 3:
        return _tri_kron_3(A.args, lower=False)
