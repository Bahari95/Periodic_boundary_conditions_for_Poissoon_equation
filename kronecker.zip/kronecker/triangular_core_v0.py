# =========================================================================
def spsolve_dns_lower(L: 'float[:,:]', b: 'float[:]', y: 'float[:]'):

    n = L.shape[0]

    for i in range(n):
        yi = 0.
        for j in range(i):
            yi += L[i,j] * y[j]

        y[i] = ( b[i] - yi ) / L[i,i]

# =========================================================================
def spsolve_dns_upper(U: 'float[:,:]', b: 'float[:]', y: 'float[:]'):

    n = U.shape[0]

    for i in range(n-1,-1,-1):
        yi = 0.
        for j in range(n-1,i-1,-1):
            yi += U[i,j] * y[j]

        y[i] = ( b[i] - yi ) / U[i,i]

# =========================================================================
def spsolve_csr_lower(A_data: 'float[:]', A_ind: 'int32[:]', A_ptr: 'int32[:]',
                      b: 'float[:]', y: 'float[:]'):

    n = len(A_ptr) - 1

    for i in range(n):
        yi = 0.
        for j in range(A_ptr[i], A_ptr[i+1]):
            yi += A_data[j] * y[A_ind[j]]

        y[i] = ( b[i] - yi ) / A_data[A_ptr[i+1]-1]

# =========================================================================
def spsolve_csr_upper(A_data: 'float[:]', A_ind: 'int32[:]', A_ptr: 'int32[:]',
                      b: 'float[:]', y: 'float[:]'):

    n = len(A_ptr) - 1

    for i in range(n-1,-1,-1):
        yi = 0.
        for j in range(A_ptr[i], A_ptr[i+1]):
            yi += A_data[j] * y[A_ind[j]]

        y[i] = ( b[i] - yi ) / A_data[A_ptr[i]]




# =========================================================================
def tril(A_rows: 'int32[:]', A_cols: 'int32[:]', A_data: 'float[:]', rows: 'int[:]', cols: 'int[:]', data: 'float[:]'):

    k = 0
    for i,j,v in zip(A_rows, A_cols, A_data):
        if j <= i:
            rows[k] = i
            cols[k] = j
            data[k] = v
            k += 1

# =========================================================================
def triu(A_rows: 'int32[:]', A_cols: 'int32[:]', A_data: 'float[:]', rows: 'int[:]', cols: 'int[:]', data: 'float[:]'):

    k = 0
    for i,j,v in zip(A_rows, A_cols, A_data):
        if i <= j:
            rows[k] = i
            cols[k] = j
            data[k] = v
            k += 1

# =========================================================================
def tril_kron_2(A1_nnz: int, A1_rows: 'int32[:]', A1_cols: 'int32[:]', A1_data: 'float[:]',
                A2_nnz: int, A2_rows: 'int32[:]', A2_cols: 'int32[:]', A2_data: 'float[:]',
                A2_nrows: int, A2_ncols: int,
                rows: 'int[:]', cols: 'int[:]', data: 'float[:]'):

    k = 0
    for k1 in range(A1_nnz):
        i1 = A1_rows[k1]
        j1 = A1_cols[k1]
        v1 = A1_data[k1]
        for k2 in range(A2_nnz):
            i2 = A2_rows[k2]
            j2 = A2_cols[k2]
            v2 = A2_data[k2]

            i = i2 + i1 * A2_nrows
            j = j2 + j1 * A2_ncols
            v = v1 * v2

            if j <= i:
                rows[k] = i
                cols[k] = j
                data[k] = v

                k += 1

# =========================================================================
def triu_kron_2(A1_nnz: int, A1_rows: 'int32[:]', A1_cols: 'int32[:]', A1_data: 'float[:]',
                A2_nnz: int, A2_rows: 'int32[:]', A2_cols: 'int32[:]', A2_data: 'float[:]',
                A2_nrows: int, A2_ncols: int,
                rows: 'int[:]', cols: 'int[:]', data: 'float[:]'):

    k = 0
    for k1 in range(A1_nnz):
        i1 = A1_rows[k1]
        j1 = A1_cols[k1]
        v1 = A1_data[k1]
        for k2 in range(A2_nnz):
            i2 = A2_rows[k2]
            j2 = A2_cols[k2]
            v2 = A2_data[k2]

            i = i2 + i1 * A2_nrows
            j = j2 + j1 * A2_ncols
            v = v1 * v2

            if i <= j:
                rows[k] = i
                cols[k] = j
                data[k] = v

                k += 1

# =========================================================================
def tril_kron_3(A1_nnz: int, A1_rows: 'int32[:]', A1_cols: 'int32[:]', A1_data: 'float[:]',
                A2_nnz: int, A2_rows: 'int32[:]', A2_cols: 'int32[:]', A2_data: 'float[:]',
                A3_nnz: int, A3_rows: 'int32[:]', A3_cols: 'int32[:]', A3_data: 'float[:]',
                A2_nrows: int, A2_ncols: int,
                A3_nrows: int, A3_ncols: int,
                rows: 'int[:]', cols: 'int[:]', data: 'float[:]'):

    k = 0
    for k1 in range(A1_nnz):
        i1 = A1_rows[k1]
        j1 = A1_cols[k1]
        v1 = A1_data[k1]
        for k2 in range(A2_nnz):
            i2 = A2_rows[k2]
            j2 = A2_cols[k2]
            v2 = A2_data[k2]

            for k3 in range(A3_nnz):
                i3 = A3_rows[k3]
                j3 = A3_cols[k3]
                v3 = A3_data[k3]

                i = i3 + (i2 + i1 * A2_nrows) * A3_nrows
                j = j3 + (j2 + j1 * A2_ncols) * A3_ncols
                v = v1 * v2 * v3

                if j <= i:
                    rows[k] = i
                    cols[k] = j
                    data[k] = v

                    k += 1

# =========================================================================
def triu_kron_3(A1_nnz: int, A1_rows: 'int32[:]', A1_cols: 'int32[:]', A1_data: 'float[:]',
                A2_nnz: int, A2_rows: 'int32[:]', A2_cols: 'int32[:]', A2_data: 'float[:]',
                A3_nnz: int, A3_rows: 'int32[:]', A3_cols: 'int32[:]', A3_data: 'float[:]',
                A2_nrows: int, A2_ncols: int,
                A3_nrows: int, A3_ncols: int,
                rows: 'int[:]', cols: 'int[:]', data: 'float[:]'):

    k = 0
    for k1 in range(A1_nnz):
        i1 = A1_rows[k1]
        j1 = A1_cols[k1]
        v1 = A1_data[k1]
        for k2 in range(A2_nnz):
            i2 = A2_rows[k2]
            j2 = A2_cols[k2]
            v2 = A2_data[k2]

            for k3 in range(A3_nnz):
                i3 = A3_rows[k3]
                j3 = A3_cols[k3]
                v3 = A3_data[k3]

                i = i3 + (i2 + i1 * A2_nrows) * A3_nrows
                j = j3 + (j2 + j1 * A2_ncols) * A3_ncols
                v = v1 * v2 * v3

                if i <= j:
                    rows[k] = i
                    cols[k] = j
                    data[k] = v

                    k += 1
